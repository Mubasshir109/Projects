
        document.getElementById('subscribe').addEventListener('click', function() {
            const email = document.querySelector('input[type="email"]').value;
            if (email) {
                alert('Thank you for subscribing with email: ' + email);
                
            } else {
                alert('Please enter a valid email address.');
            }
        });
 