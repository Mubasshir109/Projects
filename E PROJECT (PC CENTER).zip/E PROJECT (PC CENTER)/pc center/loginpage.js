function showBox(boxId) {
    // Hide all boxes
    document.querySelectorAll('.auth-box').forEach(box => {
      box.classList.remove('active');
    });
    
    // Show selected box
    document.getElementById(boxId).classList.add('active');
  }

  function handleLogin(e) {
    e.preventDefault();
    alert('Login functionality here');
  }

  function handleSignup(e) {
    e.preventDefault();
    alert('Signup functionality here');
  }

  function handleForgotPassword(e) {
    e.preventDefault();
    alert('Password reset instructions sent');
  }