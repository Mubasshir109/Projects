<?php
require_once 'config/database.php';
requireLogin();

$database = new Database();
$db = $database->connect();

// Get comprehensive dashboard data
try {
    // Basic counts
    $couriers_count = $db->query("SELECT COUNT(*) FROM couriers WHERE status = 'active'")->fetchColumn();
    $agents_count = $db->query("SELECT COUNT(*) FROM agents WHERE status = 'active'")->fetchColumn();
    $customers_count = $db->query("SELECT COUNT(*) FROM customers WHERE status = 'active'")->fetchColumn();
    $total_shipments = $db->query("SELECT COUNT(*) FROM shipments")->fetchColumn();
    
    // Shipment status counts
    $pending_shipments = $db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'pending'")->fetchColumn();
    $in_transit_shipments = $db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'in_transit'")->fetchColumn();
    $delivered_shipments = $db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'delivered'")->fetchColumn();
    $cancelled_shipments = $db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'cancelled'")->fetchColumn();
    
    // Revenue statistics
    $total_revenue = $db->query("SELECT SUM(total_cost) FROM shipments WHERE payment_status = 'paid'")->fetchColumn() ?? 0;
    $monthly_revenue = $db->query("SELECT SUM(total_cost) FROM shipments WHERE payment_status = 'paid' AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())")->fetchColumn() ?? 0;
    
    // Today's stats
    $today_shipments = $db->query("SELECT COUNT(*) FROM shipments WHERE DATE(created_at) = CURDATE()")->fetchColumn();
    $today_revenue = $db->query("SELECT SUM(total_cost) FROM shipments WHERE DATE(created_at) = CURDATE() AND payment_status = 'paid'")->fetchColumn() ?? 0;
    $today_customers = $db->query("SELECT COUNT(*) FROM customers WHERE DATE(created_at) = CURDATE()")->fetchColumn();
    
    // Recent activities
    $recent_shipments = $db->query("
        SELECT s.tracking_number, s.shipment_status, s.created_at, s.total_cost,
               c.full_name as customer_name, co.courier_name 
        FROM shipments s 
        JOIN customers c ON s.customer_id = c.id 
        JOIN couriers co ON s.courier_id = co.id 
        ORDER BY s.created_at DESC 
        LIMIT 8
    ")->fetchAll();
    
    // Recent customers
    $recent_customers = $db->query("
        SELECT full_name, customer_code, customer_type, created_at, city, state
        FROM customers
        ORDER BY created_at DESC
        LIMIT 5
    ")->fetchAll();
    
    // Top performing agents
    $top_agents = $db->query("
        SELECT a.full_name, a.agent_code, COUNT(s.id) as shipments_count, 
               SUM(s.total_cost) as total_revenue
        FROM agents a
        LEFT JOIN shipments s ON a.id = s.agent_id
        WHERE a.status = 'active'
        GROUP BY a.id
        ORDER BY shipments_count DESC
        LIMIT 5
    ")->fetchAll();
    
    // Courier performance
    $courier_performance = $db->query("
        SELECT co.courier_name, COUNT(s.id) as shipments_count, 
               SUM(CASE WHEN s.shipment_status = 'delivered' THEN 1 ELSE 0 END) as delivered_count,
               ROUND((SUM(CASE WHEN s.shipment_status = 'delivered' THEN 1 ELSE 0 END) / NULLIF(COUNT(s.id), 0)) * 100, 1) as success_rate
        FROM couriers co
        LEFT JOIN shipments s ON co.id = s.courier_id
        WHERE co.status = 'active' AND s.id IS NOT NULL
        GROUP BY co.id
        ORDER BY success_rate DESC
        LIMIT 4
    ")->fetchAll();
    
    // Monthly data for charts (last 6 months)
    $monthly_data = $db->query("
        SELECT DATE_FORMAT(created_at, '%Y-%m') as month, 
               DATE_FORMAT(created_at, '%M %Y') as month_name,
               SUM(total_cost) as revenue, COUNT(*) as shipments
        FROM shipments 
        WHERE payment_status = 'paid' AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY month ASC
    ")->fetchAll();
    
    // Delivery time analysis
    $avg_delivery_time = $db->query("
        SELECT AVG(DATEDIFF(delivery_date, pickup_date)) as avg_days
        FROM shipments 
        WHERE delivery_date IS NOT NULL AND pickup_date IS NOT NULL
    ")->fetchColumn() ?? 0;
    
    // Peak hours analysis
    $peak_hours = $db->query("
        SELECT HOUR(created_at) as hour, COUNT(*) as orders
        FROM shipments 
        WHERE DATE(created_at) >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY HOUR(created_at)
        ORDER BY orders DESC
        LIMIT 3
    ")->fetchAll();
    
    // Customer types distribution
    $customer_distribution = $db->query("
        SELECT customer_type, COUNT(*) as count
        FROM customers
        GROUP BY customer_type
    ")->fetchAll();
    
} catch (PDOException $e) {
    $error = "Error fetching dashboard data: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Courier Management System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%), 
                linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
    background-blend-mode: overlay;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body.dark-theme {
  background: radial-gradient(circle at top left, #1e272e, #0f2027, #2c5364);
  color: #ecf0f1;
  transition: background 0.5s ease, color 0.5s ease;
}
        
        .sidebar {
            background: linear-gradient(180deg, #1e3a8a 0%, #4f46e5 100%);
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: 2px 0 15px rgba(0,0,0,0.1);
        }
        
        .sidebar.collapsed {
            width: 70px;
        }
        
        .sidebar-item {
            color: rgba(255, 255, 255, 0.8);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
            overflow: hidden;
        }
        
        .sidebar-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
            transition: left 0.5s;
        }
        
        .sidebar-item:hover::before {
            left: 100%;
        }
        
        .sidebar-item:hover, .sidebar-item.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #3498db;
            transform: translateX(5px);
        }
        
        .sidebar-text {
            margin-left: 15px;
            transition: opacity 0.3s ease;
        }
        
        .collapsed .sidebar-text {
            opacity: 0;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }
        
        .main-content.expanded {
            margin-left: 70px;
        }
        
        .navbar-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 15px 30px;
            margin-bottom: 30px;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 1030;
        }
        
        /* Fix dropdown z-index issues */
        .navbar-custom .dropdown-menu {
            z-index: 1040;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            border: none;
            border-radius: 15px;
            padding: 10px 0;
        }
        
        .navbar-custom .dropdown {
            position: static;
        }
        
        .navbar-custom .dropdown-menu {
            position: absolute;
        }
        
        .welcome-banner {
            background: linear-gradient(135deg, #3b82f6 0%, #9333ea 100%);
            color: white;
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .welcome-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }
        
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .stat-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(45deg, #667eea, #764ba2);
        }
        
        .stat-icon {
            width: 70px;
            height: 70px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: white;
            margin-bottom: 20px;
            position: relative;
            overflow: hidden;
        }
        
        .stat-icon::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.2), transparent);
            animation: shimmer 3s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
        }
        
        .chart-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .activity-feed {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .activity-item {
            padding: 20px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            position: relative;
        }
        
        .activity-item:hover {
            background: linear-gradient(45deg, #f8f9ff, #fff5f5);
            transform: translateX(5px);
        }
        
        .activity-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            transform: scaleY(0);
            transition: transform 0.3s ease;
        }
        
        .activity-item:hover::before {
            transform: scaleY(1);
        }
        
        .performance-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .performance-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }
        
        .progress-ring {
            transform: rotate(-90deg);
        }
        
        .progress-ring-circle {
            stroke: #e6e6e6;
            fill: transparent;
            stroke-width: 8;
        }
        
        .progress-ring-meter {
            fill: transparent;
            stroke-width: 8;
            stroke-linecap: round;
            transition: stroke-dasharray 2s ease;
        }
        
        .quick-action {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
            color: white;
            padding: 15px 25px;
            border-radius: 15px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .quick-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
            color: white;
        }
        
        .quick-action::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s;
        }
        
        .quick-action:hover::before {
            left: 100%;
        }
        
        .weather-widget {
            background: linear-gradient(135deg, #74b9ff, #0984e3);
            color: white;
            border-radius: 20px;
            padding: 25px;
            text-align: center;
        }
        
        .time-widget {
            background: linear-gradient(135deg, #fd79a8, #e84393);
            color: white;
            border-radius: 20px;
            padding: 25px;
            text-align: center;
        }
        
        .animate-counter {
            animation: countUp 2s ease-out;
        }
        
        @keyframes countUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .floating-particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        }
        
        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            animation: float 6s infinite linear;
        }
        
        @keyframes float {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background: #ff6b6b;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.2); opacity: 0.8; }
        }
        
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
            animation: blink 2s infinite;
        }
        
        .status-indicator.online { background: #00b894; }
        .status-indicator.busy { background: #fdcb6e; }
        .status-indicator.offline { background: #fd79a8; }
        
        @keyframes blink {
            0%, 50% { opacity: 1; }
            51%, 100% { opacity: 0.5; }
        }
        
        .tracking-number {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            color: #667eea;
        }
        
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #dee2e6;
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -23px;
            top: 5px;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: #667eea;
            border: 2px solid white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.show {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .stat-card {
                margin-bottom: 20px;
            }
            
            .welcome-banner {
                padding: 20px;
            }
        }
        
        /* Dark theme adjustments */
        .dark-theme .navbar-custom,
        .dark-theme .stat-card,
        .dark-theme .chart-container,
        .dark-theme .activity-feed,
        .dark-theme .performance-card {
            background: rgba(44, 62, 80, 0.95);
            color: white;
        }
        
        .dark-theme .activity-item:hover {
            background: linear-gradient(45deg, rgba(52, 73, 94, 0.5), rgba(44, 62, 80, 0.5));
        }
    </style>
</head>
<body>
    <!-- Floating Particles -->
    <div class="floating-particles" id="particles"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="p-4 text-center border-bottom border-secondary">
            <h4 class="text-white mb-0">
                <i class="fas fa-shipping-fast me-2"></i>
                <span class="sidebar-text">CourierPro</span>
            </h4>
            <small class="text-white-50 sidebar-text">Management System v2.1</small>
        </div>
        
        <nav class="mt-3">
            <a href="dashboard.php" class="sidebar-item active">
                <i class="fas fa-tachometer-alt"></i>
                <span class="sidebar-text">Dashboard</span>
                <span class="notification-dot"></span>
            </a>
            <a href="couriers.php" class="sidebar-item">
                <i class="fas fa-truck"></i>
                <span class="sidebar-text">Couriers</span>
            </a>
            <a href="agents.php" class="sidebar-item">
                <i class="fas fa-users"></i>
                <span class="sidebar-text">Agents</span>
            </a>
            <a href="customers.php" class="sidebar-item">
                <i class="fas fa-user-friends"></i>
                <span class="sidebar-text">Customers</span>
            </a>
            <a href="shipments.php" class="sidebar-item">
                <i class="fas fa-box"></i>
                <span class="sidebar-text">Shipments</span>
            </a>
            <a href="reports.php" class="sidebar-item">
                <i class="fas fa-chart-bar"></i>
                <span class="sidebar-text">Reports</span>
            </a>
            <a href="profile.php" class="sidebar-item">
                <i class="fas fa-user-cog"></i>
                <span class="sidebar-text">Profile</span>
            </a>
            <a href="logout.php" class="sidebar-item">
                <i class="fas fa-sign-out-alt"></i>
                <span class="sidebar-text">Logout</span>
            </a>
        </nav>
        
        <!-- System Status -->
        <div class="p-4 mt-auto border-top border-secondary">
            <div class="text-white-50 small sidebar-text">
                <div class="mb-2">
                    <span class="status-indicator online"></span>
                    System Online
                </div>
                <div class="mb-2">
                    <i class="fas fa-server me-2"></i>
                    Server: 99.9% uptime
                </div>
                <div class="mb-2">
                    <i class="fas fa-database me-2"></i>
                    DB: Connected
                </div>
                <div>
                    <i class="fas fa-users-cog me-2"></i>
                    <?php echo $agents_count; ?> agents online
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <!-- Top Navigation -->
        <nav class="navbar-custom d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <button class="btn btn-outline-secondary me-3" onclick="toggleSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
                <div>
                    <h5 class="mb-0">
                        Good <?php echo date('H') < 12 ? 'Morning' : (date('H') < 17 ? 'Afternoon' : 'Evening'); ?>! 
                        <span class="text-primary"><?php echo $_SESSION['full_name']; ?></span>
                    </h5>
                    <small class="text-muted">Welcome back to your dashboard - Everything looks great!</small>
                </div>
            </div>
            
            <div class="d-flex align-items-center">
                <!-- Theme Toggle -->
                <!-- <button class="btn btn-outline-secondary me-2" onclick="toggleTheme()" title="Toggle Theme">
                    <i class="fas fa-moon" id="themeIcon"></i>
                </button> -->
                
                <!-- Fullscreen Toggle -->
                <!-- <button class="btn btn-outline-secondary me-2" onclick="toggleFullscreen()" title="Toggle Fullscreen">
                    <i class="fas fa-expand"></i>
                </button> -->
                
                <!-- Quick Actions -->
                <div class="dropdown me-3">
                    <button class="btn quick-action dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fas fa-plus me-2"></i>Quick Add
                    </button>
                    <ul class="dropdown-menu shadow-lg">
                        <li><a class="dropdown-item" href="shipments.php">
                            <i class="fas fa-box text-primary me-2"></i>New Shipment
                        </a></li>
                        <li><a class="dropdown-item" href="customers.php">
                            <i class="fas fa-user-plus text-success me-2"></i>New Customer
                        </a></li>
                        <li><a class="dropdown-item" href="agents.php">
                            <i class="fas fa-user-tie text-info me-2"></i>New Agent
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="exportDashboardData()">
                            <i class="fas fa-download text-warning me-2"></i>Export Data
                        </a></li>
                    </ul>
                </div>
                
                <!-- Notifications -->
                <div class="dropdown me-3">
                    <button class="btn btn-outline-primary dropdown-toggle position-relative" data-bs-toggle="dropdown">
                        <i class="fas fa-bell"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?php echo $pending_shipments + $today_shipments; ?>
                        </span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-lg" style="width: 320px;">
                        <li class="dropdown-header d-flex justify-content-between">
                            <span>Notifications</span>
                            <button class="btn btn-sm btn-outline-primary" onclick="markAllRead()">Mark All Read</button>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="shipments.php">
                            <div class="d-flex">
                                <i class="fas fa-exclamation-triangle text-warning me-3 mt-1"></i>
                                <div>
                                    <strong><?php echo $pending_shipments; ?> pending shipments</strong>
                                    <br><small class="text-muted">Need immediate attention</small>
                                </div>
                            </div>
                        </a></li>
                        <li><a class="dropdown-item" href="shipments.php">
                            <div class="d-flex">
                                <i class="fas fa-truck text-info me-3 mt-1"></i>
                                <div>
                                    <strong><?php echo $today_shipments; ?> new shipments today</strong>
                                    <br><small class="text-muted">Created in the last 24 hours</small>
                                </div>
                            </div>
                        </a></li>
                        <li><a class="dropdown-item" href="reports.php">
                            <div class="d-flex">
                                <i class="fas fa-chart-line text-success me-3 mt-1"></i>
                                <div>
                                    <strong>Today's revenue: <?php echo formatCurrency($today_revenue); ?></strong>
                                    <br><small class="text-muted">Revenue generated today</small>
                                </div>
                            </div>
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li class="text-center">
                            <a href="" class="dropdown-item text-primary">
                                <i class="fas fa-eye me-2"></i>View All Notifications
                            </a>
                        </li>
                    </ul>
                </div>
                
                <!-- User Profile -->
                <div class="dropdown">
                    <button class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                        <div class="d-flex align-items-center">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                <?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?>
                            </div>
                            <div class="d-none d-lg-block text-start">
                                <div class="fw-bold"><?php echo $_SESSION['full_name']; ?></div>
                                <small class="text-muted"><?php echo ucfirst($_SESSION['role']); ?> Admin</small>
                            </div>
                        </div>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-lg">
                        <li class="dropdown-header">Account Settings</li>
                        <li><a class="dropdown-item" href="profile.php">
                            <i class="fas fa-user-cog text-primary me-2"></i>Profile Settings
                        </a></li>
                        <li><a class="dropdown-item" href="#">
                            <i class="fas fa-cog text-secondary me-2"></i>System Preferences
                        </a></li>
                        <li><a class="dropdown-item" href="#">
                            <i class="fas fa-bell text-warning me-2"></i>Notification Settings
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="showHelp()">
                            <i class="fas fa-question-circle text-info me-2"></i>Help & Support
                        </a></li>
                        <li><a class="dropdown-item text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Welcome Banner with Live Data -->
        <div class="welcome-banner">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="mb-3">
                        <i class="fas fa-chart-line me-3"></i>
                        Dashboard Overview
                        <span class="badge bg-success ms-3">Live Data</span>
                    </h2>
                    <p class="mb-3 opacity-90 fs-5">
                        Managing <strong><?php echo number_format($total_shipments); ?></strong> shipments across <strong><?php echo $couriers_count; ?></strong> courier partners
                        with <strong><?php echo formatCurrency($total_revenue); ?></strong> in total revenue
                    </p>
                    <div class="d-flex align-items-center flex-wrap">
                        <div class="me-4 mb-2">
                            <span class="status-indicator online"></span>
                            <span>System Status: Online</span>
                        </div>
                        <div class="me-4 mb-2">
                            <i class="fas fa-clock me-2"></i>
                            <span id="currentTime"></span>
                        </div>
                        <div class="me-4 mb-2">
                            <i class="fas fa-calendar me-2"></i>
                            <span id="currentDate"></span>
                        </div>
                        <div class="mb-2">
                            <i class="fas fa-globe me-2"></i>
                            <span>Karachi, Pakistan</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <div class="row">
                        <div class="col-6 mb-3">
                            <div class="weather-widget">
                                <i class="fas fa-sun fa-2x mb-2"></i>
                                <h4 id="temperature">28°C</h4>
                                <small>Sunny</small>
                            </div>
                        </div>
                        <div class="col-6 mb-3">
                            <div class="time-widget">
                                <i class="fas fa-users fa-2x mb-2"></i>
                                <h4><?php echo $agents_count; ?></h4>
                                <small>Active Agents</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Enhanced Statistics Cards -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="stat-card text-center">
                    <div class="stat-icon mx-auto" style="background: linear-gradient(45deg, #667eea, #764ba2);">
                        <i class="fas fa-box"></i>
                    </div>
                    <h2 class="animate-counter fw-bold text-primary mb-1" data-target="<?php echo $total_shipments; ?>">0</h2>
                    <p class="text-muted mb-2">Total Shipments</p>
                    <div class="d-flex justify-content-between">
                        <small class="text-success">
                            <i class="fas fa-arrow-up me-1"></i>
                            +<?php echo $today_shipments; ?> today
                        </small>
                        <small class="text-info">
                            <i class="fas fa-clock me-1"></i>
                            <?php echo $pending_shipments; ?> pending
                        </small>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="stat-card text-center">
                    <div class="stat-icon mx-auto" style="background: linear-gradient(45deg, #00b894, #00a085);">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <h2 class="animate-counter fw-bold text-success mb-1" data-target="<?php echo intval($total_revenue); ?>">0</h2>
                    <p class="text-muted mb-2">Total Revenue</p>
                    <div class="d-flex justify-content-between">
                        <small class="text-success">
                            <i class="fas fa-arrow-up me-1"></i>
                            +<?php echo formatCurrency($today_revenue); ?> today
                        </small>
                        <small class="text-info">
                            <i class="fas fa-calendar me-1"></i>
                            <?php echo formatCurrency($monthly_revenue); ?> this month
                        </small>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="stat-card text-center">
                    <div class="stat-icon mx-auto" style="background: linear-gradient(45deg, #fd79a8, #e84393);">
                        <i class="fas fa-users"></i>
                    </div>
                    <h2 class="animate-counter fw-bold text-info mb-1" data-target="<?php echo $customers_count; ?>">0</h2>
                    <p class="text-muted mb-2">Active Customers</p>
                    <div class="d-flex justify-content-between">
                        <small class="text-success">
                            <i class="fas fa-user-plus me-1"></i>
                            +<?php echo $today_customers; ?> new today
                        </small>
                        <small class="text-info">
                            <?php 
                            $business_customers = 0;
                            foreach($customer_distribution as $dist) {
                                if($dist['customer_type'] === 'business') $business_customers = $dist['count'];
                            }
                            echo $business_customers;
                            ?> business
                        </small>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="stat-card text-center">
                    <div class="stat-icon mx-auto" style="background: linear-gradient(45deg, #fdcb6e, #f39c12);">
                        <i class="fas fa-truck"></i>
                    </div>
                    <h2 class="animate-counter fw-bold text-warning mb-1" data-target="<?php echo $couriers_count; ?>">0</h2>
                    <p class="text-muted mb-2">Active Couriers</p>
                    <div class="d-flex justify-content-between">
                        <small class="text-warning">
                            <i class="fas fa-shipping-fast me-1"></i>
                            <?php echo number_format($avg_delivery_time, 1); ?> avg days
                        </small>
                        <small class="text-success">
                            <?php echo round((($total_shipments - $cancelled_shipments) / max($total_shipments, 1)) * 100, 1); ?>% success
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Real-time Shipment Status with Progress Rings -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="performance-card text-center">
                    <div class="position-relative d-inline-block">
                        <svg class="progress-ring" width="80" height="80">
                            <circle class="progress-ring-circle" cx="40" cy="40" r="35"></circle>
                            <circle class="progress-ring-meter" cx="40" cy="40" r="35" 
                                    stroke="url(#gradient1)" 
                                    stroke-dasharray="<?php echo round(($pending_shipments / max($total_shipments, 1)) * 220); ?> 220"></circle>
                            <defs>
                                <linearGradient id="gradient1">
                                    <stop offset="0%" stop-color="#ffc107"/>
                                    <stop offset="100%" stop-color="#ff8c00"/>
                                </linearGradient>
                            </defs>
                        </svg>
                        <div class="position-absolute top-50 start-50 translate-middle text-center">
                            <h5 class="mb-0"><?php echo $pending_shipments; ?></h5>
                        </div>
                    </div>
                    <h6 class="mt-3 text-warning">Pending</h6>
                    <small class="text-muted">Awaiting pickup</small>
                    <div class="mt-2">
                        <div class="progress" style="height: 4px;">
                            <div class="progress-bar bg-warning" style="width: <?php echo round(($pending_shipments / max($total_shipments, 1)) * 100); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="performance-card text-center">
                    <div class="position-relative d-inline-block">
                        <svg class="progress-ring" width="80" height="80">
                            <circle class="progress-ring-circle" cx="40" cy="40" r="35"></circle>
                            <circle class="progress-ring-meter" cx="40" cy="40" r="35" 
                                    stroke="url(#gradient2)" 
                                    stroke-dasharray="<?php echo round(($in_transit_shipments / max($total_shipments, 1)) * 220); ?> 220"></circle>
                            <defs>
                                <linearGradient id="gradient2">
                                    <stop offset="0%" stop-color="#17a2b8"/>
                                    <stop offset="100%" stop-color="#007bff"/>
                                </linearGradient>
                            </defs>
                        </svg>
                        <div class="position-absolute top-50 start-50 translate-middle text-center">
                            <h5 class="mb-0"><?php echo $in_transit_shipments; ?></h5>
                        </div>
                    </div>
                    <h6 class="mt-3 text-info">In Transit</h6>
                    <small class="text-muted">On the way</small>
                    <div class="mt-2">
                        <div class="progress" style="height: 4px;">
                            <div class="progress-bar bg-info" style="width: <?php echo round(($in_transit_shipments / max($total_shipments, 1)) * 100); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="performance-card text-center">
                    <div class="position-relative d-inline-block">
                        <svg class="progress-ring" width="80" height="80">
                            <circle class="progress-ring-circle" cx="40" cy="40" r="35"></circle>
                            <circle class="progress-ring-meter" cx="40" cy="40" r="35" 
                                    stroke="url(#gradient3)" 
                                    stroke-dasharray="<?php echo round(($delivered_shipments / max($total_shipments, 1)) * 220); ?> 220"></circle>
                            <defs>
                                <linearGradient id="gradient3">
                                    <stop offset="0%" stop-color="#28a745"/>
                                    <stop offset="100%" stop-color="#20c997"/>
                                </linearGradient>
                            </defs>
                        </svg>
                        <div class="position-absolute top-50 start-50 translate-middle text-center">
                            <h5 class="mb-0"><?php echo $delivered_shipments; ?></h5>
                        </div>
                    </div>
                    <h6 class="mt-3 text-success">Delivered</h6>
                    <small class="text-muted">Successfully completed</small>
                    <div class="mt-2">
                        <div class="progress" style="height: 4px;">
                            <div class="progress-bar bg-success" style="width: <?php echo round(($delivered_shipments / max($total_shipments, 1)) * 100); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="performance-card text-center">
                    <div class="position-relative d-inline-block">
                        <svg class="progress-ring" width="80" height="80">
                            <circle class="progress-ring-circle" cx="40" cy="40" r="35"></circle>
                            <circle class="progress-ring-meter" cx="40" cy="40" r="35" 
                                    stroke="url(#gradient4)" 
                                    stroke-dasharray="<?php echo round((($total_shipments - $cancelled_shipments) / max($total_shipments, 1)) * 220); ?> 220"></circle>
                            <defs>
                                <linearGradient id="gradient4">
                                    <stop offset="0%" stop-color="#6f42c1"/>
                                    <stop offset="100%" stop-color="#e83e8c"/>
                                </linearGradient>
                            </defs>
                        </svg>
                        <div class="position-absolute top-50 start-50 translate-middle text-center">
                            <h5 class="mb-0"><?php echo round((($total_shipments - $cancelled_shipments) / max($total_shipments, 1)) * 100); ?>%</h5>
                        </div>
                    </div>
                    <h6 class="mt-3 text-primary">Success Rate</h6>
                    <small class="text-muted">Overall performance</small>
                    <div class="mt-2">
                        <div class="progress" style="height: 4px;">
                            <div class="progress-bar bg-primary" style="width: <?php echo round((($total_shipments - $cancelled_shipments) / max($total_shipments, 1)) * 100); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts and Analytics Section -->
        <div class="row mb-4">
            <div class="col-lg-8 mb-4">
                <div class="chart-container">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0">
                            <i class="fas fa-chart-line text-primary me-2"></i>
                            Revenue & Shipments Trend
                        </h5>
                        <div class="btn-group" role="group">
                            <input type="radio" class="btn-check" name="chartPeriod" id="period7" checked>
                            <label class="btn btn-outline-primary btn-sm" for="period7">7D</label>
                            
                            <input type="radio" class="btn-check" name="chartPeriod" id="period30">
                            <label class="btn btn-outline-primary btn-sm" for="period30">30D</label>
                            
                            <input type="radio" class="btn-check" name="chartPeriod" id="period90">
                            <label class="btn btn-outline-primary btn-sm" for="period90">90D</label>
                        </div>
                    </div>
                    <canvas id="revenueChart" height="100"></canvas>
                    
                    <!-- Chart Statistics -->
                    <div class="row mt-4">
                        <div class="col-md-4 text-center">
                            <div class="border-end">
                                <h6 class="text-primary">Peak Revenue</h6>
                                <p class="mb-0 fw-bold"><?php echo formatCurrency(max(array_column($monthly_data, 'revenue'))); ?></p>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="border-end">
                                <h6 class="text-success">Avg Monthly</h6>
                                <p class="mb-0 fw-bold"><?php echo formatCurrency(array_sum(array_column($monthly_data, 'revenue')) / max(count($monthly_data), 1)); ?></p>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <h6 class="text-info">Growth Rate</h6>
                            <p class="mb-0 fw-bold text-success">+15.3%</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 mb-4">
                <div class="chart-container">
                    <h5 class="mb-4">
                        <i class="fas fa-chart-pie text-primary me-2"></i>
                        Customer Distribution
                    </h5>
                    <canvas id="customerChart"></canvas>
                    <div class="mt-4">
                        <?php foreach ($customer_distribution as $dist): ?>
                        <div class="d-flex justify-content-between align-items-center mb-3 p-2 bg-light rounded">
                            <div class="d-flex align-items-center">
                                <span class="badge bg-<?php echo $dist['customer_type'] === 'business' ? 'primary' : 'info'; ?> me-2">
                                    <i class="fas fa-<?php echo $dist['customer_type'] === 'business' ? 'building' : 'user'; ?>"></i>
                                </span>
                                <span class="fw-bold"><?php echo ucfirst($dist['customer_type']); ?></span>
                            </div>
                            <span class="badge bg-secondary"><?php echo $dist['count']; ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Performance Dashboard Section -->
        <div class="row mb-4">
            <div class="col-lg-6 mb-4">
                <div class="activity-feed">
                    <div class="p-4 border-bottom bg-light rounded-top">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">
                                <i class="fas fa-trophy text-warning me-2"></i>
                                Top Performing Agents
                            </h5>
                            <span class="badge bg-warning text-dark">Top 5</span>
                        </div>
                    </div>
                    <div style="max-height: 400px; overflow-y: auto;">
                        <?php foreach ($top_agents as $index => $agent): ?>
                        <div class="activity-item">
                            <div class="d-flex align-items-center">
                                <div class="position-relative me-3">
                                    <div class="bg-gradient text-white rounded-circle d-flex align-items-center justify-content-center" 
                                         style="width: 50px; height: 50px; background: linear-gradient(45deg, #<?php echo substr(md5($agent['full_name']), 0, 6); ?>, #<?php echo substr(md5($agent['agent_code']), 0, 6); ?>);">
                                        <?php echo strtoupper(substr($agent['full_name'], 0, 1)); ?>
                                    </div>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning text-dark">
                                        #<?php echo $index + 1; ?>
                                    </span>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($agent['full_name']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars($agent['agent_code']); ?></small>
                                    <div class="mt-2">
                                        <div class="progress" style="height: 6px;">
                                            <div class="progress-bar bg-gradient" 
                                                 style="width: <?php echo min(($agent['shipments_count'] / max(array_column($top_agents, 'shipments_count'))) * 100, 100); ?>%; 
                                                        background: linear-gradient(45deg, #667eea, #764ba2);"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <div class="fw-bold text-primary"><?php echo $agent['shipments_count']; ?></div>
                                    <small class="text-muted">Shipments</small>
                                    <div class="text-success fw-bold"><?php echo formatCurrency($agent['total_revenue']); ?></div>
                                    <small class="text-muted">Revenue</small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="p-3 bg-light rounded-bottom text-center">
                        <a href="agents.php" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-users me-2"></i>View All Agents
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6 mb-4">
                <div class="activity-feed">
                    <div class="p-4 border-bottom bg-light rounded-top">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">
                                <i class="fas fa-shipping-fast text-info me-2"></i>
                                Courier Performance
                            </h5>
                            <span class="badge bg-info">Live Data</span>
                        </div>
                    </div>
                    <div style="max-height: 400px; overflow-y: auto;">
                        <?php foreach ($courier_performance as $index => $courier): ?>
                        <div class="activity-item">
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <div class="bg-info text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                        <i class="fas fa-truck"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($courier['courier_name']); ?></h6>
                                    <div class="d-flex justify-content-between align-items-center mt-2">
                                        <small class="text-muted">Success Rate</small>
                                        <span class="badge bg-<?php echo $courier['success_rate'] >= 90 ? 'success' : ($courier['success_rate'] >= 70 ? 'warning' : 'danger'); ?>">
                                            <?php echo $courier['success_rate']; ?>%
                                        </span>
                                    </div>
                                    <div class="progress mt-2" style="height: 6px;">
                                        <div class="progress-bar bg-<?php echo $courier['success_rate'] >= 90 ? 'success' : ($courier['success_rate'] >= 70 ? 'warning' : 'danger'); ?>" 
                                             style="width: <?php echo $courier['success_rate']; ?>%"></div>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <div class="fw-bold text-primary"><?php echo $courier['shipments_count']; ?></div>
                                    <small class="text-muted">Total</small>
                                    <div class="fw-bold text-success"><?php echo $courier['delivered_count']; ?></div>
                                    <small class="text-muted">Delivered</small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="p-3 bg-light rounded-bottom text-center">
                        <a href="couriers.php" class="btn btn-outline-info btn-sm">
                            <i class="fas fa-truck me-2"></i>Manage Couriers
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activity and Quick Stats -->
        <div class="row">
            <div class="col-lg-8 mb-4">
                <div class="activity-feed">
                    <div class="p-4 border-bottom bg-light rounded-top">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">
                                <i class="fas fa-history text-primary me-2"></i>
                                Recent Shipments Activity
                                <span class="badge bg-primary ms-2">Live</span>
                            </h5>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                                    <i class="fas fa-filter me-1"></i>Filter
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" onclick="filterActivity('all')">All Activities</a></li>
                                    <li><a class="dropdown-item" href="#" onclick="filterActivity('delivered')">Delivered Only</a></li>
                                    <li><a class="dropdown-item" href="#" onclick="filterActivity('pending')">Pending Only</a></li>
                                    <li><a class="dropdown-item" href="#" onclick="filterActivity('in_transit')">In Transit Only</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div style="max-height: 500px; overflow-y: auto;" id="activityFeed">
                        <?php foreach ($recent_shipments as $shipment): ?>
                        <div class="activity-item" data-status="<?php echo $shipment['shipment_status']; ?>">
                            <div class="d-flex align-items-start">
                                <div class="me-3">
                                    <div class="bg-<?php echo $shipment['shipment_status'] === 'delivered' ? 'success' : ($shipment['shipment_status'] === 'pending' ? 'warning' : 'info'); ?> text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 45px; height: 45px;">
                                        <i class="fas fa-<?php echo $shipment['shipment_status'] === 'delivered' ? 'check' : ($shipment['shipment_status'] === 'pending' ? 'clock' : 'truck'); ?>"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1">
                                                <span class="tracking-number"><?php echo $shipment['tracking_number']; ?></span>
                                                <span class="badge bg-<?php 
                                                    switch($shipment['shipment_status']) {
                                                        case 'pending': echo 'warning'; break;
                                                        case 'in_transit': echo 'info'; break;
                                                        case 'delivered': echo 'success'; break;
                                                        case 'cancelled': echo 'danger'; break;
                                                        default: echo 'secondary';
                                                    }
                                                ?> ms-2">
                                                    <?php echo ucfirst(str_replace('_', ' ', $shipment['shipment_status'])); ?>
                                                </span>
                                            </h6>
                                            <p class="mb-1 text-muted">
                                                Customer: <strong><?php echo htmlspecialchars($shipment['customer_name']); ?></strong> via 
                                                <span class="text-primary"><?php echo htmlspecialchars($shipment['courier_name']); ?></span>
                                            </p>
                                            <small class="text-muted">
                                                <i class="fas fa-clock me-1"></i>
                                                <?php echo formatDate($shipment['created_at'], 'M d, Y H:i'); ?>
                                            </small>
                                        </div>
                                        <div class="text-end">
                                            <div class="fw-bold text-success"><?php echo formatCurrency($shipment['total_cost']); ?></div>
                                            <button class="btn btn-sm btn-outline-primary mt-1" onclick="viewShipmentDetails('<?php echo $shipment['tracking_number']; ?>')">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="p-3 bg-light rounded-bottom text-center">
                        <a href="shipments.php" class="btn btn-primary">
                            <i class="fas fa-box me-2"></i>View All Shipments
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <!-- Today's Performance Widget -->
                <div class="performance-card mb-4">
                    <h6 class="text-primary mb-3">
                        <i class="fas fa-tachometer-alt me-2"></i>
                        Today's Performance
                        <span class="badge bg-success ms-2 small">Live</span>
                    </h6>
                    <div class="row text-center">
                        <div class="col-6 mb-3">
                            <div class="bg-light rounded p-3 position-relative overflow-hidden">
                                <div class="position-absolute top-0 start-0 w-100 h-100 opacity-25" 
                                     style="background: linear-gradient(45deg, #667eea, #764ba2);"></div>
                                <h4 class="text-primary mb-1 position-relative"><?php echo $today_shipments; ?></h4>
                                <small class="text-muted position-relative">New Orders</small>
                            </div>
                        </div>
                        <div class="col-6 mb-3">
                            <div class="bg-light rounded p-3 position-relative overflow-hidden">
                                <div class="position-absolute top-0 start-0 w-100 h-100 opacity-25" 
                                     style="background: linear-gradient(45deg, #00b894, #00a085);"></div>
                                <h4 class="text-success mb-1 position-relative"><?php echo formatCurrency($today_revenue); ?></h4>
                                <small class="text-muted position-relative">Revenue</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="bg-light rounded p-3 position-relative overflow-hidden">
                                <div class="position-absolute top-0 start-0 w-100 h-100 opacity-25" 
                                     style="background: linear-gradient(45deg, #fd79a8, #e84393);"></div>
                                <h4 class="text-info mb-1 position-relative"><?php echo $today_customers; ?></h4>
                                <small class="text-muted position-relative">New Customers</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="bg-light rounded p-3 position-relative overflow-hidden">
                                <div class="position-absolute top-0 start-0 w-100 h-100 opacity-25" 
                                     style="background: linear-gradient(45deg, #fdcb6e, #f39c12);"></div>
                                <h4 class="text-warning mb-1 position-relative"><?php echo count($peak_hours); ?></h4>
                                <small class="text-muted position-relative">Peak Hours</small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quick Analytics -->
                    <div class="mt-4 pt-3 border-top">
                        <div class="row">
                            <div class="col-6">
                                <small class="text-muted">Avg Delivery Time</small>
                                <div class="fw-bold text-primary"><?php echo number_format($avg_delivery_time, 1); ?> days</div>
                            </div>
                            <div class="col-6">
                                <small class="text-muted">Success Rate</small>
                                <div class="fw-bold text-success"><?php echo round((($delivered_shipments / max($total_shipments, 1)) * 100), 1); ?>%</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Customers Widget -->
                <div class="activity-feed">
                    <div class="p-4 border-bottom bg-light rounded-top">
                        <h6 class="mb-0">
                            <i class="fas fa-user-plus text-success me-2"></i>
                            Recent Customers
                        </h6>
                    </div>
                    <div style="max-height: 300px; overflow-y: auto;">
                        <?php foreach ($recent_customers as $customer): ?>
                        <div class="activity-item">
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <div class="bg-gradient text-white rounded-circle d-flex align-items-center justify-content-center" 
                                         style="width: 40px; height: 40px; background: linear-gradient(45deg, #<?php echo substr(md5($customer['full_name']), 0, 6); ?>, #<?php echo substr(md5($customer['customer_code']), 0, 6); ?>);">
                                        <?php echo strtoupper(substr($customer['full_name'], 0, 1)); ?>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($customer['full_name']); ?></h6>
                                    <small class="text-muted">
                                        <?php echo htmlspecialchars($customer['customer_code']); ?> • 
                                        <span class="badge bg-<?php echo $customer['customer_type'] === 'business' ? 'primary' : 'info'; ?> badge-sm">
                                            <?php echo ucfirst($customer['customer_type']); ?>
                                        </span>
                                    </small>
                                    <br>
                                    <small class="text-primary">
                                        <i class="fas fa-map-marker-alt me-1"></i>
                                        <?php echo htmlspecialchars($customer['city']); ?>, <?php echo htmlspecialchars($customer['state']); ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <small class="text-muted"><?php echo formatDate($customer['created_at'], 'M d'); ?></small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="p-3 bg-light rounded-bottom text-center">
                        <a href="customers.php" class="btn btn-outline-success btn-sm">
                            <i class="fas fa-users me-2"></i>Manage Customers
                        </a>
                    </div>
                </div>
                
                <!-- System Information Widget -->
                <div class="performance-card mt-4">
                    <h6 class="text-primary mb-3">
                        <i class="fas fa-server me-2"></i>
                        System Status
                    </h6>
                    <div class="small">
                        <div class="d-flex justify-content-between align-items-center mb-3 p-2 bg-light rounded">
                            <div class="d-flex align-items-center">
                                <span class="status-indicator online me-2"></span>
                                <span>Server Status</span>
                            </div>
                            <span class="badge bg-success">Online</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3 p-2 bg-light rounded">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-database text-info me-2"></i>
                                <span>Database</span>
                            </div>
                            <span class="badge bg-success">Connected</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3 p-2 bg-light rounded">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-cloud text-primary me-2"></i>
                                <span>Last Backup</span>
                            </div>
                            <span class="text-info">2 hours ago</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3 p-2 bg-light rounded">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-code-branch text-warning me-2"></i>
                                <span>Version</span>
                            </div>
                            <span class="badge bg-secondary">v2.1.0</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center p-2 bg-light rounded">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-chart-line text-success me-2"></i>
                                <span>Uptime</span>
                            </div>
                            <span class="badge bg-success">99.9%</span>
                        </div>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="mt-4 pt-3 border-top">
                        <div class="d-grid gap-2">
                            <button class="btn btn-outline-primary btn-sm" onclick="refreshDashboard()">
                                <i class="fas fa-sync-alt me-2"></i>Refresh Data
                            </button>
                            <button class="btn btn-outline-success btn-sm" onclick="exportDashboardData()">
                                <i class="fas fa-download me-2"></i>Export Report
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sidebar toggle functionality
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            
            // Store preference in localStorage (Note: Not available in Claude artifacts)
            try {
                localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            } catch (e) {
                console.log('localStorage not available');
            }
        }

        // Initialize sidebar state
        document.addEventListener('DOMContentLoaded', function() {
            try {
                const collapsed = localStorage.getItem('sidebarCollapsed') === 'true';
                if (collapsed) {
                    toggleSidebar();
                }
            } catch (e) {
                console.log('localStorage not available');
            }
        });

        // Real-time clock and date
        function updateDateTime() {
            const now = new Date();
            
            // Update time
            const timeOptions = { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit',
                timeZone: 'Asia/Karachi'
            };
            const timeElement = document.getElementById('currentTime');
            if (timeElement) {
                timeElement.textContent = now.toLocaleTimeString('en-US', timeOptions);
            }
            
            // Update date
            const dateOptions = {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            };
            const dateElement = document.getElementById('currentDate');
            if (dateElement) {
                dateElement.textContent = now.toLocaleDateString('en-US', dateOptions);
            }
        }
        
        setInterval(updateDateTime, 1000);
        updateDateTime();

        // Floating particles animation
        function createParticles() {
            const container = document.getElementById('particles');
            if (!container) return;
            
            const particleCount = 25;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 6 + 's';
                particle.style.animationDuration = (Math.random() * 4 + 4) + 's';
                container.appendChild(particle);
            }
        }
        createParticles();

        // Initialize Charts
        const revenueCtx = document.getElementById('revenueChart');
        if (revenueCtx) {
            const monthlyData = <?php echo json_encode($monthly_data); ?>;
            
            new Chart(revenueCtx, {
                type: 'line',
                data: {
                    labels: monthlyData.map(item => item.month_name),
                    datasets: [{
                        label: 'Revenue (PKR)',
                        data: monthlyData.map(item => item.revenue),
                        borderColor: 'rgb(102, 126, 234)',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: 'rgb(102, 126, 234)',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 6,
                        pointHoverRadius: 8
                    }, {
                        label: 'Shipments',
                        data: monthlyData.map(item => item.shipments),
                        borderColor: 'rgb(255, 107, 107)',
                        backgroundColor: 'rgba(255, 107, 107, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: 'rgb(255, 107, 107)',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 6,
                        pointHoverRadius: 8,
                        yAxisID: 'y1'
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true,
                                font: {
                                    size: 12
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0,0,0,0.8)',
                            titleColor: 'white',
                            bodyColor: 'white',
                            cornerRadius: 10,
                            displayColors: true,
                            callbacks: {
                                label: function(context) {
                                    if (context.datasetIndex === 0) {
                                        return 'Revenue: PKR ' + context.parsed.y.toLocaleString();
                                    } else {
                                        return 'Shipments: ' + context.parsed.y;
                                    }
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            position: 'left',
                            ticks: {
                                callback: function(value) {
                                    return 'PKR ' + value.toLocaleString();
                                }
                            },
                            grid: {
                                color: 'rgba(0,0,0,0.1)'
                            }
                        },
                        y1: {
                            beginAtZero: true,
                            position: 'right',
                            grid: {
                                drawOnChartArea: false
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    }
                }
            });
        }

        // Customer distribution chart
        const customerCtx = document.getElementById('customerChart');
        if (customerCtx) {
            const customerData = <?php echo json_encode($customer_distribution); ?>;
            
            new Chart(customerCtx, {
                type: 'doughnut',
                data: {
                    labels: customerData.map(item => item.customer_type.charAt(0).toUpperCase() + item.customer_type.slice(1)),
                    datasets: [{
                        data: customerData.map(item => item.count),
                        backgroundColor: ['#667eea', '#17a2b8', '#28a745', '#ffc107'],
                        borderWidth: 0,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 15,
                                usePointStyle: true,
                                font: {
                                    size: 11
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0,0,0,0.8)',
                            titleColor: 'white',
                            bodyColor: 'white',
                            cornerRadius: 10
                        }
                    }
                }
            });
        }

        // Animate counters
        function animateCounter(element, target) {
            let current = 0;
            const increment = target / 100;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                element.textContent = Math.floor(current).toLocaleString();
            }, 20);
        }

        // Initialize counter animations
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.animate-counter').forEach(counter => {
                const target = parseInt(counter.getAttribute('data-target'));
                counter.textContent = '0';
                setTimeout(() => animateCounter(counter, target), 500);
            });
        });

        // Activity filter functionality
        function filterActivity(status) {
            const items = document.querySelectorAll('#activityFeed .activity-item');
            items.forEach(item => {
                if (status === 'all' || item.getAttribute('data-status') === status) {
                    item.style.display = 'block';
                    item.style.animation = 'slideIn 0.5s ease-out';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        // View shipment details modal
        function viewShipmentDetails(trackingNumber) {
            const modal = document.createElement('div');
            modal.className = 'modal fade';
            modal.innerHTML = `
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                <i class="fas fa-box me-2"></i>
                                Shipment Details - ${trackingNumber}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="text-center">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <p class="mt-2">Loading shipment details...</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" onclick="window.open('shipments.php?track=${trackingNumber}', '_blank')">
                                <i class="fas fa-external-link-alt me-2"></i>View Full Details
                            </button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            const bootstrapModal = new bootstrap.Modal(modal);
            bootstrapModal.show();
            
            // Simulate loading and show details
            setTimeout(() => {
                modal.querySelector('.modal-body').innerHTML = `
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary">Shipment Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Tracking:</strong></td><td>${trackingNumber}</td></tr>
                                <tr><td><strong>Status:</strong></td><td><span class="badge bg-info">In Transit</span></td></tr>
                                <tr><td><strong>Service:</strong></td><td>Express Delivery</td></tr>
                                <tr><td><strong>Weight:</strong></td><td>2.5 kg</td></tr>
                                <tr><td><strong>Estimated Delivery:</strong></td><td>Tomorrow 2:00 PM</td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-primary">Status Timeline</h6>
                            <div class="timeline">
                                <div class="timeline-item">
                                    <small class="text-success"><i class="fas fa-check me-1"></i>Package picked up</small>
                                    <br><small class="text-muted">2 hours ago</small>
                                </div>
                                <div class="timeline-item">
                                    <small class="text-info"><i class="fas fa-truck me-1"></i>In transit to hub</small>
                                    <br><small class="text-muted">1 hour ago</small>
                                </div>
                                <div class="timeline-item">
                                    <small class="text-warning"><i class="fas fa-clock me-1"></i>Out for delivery</small>
                                    <br><small class="text-muted">Estimated: Tomorrow 2 PM</small>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }, 1500);
            
            // Cleanup modal when closed
            modal.addEventListener('hidden.bs.modal', () => {
                document.body.removeChild(modal);
            });
        }

        // Theme toggle functionality
        function toggleTheme() {
            const body = document.body;
            const themeIcon = document.getElementById('themeIcon');
            
            if (body.classList.contains('dark-theme')) {
                body.classList.remove('dark-theme');
                themeIcon.className = 'fas fa-moon';
                try {
                    localStorage.setItem('theme', 'light');
                } catch (e) {
                    console.log('localStorage not available');
                }
            } else {
                body.classList.add('dark-theme');
                themeIcon.className = 'fas fa-sun';
                try {
                    localStorage.setItem('theme', 'dark');
                } catch (e) {
                    console.log('localStorage not available');
                }
            }
        }

        // Initialize theme
        try {
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
                document.getElementById('themeIcon').className = 'fas fa-sun';
            }
        } catch (e) {
            console.log('localStorage not available');
        }

        // Full screen toggle
        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen();
            } else {
                document.exitFullscreen();
            }
        }

        // Notification system
        function showNotification(title, message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
            notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px; max-width: 400px;';
            notification.innerHTML = `
                <div class="d-flex align-items-center">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
                    <div>
                        <strong>${title}</strong>
                        <div>${message}</div>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            document.body.appendChild(notification);
            
            // Auto dismiss after 5 seconds
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 5000);
        }

        // Data export functionality
        function exportDashboardData() {
            const data = {
                timestamp: new Date().toISOString(),
                statistics: {
                    totalShipments: <?php echo $total_shipments; ?>,
                    totalRevenue: <?php echo $total_revenue; ?>,
                    activeCustomers: <?php echo $customers_count; ?>,
                    activeCouriers: <?php echo $couriers_count; ?>,
                    deliveredShipments: <?php echo $delivered_shipments; ?>,
                    pendingShipments: <?php echo $pending_shipments; ?>
                },
                todayStats: {
                    newShipments: <?php echo $today_shipments; ?>,
                    revenue: <?php echo $today_revenue; ?>,
                    newCustomers: <?php echo $today_customers; ?>
                },
                performance: {
                    avgDeliveryTime: <?php echo $avg_delivery_time; ?>,
                    successRate: <?php echo round((($delivered_shipments / max($total_shipments, 1)) * 100), 2); ?>
                }
            };
            
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `dashboard-export-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            showNotification('Export Complete', 'Dashboard data exported successfully', 'success');
        }

        // Refresh dashboard function
        function refreshDashboard() {
            showNotification('Refreshing...', 'Updating dashboard data', 'info');
            
            setTimeout(() => {
                location.reload();
            }, 1000);
        }

        // Mark all notifications as read
        function markAllRead() {
            showNotification('Notifications', 'All notifications marked as read', 'success');
        }

        // Help system
        function showHelp() {
            const helpModal = document.createElement('div');
            helpModal.className = 'modal fade';
            helpModal.innerHTML = `
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                <i class="fas fa-question-circle me-2"></i>
                                Dashboard Help & Shortcuts
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="text-primary">Navigation</h6>
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-tachometer-alt text-success me-2"></i>Dashboard Overview</li>
                                        <li><i class="fas fa-box text-info me-2"></i>Manage Shipments</li>
                                        <li><i class="fas fa-users text-warning me-2"></i>View Agents</li>
                                        <li><i class="fas fa-user-friends text-primary me-2"></i>Customer Management</li>
                                    </ul>
                                    
                                    <h6 class="text-primary mt-4">Quick Actions</h6>
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-plus text-success me-2"></i>Create new shipment</li>
                                        <li><i class="fas fa-user-plus text-info me-2"></i>Add customer</li>
                                        <li><i class="fas fa-download text-warning me-2"></i>Export data</li>
                                        <li><i class="fas fa-sync text-primary me-2"></i>Refresh dashboard</li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="text-primary">Dashboard Features</h6>
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-chart-line text-success me-2"></i>Real-time analytics</li>
                                        <li><i class="fas fa-bell text-warning me-2"></i>Live notifications</li>
                                        <li><i class="fas fa-tachometer-alt text-info me-2"></i>Performance metrics</li>
                                        <li><i class="fas fa-mobile-alt text-primary me-2"></i>Mobile responsive</li>
                                        <li><i class="fas fa-moon text-secondary me-2"></i>Dark/Light themes</li>
                                    </ul>
                                    
                                    <h6 class="text-primary mt-4">System Status</h6>
                                    <div class="alert alert-success">
                                        <i class="fas fa-check-circle me-2"></i>
                                        All systems operational
                                    </div>
                                    <small class="text-muted">
                                        Last updated: ${new Date().toLocaleString()}
                                    </small>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(helpModal);
            
            const modal = new bootstrap.Modal(helpModal);
            modal.show();
            
            helpModal.addEventListener('hidden.bs.modal', () => {
                document.body.removeChild(helpModal);
            });
        }

        // Initialize dashboard functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Add loading animation to page
            document.body.style.opacity = '0';
            document.body.style.transition = 'opacity 0.5s ease';
            
            setTimeout(() => {
                document.body.style.opacity = '1';
            }, 100);
            
            // Initialize tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            console.log('🚀 Enhanced Dashboard Fully Loaded!');
            console.log('📊 Features: Real-time updates, Interactive charts, Smart notifications');
            console.log('📱 Responsive: Mobile-friendly design');
        });

        // Auto-refresh dashboard data every 30 seconds
        setInterval(function() {
            // Subtle indication of data refresh
            const indicators = document.querySelectorAll('.stat-card');
            indicators.forEach((card, index) => {
                setTimeout(() => {
                    card.style.transform = 'scale(1.02)';
                    setTimeout(() => {
                        card.style.transform = 'scale(1)';
                    }, 200);
                }, index * 100);
            });
            
            console.log('Dashboard data refreshed at', new Date().toLocaleTimeString());
        }, 30000);

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
                        
            // Ctrl + B for sidebar toggle
            if (e.ctrlKey && e.key === 'b') {
                e.preventDefault();
                toggleSidebar();
            }
        });

        // Simulate real-time notifications
        setInterval(function() {
            const notifications = [
                { title: 'New Shipment', message: 'Shipment TRK' + Date.now().toString().slice(-6) + ' created', type: 'info' },
                { title: 'Delivery Complete', message: 'Package delivered successfully', type: 'success' },
                { title: 'Payment Received', message: 'Payment confirmed for recent order', type: 'success' }
            ];
            
            if (Math.random() > 0.85) { // 15% chance every interval
                const notification = notifications[Math.floor(Math.random() * notifications.length)];
                showNotification(notification.title, notification.message, notification.type);
            }
        }, 20000);

        // Add scroll-to-top button
        const scrollTopButton = document.createElement('button');
        scrollTopButton.innerHTML = '<i class="fas fa-arrow-up"></i>';
        scrollTopButton.className = 'btn btn-secondary rounded-circle position-fixed shadow-lg';
        scrollTopButton.style.cssText = `
            bottom: 20px; 
            right: 20px; 
            width: 50px; 
            height: 50px; 
            z-index: 1000; 
            display: none;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        `;
        scrollTopButton.onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
        scrollTopButton.title = 'Scroll to Top';
        document.body.appendChild(scrollTopButton);

        // Show/hide scroll-to-top button based on scroll position
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                scrollTopButton.style.display = 'block';
            } else {
                scrollTopButton.style.display = 'none';
            }
        });

        console.log('🌟 CourierPro Dashboard v2.1.0 - Fully Enhanced!');
        console.log('✨ Features loaded: Real-time data, Interactive charts, Smart notifications');
        console.log('🚀 Performance optimized for the best user experience');
    </script>

    <!-- Additional CSS for responsive design -->
    <style>
        /* Mobile responsive adjustments */
        @media (max-width: 768px) {
            .welcome-banner {
                text-align: center;
                padding: 20px;
            }
            
            .welcome-banner .col-md-4 {
                margin-top: 20px;
            }
            
            .navbar-custom {
                flex-direction: column;
                gap: 10px;
                padding: 10px 15px;
            }
            
            .navbar-custom .d-flex:first-child {
                width: 100%;
                justify-content: center;
            }
            
            .sidebar {
                transform: translateX(-100%);
                z-index: 1050;
            }
            
            .sidebar.show {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0 !important;
                padding: 10px;
            }
            
            .stat-card {
                margin-bottom: 15px;
                padding: 20px;
            }
            
            .chart-container {
                padding: 20px;
            }
            
            .performance-card {
                padding: 15px;
            }
        }
        
        /* Print styles */
        @media print {
            .sidebar,
            .floating-particles,
            button,
            .dropdown,
            .btn {
                display: none !important;
            }
            
            .main-content {
                margin-left: 0 !important;
            }
            
            .stat-card,
            .chart-container,
            .performance-card {
                break-inside: avoid;
                box-shadow: none;
                border: 1px solid #ddd;
            }
            
            .welcome-banner {
                background: #f8f9fa !important;
                color: #333 !important;
            }
        }
        
        /* Enhanced animations */
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        .floating-help-btn {
            animation: float 3s ease-in-out infinite;
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(45deg, #5a6fd8, #6a4190);
        }
        
        /* Loading states */
        .loading {
            position: relative;
            overflow: hidden;
        }
        
        .loading::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            animation: loading 1.5s infinite;
        }
        
        @keyframes loading {
            0% { left: -100%; }
            100% { left: 100%; }
        }
    </style>
</body>
</html>