<?php
require_once 'config/database.php';
requireLogin();

$database = new Database();
$db = $database->connect();

$admin_id = $_SESSION['admin_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setMessage('Invalid CSRF token', 'error');
    } else {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'update_profile':
                $full_name = sanitizeInput($_POST['full_name']);
                $username = sanitizeInput($_POST['username']);
                $email = sanitizeInput($_POST['email']);
                
                try {
                    // Check if username or email already exists (excluding current user)
                    $stmt = $db->prepare("SELECT COUNT(*) FROM admins WHERE (username = ? OR email = ?) AND id != ?");
                    $stmt->execute([$username, $email, $admin_id]);
                    
                    if ($stmt->fetchColumn() > 0) {
                        setMessage('Username or email already exists', 'error');
                    } else {
                        $stmt = $db->prepare("UPDATE admins SET full_name = ?, username = ?, email = ? WHERE id = ?");
                        $stmt->execute([$full_name, $username, $email, $admin_id]);
                        
                        // Update session variables
                        $_SESSION['full_name'] = $full_name;
                        $_SESSION['username'] = $username;
                        
                        setMessage('Profile updated successfully!');
                    }
                } catch (PDOException $e) {
                    setMessage('Error updating profile: ' . $e->getMessage(), 'error');
                }
                break;
                
            case 'change_password':
                $current_password = $_POST['current_password'];
                $new_password = $_POST['new_password'];
                $confirm_password = $_POST['confirm_password'];
                
                if ($new_password !== $confirm_password) {
                    setMessage('New passwords do not match', 'error');
                } elseif (strlen($new_password) < 6) {
                    setMessage('Password must be at least 6 characters long', 'error');
                } else {
                    try {
                        // Verify current password
                        $stmt = $db->prepare("SELECT password FROM admins WHERE id = ?");
                        $stmt->execute([$admin_id]);
                        $stored_password = $stmt->fetchColumn();
                        
                        if (password_verify($current_password, $stored_password)) {
                            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                            $stmt = $db->prepare("UPDATE admins SET password = ? WHERE id = ?");
                            $stmt->execute([$hashed_password, $admin_id]);
                            
                            setMessage('Password changed successfully!');
                        } else {
                            setMessage('Current password is incorrect', 'error');
                        }
                    } catch (PDOException $e) {
                        setMessage('Error changing password: ' . $e->getMessage(), 'error');
                    }
                }
                break;
        }
        
        header('Location: profile.php');
        exit();
    }
}

// Get current admin data
try {
    $stmt = $db->prepare("SELECT * FROM admins WHERE id = ?");
    $stmt->execute([$admin_id]);
    $admin = $stmt->fetch();
    
    // Get admin activity stats
    $login_history = $db->prepare("SELECT last_login, created_at FROM admins WHERE id = ?");
    $login_history->execute([$admin_id]);
    $login_data = $login_history->fetch();
    
} catch (PDOException $e) {
    $error = "Error fetching profile data: " . $e->getMessage();
}

$message = getMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Settings - Admin Panel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
   background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%), 
                linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
    background-blend-mode: overlay;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.sidebar {
    background: linear-gradient(180deg, #1e3a8a 0%, #4f46e5 100%);
    min-height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    z-index: 1000;
    transition: all 0.3s ease;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
}

.sidebar-item {
    color: rgba(255, 255, 255, 0.85);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.sidebar-item:hover,
.sidebar-item.active {
    color: white;
    background: rgba(255, 255, 255, 0.1);
    border-left-color: #3b82f6;
    transform: translateX(5px);
}

.sidebar h4 {
    font-size: 18px;   /* size chhota / bara karne ke liye */
    font-weight: 600;  /* boldness */
    color: #fff;       /* white hi rakho */
    margin: 0;         /* gap remove */
}

.main-content {
    margin-left: 250px;
    padding: 20px;
}

.content-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    padding: 30px;
    margin-bottom: 30px;
}

.navbar-custom {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    padding: 15px 30px;
    margin-bottom: 30px;
    border-radius: 15px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    z-index: 1050;
}
.navbar-custom h3,
.navbar-custom h5 {
    font-size: 1.2rem;      /* consistent size */
    font-weight: 600;       /* semi-bold clean look */
    color: #1e3a8a;         /* dashboard theme ka dark blue */
    margin: 0;              /* extra spacing hatao */
    letter-spacing: 0.5px;  /* thoda spacing for modern look */
}

.dropdown-menu {
    z-index: 2000; /* dropdown hamesha upar */
}

.profile-header {
    background: linear-gradient(135deg, #3b82f6 0%, #9333ea 100%);
    color: white;
    border-radius: 20px;
    padding: 40px;
    text-align: center;
    position: relative;
    overflow: hidden;
    margin-bottom: 30px;
}

.profile-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
    animation: rotate 15s linear infinite;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.profile-avatar {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    font-weight: bold;
    margin: 0 auto 20px;
    position: relative;
    z-index: 1;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

.profile-avatar:hover {
    transform: scale(1.05);
    transition: transform 0.3s ease;
}

.btn-gradient {
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    border: none;
    color: white;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn-gradient:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.4);
    color: white;
}

.btn-gradient::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s;
}

.btn-gradient:hover::before {
    left: 100%;
}

.form-control {
    border: 2px solid #e1e8ed;
    border-radius: 12px;
    padding: 15px 20px;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.9);
}

.form-control:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 0.3rem rgba(59, 130, 246, 0.15);
    transform: translateY(-2px);
    background: white;
}

.stats-card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    border-left: 4px solid;
}

.stats-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
}

.stats-card.role { border-left-color: #3b82f6; }
.stats-card.status { border-left-color: #10b981; }
.stats-card.login { border-left-color: #9333ea; }
.stats-card.member { border-left-color: #f59e0b; }

.animate-slide-in {
    animation: slideInUp 0.6s ease-out;
}

@keyframes slideInUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}

.tab-pane {
    animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.nav-pills .nav-link {
    border-radius: 12px;
    padding: 12px 20px;
    margin-right: 10px;
    transition: all 0.3s ease;
}

.nav-pills .nav-link.active {
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(59, 130, 246, 0.3);
}

.password-strength {
    height: 5px;
    border-radius: 3px;
    margin-top: 10px;
    transition: all 0.3s ease;
}

.password-strength.weak { background: #ef4444; width: 33%; }
.password-strength.medium { background: #f59e0b; width: 66%; }
.password-strength.strong { background: #10b981; width: 100%; }

    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-center border-bottom border-secondary">
            <h4 class="text-white mb-0">
                <i class="fas fa-user-cog me-2"></i>
                <span class="sidebar-text">Admin Panel</span>
            </h4>
        </div>
        
        <nav class="mt-3">
            <a href="dashboard.php" class="sidebar-item">
                <i class="fas fa-tachometer-alt me-3"></i>Dashboard
            </a>
            <a href="couriers.php" class="sidebar-item">
                <i class="fas fa-truck me-3"></i>Couriers
            </a>
            <a href="agents.php" class="sidebar-item">
                <i class="fas fa-users me-3"></i>Agents
            </a>
            <a href="customers.php" class="sidebar-item">
                <i class="fas fa-user-friends me-3"></i>Customers
            </a>
            <a href="shipments.php" class="sidebar-item">
                <i class="fas fa-box me-3"></i>Shipments
            </a>
            <a href="reports.php" class="sidebar-item">
                <i class="fas fa-chart-bar me-3"></i>Reports
            </a>
            <a href="logout.php" class="sidebar-item">
                <i class="fas fa-sign-out-alt me-3"></i>Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation -->
        <nav class="navbar-custom d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-user-cog me-2 text-primary"></i>Profile Settings</h5>
            <div class="d-flex align-items-center">
                <span class="me-3">Welcome, <?php echo $_SESSION['full_name']; ?></span>
                <div class="dropdown">
                    <button class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fas fa-user"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item active" href="profile.php"><i class="fas fa-user-cog me-2"></i>Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Alert Messages -->
        <?php if ($message): ?>
        <div class="alert alert-<?php echo $message['type'] === 'error' ? 'danger' : 'success'; ?> alert-dismissible fade show animate-slide-in" role="alert">
            <i class="fas fa-<?php echo $message['type'] === 'error' ? 'exclamation-triangle' : 'check-circle'; ?> me-2"></i>
            <?php echo $message['message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-avatar">
                <?php echo strtoupper(substr($admin['full_name'], 0, 1)); ?>
            </div>
            <h2 class="mb-2"><?php echo htmlspecialchars($admin['full_name']); ?></h2>
            <p class="mb-0 opacity-90">
                <i class="fas fa-crown me-2"></i>
                <?php echo ucfirst($admin['role']); ?> Administrator
            </p>
        </div>

        <!-- Profile Stats -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card role">
                    <i class="fas fa-user-shield fa-2x text-primary mb-3"></i>
                    <h5 class="mb-1"><?php echo ucfirst($admin['role']); ?></h5>
                    <small class="text-muted">Account Role</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card status">
                    <i class="fas fa-check-circle fa-2x text-success mb-3"></i>
                    <h5 class="mb-1"><?php echo ucfirst($admin['status']); ?></h5>
                    <small class="text-muted">Account Status</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card login">
                    <i class="fas fa-clock fa-2x text-info mb-3"></i>
                    <h5 class="mb-1"><?php echo $login_data['last_login'] ? formatDate($login_data['last_login'], 'M d, H:i') : 'Never'; ?></h5>
                    <small class="text-muted">Last Login</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card member">
                    <i class="fas fa-calendar-alt fa-2x text-warning mb-3"></i>
                    <h5 class="mb-1"><?php echo formatDate($login_data['created_at'], 'M Y'); ?></h5>
                    <small class="text-muted">Member Since</small>
                </div>
            </div>
        </div>

        <!-- Profile Management Tabs -->
        <div class="content-card">
            <ul class="nav nav-pills mb-4" id="profileTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="profile-tab" data-bs-toggle="pill" data-bs-target="#profile" type="button" role="tab">
                        <i class="fas fa-user me-2"></i>Profile Information
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="password-tab" data-bs-toggle="pill" data-bs-target="#password" type="button" role="tab">
                        <i class="fas fa-lock me-2"></i>Change Password
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="activity-tab" data-bs-toggle="pill" data-bs-target="#activity" type="button" role="tab">
                        <i class="fas fa-history me-2"></i>Account Activity
                    </button>
                </li>
            </ul>

            <div class="tab-content" id="profileTabsContent">
                <!-- Profile Information Tab -->
                <div class="tab-pane fade show active" id="profile" role="tabpanel">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="update_profile">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label for="full_name" class="form-label">
                                    <i class="fas fa-user me-2 text-primary"></i>Full Name *
                                </label>
                                <input type="text" class="form-control" id="full_name" name="full_name" 
                                       value="<?php echo htmlspecialchars($admin['full_name']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label for="username" class="form-label">
                                    <i class="fas fa-at me-2 text-primary"></i>Username *
                                </label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="<?php echo htmlspecialchars($admin['username']); ?>" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope me-2 text-primary"></i>Email Address *
                                </label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo htmlspecialchars($admin['email']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label class="form-label">
                                    <i class="fas fa-crown me-2 text-primary"></i>Role
                                </label>
                                <input type="text" class="form-control" value="<?php echo ucfirst($admin['role']); ?>" readonly>
                                <small class="text-muted">Contact super admin to change role</small>
                            </div>
                        </div>
                        
                        <div class="text-end">
                            <button type="submit" class="btn btn-gradient btn-lg">
                                <i class="fas fa-save me-2"></i>Update Profile
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Change Password Tab -->
                <div class="tab-pane fade" id="password" role="tabpanel">
                    <form method="POST" action="" id="passwordForm">
                        <input type="hidden" name="action" value="change_password">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="mb-4">
                            <label for="current_password" class="form-label">
                                <i class="fas fa-key me-2 text-primary"></i>Current Password *
                            </label>
                            <div class="position-relative">
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                                <button type="button" class="btn btn-outline-secondary position-absolute top-50 end-0 translate-middle-y me-2" onclick="togglePassword('current_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="new_password" class="form-label">
                                <i class="fas fa-lock me-2 text-primary"></i>New Password *
                            </label>
                            <div class="position-relative">
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                <button type="button" class="btn btn-outline-secondary position-absolute top-50 end-0 translate-middle-y me-2" onclick="togglePassword('new_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="password-strength" id="passwordStrength"></div>
                            <small class="text-muted">Password must be at least 6 characters long</small>
                        </div>
                        
                        <div class="mb-4">
                            <label for="confirm_password" class="form-label">
                                <i class="fas fa-check-double me-2 text-primary"></i>Confirm New Password *
                            </label>
                            <div class="position-relative">
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                <button type="button" class="btn btn-outline-secondary position-absolute top-50 end-0 translate-middle-y me-2" onclick="togglePassword('confirm_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div id="passwordMatch" class="mt-2"></div>
                        </div>
                        
                        <div class="text-end">
                            <button type="submit" class="btn btn-gradient btn-lg" id="changePasswordBtn" disabled>
                                <i class="fas fa-shield-alt me-2"></i>Change Password
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Account Activity Tab -->
                <div class="tab-pane fade" id="activity" role="tabpanel">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary mb-3">Account Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td><i class="fas fa-user text-primary me-2"></i><strong>Admin ID:</strong></td>
                                    <td><?php echo $admin['id']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-calendar-plus text-success me-2"></i><strong>Created:</strong></td>
                                    <td><?php echo formatDate($admin['created_at'], 'M d, Y H:i'); ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-edit text-warning me-2"></i><strong>Last Updated:</strong></td>
                                    <td><?php echo formatDate($admin['updated_at'], 'M d, Y H:i'); ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-sign-in-alt text-info me-2"></i><strong>Last Login:</strong></td>
                                    <td><?php echo $admin['last_login'] ? formatDate($admin['last_login'], 'M d, Y H:i') : 'Never'; ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-primary mb-3">Security Information</h6>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Security Tips:</strong>
                                <ul class="mt-2 mb-0">
                                    <li>Use a strong, unique password</li>
                                    <li>Change your password regularly</li>
                                    <li>Never share your login credentials</li>
                                    <li>Always logout when finished</li>
                                </ul>
                            </div>
                            
                            <div class="mt-4">
                                <h6 class="text-primary">Quick Actions</h6>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary" onclick="generateStrongPassword()">
                                        <i class="fas fa-magic me-2"></i>Generate Strong Password
                                    </button>
                                    <button class="btn btn-outline-warning" onclick="clearBrowserData()">
                                        <i class="fas fa-broom me-2"></i>Clear Browser Data
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const button = field.nextElementSibling.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                button.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                field.type = 'password';
                button.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        // Password strength checker
        function checkPasswordStrength(password) {
            const strengthBar = document.getElementById('passwordStrength');
            let strength = 0;
            
            if (password.length >= 6) strength++;
            if (password.match(/[a-z]+/)) strength++;
            if (password.match(/[A-Z]+/)) strength++;
            if (password.match(/[0-9]+/)) strength++;
            if (password.match(/[$@#&!]+/)) strength++;
            
            strengthBar.className = 'password-strength';
            if (strength < 3) {
                strengthBar.classList.add('weak');
            } else if (strength < 5) {
                strengthBar.classList.add('medium');
            } else {
                strengthBar.classList.add('strong');
            }
            
            return strength;
        }

        // Password matching checker
        function checkPasswordMatch() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const matchDiv = document.getElementById('passwordMatch');
            const submitBtn = document.getElementById('changePasswordBtn');
            
            if (confirmPassword.length > 0) {
                if (newPassword === confirmPassword) {
                    matchDiv.innerHTML = '<small class="text-success"><i class="fas fa-check me-1"></i>Passwords match</small>';
                    submitBtn.disabled = false;
                } else {
                    matchDiv.innerHTML = '<small class="text-danger"><i class="fas fa-times me-1"></i>Passwords do not match</small>';
                    submitBtn.disabled = true;
                }
            } else {
                matchDiv.innerHTML = '';
                submitBtn.disabled = true;
            }
        }

        // Generate strong password
        function generateStrongPassword() {
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$&!';
            let password = '';
            
            for (let i = 0; i < 12; i++) {
                password += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            
            document.getElementById('new_password').value = password;
            document.getElementById('confirm_password').value = password;
            
            checkPasswordStrength(password);
            checkPasswordMatch();
            
            // Show password temporarily
            document.getElementById('new_password').type = 'text';
            document.getElementById('confirm_password').type = 'text';
            
            setTimeout(() => {
                document.getElementById('new_password').type = 'password';
                document.getElementById('confirm_password').type = 'password';
            }, 3000);
            
            // Show success message
            const alert = document.createElement('div');
            alert.className = 'alert alert-success alert-dismissible fade show mt-3';
            alert.innerHTML = `
                <i class="fas fa-check-circle me-2"></i>
                Strong password generated! It will be hidden in 3 seconds.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.getElementById('password').insertBefore(alert, document.getElementById('passwordForm'));
            
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 5000);
        }

        // Clear browser data
        function clearBrowserData() {
            if (confirm('This will clear your browser\'s stored data for this site. Continue?')) {
                localStorage.clear();
                sessionStorage.clear();
                
                // Show success message
                const alert = document.createElement('div');
                alert.className = 'alert alert-success alert-dismissible fade show';
                alert.innerHTML = `
                    <i class="fas fa-check-circle me-2"></i>
                    Browser data cleared successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                document.querySelector('.main-content').insertBefore(alert, document.querySelector('.profile-header'));
                
                setTimeout(() => {
                    if (alert.parentNode) {
                        alert.remove();
                    }
                }, 3000);
            }
        }

        // Event listeners
        document.getElementById('new_password').addEventListener('input', function() {
            checkPasswordStrength(this.value);
            checkPasswordMatch();
        });

        document.getElementById('confirm_password').addEventListener('input', checkPasswordMatch);

        // Form animations
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 5px 15px rgba(102, 126, 234, 0.2)';
            });
            
            input.addEventListener('blur', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            });
        });

        // Profile form validation
        document.querySelector('#profile form').addEventListener('submit', function(e) {
            const fullName = document.getElementById('full_name').value.trim();
            const username = document.getElementById('username').value.trim();
            const email = document.getElementById('email').value.trim();
            
            if (!fullName || !username || !email) {
                e.preventDefault();
                
                const alert = document.createElement('div');
                alert.className = 'alert alert-danger alert-dismissible fade show';
                alert.innerHTML = `
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Please fill in all required fields.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                this.insertBefore(alert, this.firstChild);
                
                setTimeout(() => {
                    if (alert.parentNode) {
                        alert.remove();
                    }
                }, 5000);
            }
        });

        // Password form validation
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            const currentPassword = document.getElementById('current_password').value;
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (!currentPassword || !newPassword || !confirmPassword) {
                e.preventDefault();
                
                const alert = document.createElement('div');
                alert.className = 'alert alert-danger alert-dismissible fade show';
                alert.innerHTML = `
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Please fill in all password fields.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                this.insertBefore(alert, this.firstChild);
                
                setTimeout(() => {
                    if (alert.parentNode) {
                        alert.remove();
                    }
                }, 5000);
                return;
            }
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                
                const alert = document.createElement('div');
                alert.className = 'alert alert-danger alert-dismissible fade show';
                alert.innerHTML = `
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    New passwords do not match.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                this.insertBefore(alert, this.firstChild);
                
                setTimeout(() => {
                    if (alert.parentNode) {
                        alert.remove();
                    }
                }, 5000);
                return;
            }
            
            if (newPassword.length < 6) {
                e.preventDefault();
                
                const alert = document.createElement('div');
                alert.className = 'alert alert-danger alert-dismissible fade show';
                alert.innerHTML = `
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Password must be at least 6 characters long.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                this.insertBefore(alert, this.firstChild);
                
                setTimeout(() => {
                    if (alert.parentNode) {
                        alert.remove();
                    }
                }, 5000);
            }
        });

        // Animate profile stats on load
        document.addEventListener('DOMContentLoaded', function() {
            const statsCards = document.querySelectorAll('.stats-card');
            statsCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });

        // Tab switching animation
        document.querySelectorAll('#profileTabs button').forEach(button => {
            button.addEventListener('click', function() {
                // Add loading effect
                const tabPane = document.querySelector(this.getAttribute('data-bs-target'));
                if (tabPane) {
                    tabPane.style.opacity = '0.5';
                    setTimeout(() => {
                        tabPane.style.opacity = '1';
                    }, 150);
                }
            });
        });

        // Real-time username availability check (simulated)
        let usernameTimeout;
        document.getElementById('username').addEventListener('input', function() {
            clearTimeout(usernameTimeout);
            const username = this.value.trim();
            
            if (username.length >= 3) {
                usernameTimeout = setTimeout(() => {
                    // Simulate availability check
                    const feedback = document.createElement('small');
                    feedback.className = 'text-success';
                    feedback.innerHTML = '<i class="fas fa-check me-1"></i>Username available';
                    
                    // Remove existing feedback
                    const existing = this.parentNode.querySelector('small');
                    if (existing) existing.remove();
                    
                    this.parentNode.appendChild(feedback);
                }, 500);
            }
        });

        // Email validation
        document.getElementById('email').addEventListener('blur', function() {
            const email = this.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            // Remove existing feedback
            const existing = this.parentNode.querySelector('small');
            if (existing) existing.remove();
            
            if (email && !emailRegex.test(email)) {
                const feedback = document.createElement('small');
                feedback.className = 'text-danger';
                feedback.innerHTML = '<i class="fas fa-times me-1"></i>Please enter a valid email address';
                this.parentNode.appendChild(feedback);
                this.classList.add('is-invalid');
            } else if (email) {
                const feedback = document.createElement('small');
                feedback.className = 'text-success';
                feedback.innerHTML = '<i class="fas fa-check me-1"></i>Email format is valid';
                this.parentNode.appendChild(feedback);
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        });

        // Auto-save profile changes (draft)
        let autoSaveTimeout;
        ['full_name', 'username', 'email'].forEach(fieldId => {
            document.getElementById(fieldId).addEventListener('input', function() {
                clearTimeout(autoSaveTimeout);
                autoSaveTimeout = setTimeout(() => {
                    // Save to localStorage as draft
                    localStorage.setItem('profile_draft_' + fieldId, this.value);
                    
                    // Show auto-save indicator
                    let indicator = document.getElementById('autoSaveIndicator');
                    if (!indicator) {
                        indicator = document.createElement('small');
                        indicator.id = 'autoSaveIndicator';
                        indicator.className = 'text-muted';
                        document.querySelector('#profile .text-end').insertBefore(indicator, document.querySelector('#profile .btn'));
                    }
                    indicator.innerHTML = '<i class="fas fa-cloud me-1"></i>Draft saved';
                    
                    setTimeout(() => {
                        if (indicator) indicator.innerHTML = '';
                    }, 2000);
                }, 1000);
            });
        });

        // Restore draft on page load
        document.addEventListener('DOMContentLoaded', function() {
            ['full_name', 'username', 'email'].forEach(fieldId => {
                const draft = localStorage.getItem('profile_draft_' + fieldId);
                if (draft && draft !== document.getElementById(fieldId).value) {
                    // Show restore option
                    const restoreBtn = document.createElement('button');
                    restoreBtn.type = 'button';
                    restoreBtn.className = 'btn btn-sm btn-outline-info ms-2';
                    restoreBtn.innerHTML = '<i class="fas fa-undo me-1"></i>Restore';
                    restoreBtn.onclick = function() {
                        document.getElementById(fieldId).value = draft;
                        this.remove();
                    };
                    
                    document.getElementById(fieldId).parentNode.appendChild(restoreBtn);
                }
            });
        });

        // Clear drafts on successful form submission
        document.querySelector('#profile form').addEventListener('submit', function() {
            ['full_name', 'username', 'email'].forEach(fieldId => {
                localStorage.removeItem('profile_draft_' + fieldId);
            });
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + S to save profile
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                const activeTab = document.querySelector('.tab-pane.show.active');
                const form = activeTab.querySelector('form');
                if (form) {
                    form.requestSubmit();
                }
            }
            
            // Ctrl/Cmd + G to generate password
            if ((e.ctrlKey || e.metaKey) && e.key === 'g' && document.querySelector('#password-tab').classList.contains('active')) {
                e.preventDefault();
                generateStrongPassword();
            }
        });

        // Show keyboard shortcuts help
        function showKeyboardShortcuts() {
            const modal = new bootstrap.Modal(document.createElement('div'));
            // Implementation would go here
        }

        // Profile completion indicator
        function updateProfileCompletion() {
            const fields = ['full_name', 'username', 'email'];
            let completed = 0;
            
            fields.forEach(fieldId => {
                if (document.getElementById(fieldId).value.trim()) {
                    completed++;
                }
            });
            
            const percentage = Math.round((completed / fields.length) * 100);
            
            // Update profile completion indicator if it exists
            let indicator = document.getElementById('profileCompletion');
            if (!indicator) {
                indicator = document.createElement('div');
                indicator.id = 'profileCompletion';
                indicator.className = 'mt-3 text-center';
                document.querySelector('.profile-header').appendChild(indicator);
            }
            
            indicator.innerHTML = `
                <small class="text-white opacity-75">Profile Completion: ${percentage}%</small>
                <div class="progress mt-1" style="height: 4px;">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: ${percentage}%"></div>
                </div>
            `;
        }

        // Update completion on field changes
        ['full_name', 'username', 'email'].forEach(fieldId => {
            document.getElementById(fieldId).addEventListener('input', updateProfileCompletion);
        });

        // Initialize profile completion on load
        document.addEventListener('DOMContentLoaded', updateProfileCompletion);

        console.log('Profile Management System Loaded Successfully');
    </script>
</body>
</html>