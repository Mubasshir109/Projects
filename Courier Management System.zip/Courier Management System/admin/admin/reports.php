<?php
require_once 'config/database.php';
requireLogin();

$database = new Database();
$db = $database->connect();

// Handle CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $type = $_GET['type'] ?? 'shipments';
    $filename = $type . '_report_' . date('Y-m-d') . '.csv';
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    switch ($type) {
        case 'shipments':
            fputcsv($output, ['Tracking Number', 'Customer', 'Agent', 'Courier', 'Status', 'Total Cost', 'Created Date']);
            $stmt = $db->query("
                SELECT s.tracking_number, c.full_name as customer, a.full_name as agent, 
                       co.courier_name, s.shipment_status, s.total_cost, s.created_at
                FROM shipments s
                JOIN customers c ON s.customer_id = c.id
                JOIN agents a ON s.agent_id = a.id
                JOIN couriers co ON s.courier_id = co.id
                ORDER BY s.created_at DESC
            ");
            while ($row = $stmt->fetch()) {
                fputcsv($output, [
                    $row['tracking_number'],
                    $row['customer'],
                    $row['agent'],
                    $row['courier_name'],
                    $row['shipment_status'],
                    $row['total_cost'],
                    $row['created_at']
                ]);
            }
            break;
            
        case 'customers':
            fputcsv($output, ['Customer Code', 'Full Name', 'Email', 'Phone', 'Type', 'City', 'Status', 'Registration Date']);
            $stmt = $db->query("SELECT * FROM customers ORDER BY created_at DESC");
            while ($row = $stmt->fetch()) {
                fputcsv($output, [
                    $row['customer_code'],
                    $row['full_name'],
                    $row['email'],
                    $row['phone'],
                    $row['customer_type'],
                    $row['city'],
                    $row['status'],
                    $row['registration_date']
                ]);
            }
            break;
            
        case 'revenue':
            fputcsv($output, ['Date', 'Total Revenue', 'Shipments Count', 'Average Value']);
            $stmt = $db->query("
                SELECT DATE(created_at) as date, 
                       SUM(total_cost) as revenue, 
                       COUNT(*) as shipments,
                       AVG(total_cost) as avg_value
                FROM shipments 
                WHERE payment_status = 'paid'
                GROUP BY DATE(created_at) 
                ORDER BY date DESC
            ");
            while ($row = $stmt->fetch()) {
                fputcsv($output, [
                    $row['date'],
                    $row['revenue'],
                    $row['shipments'],
                    number_format($row['avg_value'], 2)
                ]);
            }
            break;
    }
    
    fclose($output);
    exit();
}

// Get report data
try {
    // Shipment statistics
    $total_shipments = $db->query("SELECT COUNT(*) FROM shipments")->fetchColumn();
    $pending_shipments = $db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'pending'")->fetchColumn();
    $in_transit_shipments = $db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'in_transit'")->fetchColumn();
    $delivered_shipments = $db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'delivered'")->fetchColumn();
    
    // Revenue statistics
    $total_revenue = $db->query("SELECT SUM(total_cost) FROM shipments WHERE payment_status = 'paid'")->fetchColumn() ?? 0;
    $monthly_revenue = $db->query("SELECT SUM(total_cost) FROM shipments WHERE payment_status = 'paid' AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())")->fetchColumn() ?? 0;
    
    // Top performing agents
    $top_agents = $db->query("
        SELECT a.full_name, a.agent_code, COUNT(s.id) as shipments_count, SUM(s.total_cost) as total_revenue
        FROM agents a
        LEFT JOIN shipments s ON a.id = s.agent_id
        WHERE a.status = 'active'
        GROUP BY a.id
        ORDER BY shipments_count DESC
        LIMIT 5
    ")->fetchAll();
    
    // Top customers
    $top_customers = $db->query("
        SELECT c.full_name, c.customer_code, COUNT(s.id) as shipments_count, SUM(s.total_cost) as total_spent
        FROM customers c
        LEFT JOIN shipments s ON c.id = s.customer_id
        WHERE c.status = 'active'
        GROUP BY c.id
        ORDER BY shipments_count DESC
        LIMIT 5
    ")->fetchAll();
    
    // Monthly revenue data for chart
    $monthly_data = $db->query("
        SELECT MONTH(created_at) as month, YEAR(created_at) as year, 
               SUM(total_cost) as revenue, COUNT(*) as shipments
        FROM shipments 
        WHERE payment_status = 'paid' AND created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
        GROUP BY YEAR(created_at), MONTH(created_at) 
        ORDER BY year DESC, month DESC
        LIMIT 12
    ")->fetchAll();
    
    // Courier performance
    $courier_performance = $db->query("
        SELECT co.courier_name, COUNT(s.id) as shipments_count, 
               SUM(CASE WHEN s.shipment_status = 'delivered' THEN 1 ELSE 0 END) as delivered_count,
               ROUND((SUM(CASE WHEN s.shipment_status = 'delivered' THEN 1 ELSE 0 END) / COUNT(s.id)) * 100, 2) as success_rate
        FROM couriers co
        LEFT JOIN shipments s ON co.id = s.courier_id
        WHERE co.status = 'active'
        GROUP BY co.id
        ORDER BY success_rate DESC
    ")->fetchAll();
    
} catch (PDOException $e) {
    $error = "Error fetching report data: " . $e->getMessage();
}

$message = getMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - Admin Panel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
       body {
   background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%), 
                linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
    background-blend-mode: overlay;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.sidebar {
    background: linear-gradient(180deg, #1e3a8a 0%, #4f46e5 100%);
    min-height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    z-index: 1000;
    transition: all 0.3s ease;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
}

.sidebar-item {
    color: rgba(255, 255, 255, 0.85);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.sidebar-item:hover,
.sidebar-item.active {
    color: white;
    background: rgba(255, 255, 255, 0.1);
    border-left-color: #3b82f6;
    transform: translateX(5px);
}

.sidebar h4 {
    font-size: 18px;   /* size chhota / bara karne ke liye */
    font-weight: 600;  /* boldness */
    color: #fff;       /* white hi rakho */
    margin: 0;         /* gap remove */
}


.main-content {
    margin-left: 250px;
    padding: 20px;
}

.content-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    padding: 30px;
    margin-bottom: 30px;
}

.navbar-custom {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    padding: 15px 30px;
    margin-bottom: 30px;
    border-radius: 15px;
    border: 1px solid rgba(255, 255, 255, 0.2);
}
.navbar-custom h3,
.navbar-custom h5 {
    font-size: 1.2rem;      /* consistent size */
    font-weight: 600;       /* semi-bold clean look */
    color: #1e3a8a;         /* dashboard theme ka dark blue */
    margin: 0;              /* extra spacing hatao */
    letter-spacing: 0.5px;  /* thoda spacing for modern look */
}


.stat-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 20px;
    padding: 30px;
    text-align: center;
    position: relative;
    overflow: hidden;
    transition: transform 0.3s ease;
}

.stats-card {
    background: linear-gradient(135deg, #3b82f6 0%, #9333ea 100%);
    color: white;
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
}
.stats-card::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
    animation: rotate 15s linear infinite;
}
@keyframes rotate {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
}

.chart-container {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    margin-bottom: 30px;
}

.btn-download {
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    border: none;
    color: white;
    padding: 12px 25px;
    border-radius: 25px;
    transition: all 0.3s ease;
}

.btn-download:hover {
    transform: translateY(-3px);
    color: white;
}

.table-modern {
    border-collapse: separate;
    border-spacing: 0;
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
}

.table-modern th {
    background: linear-gradient(45deg, #667eea, #764ba2);
    color: white;
    border: none;
    padding: 20px 15px;
    font-weight: 600;
}

.table-modern td {
    border: none;
    padding: 15px;
    border-bottom: 1px solid #f1f3f4;
    vertical-align: middle;
}

.table-modern tr:hover {
    background: linear-gradient(45deg, #f8f9ff, #fff5f5);
}

.performance-bar {
    height: 10px;
    border-radius: 5px;
    background: #e9ecef;
    overflow: hidden;
}

.performance-fill {
    height: 100%;
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    transition: width 0.5s ease;
}
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-center border-bottom border-secondary">
            <h4 class="text-white mb-0">
    <i class="fas fa-chart-bar me-2"></i> 
     <span class="sidebar-text">Admin Panel</span>
</h4>

        </div>
        
        <nav class="mt-3">
            <a href="dashboard.php" class="sidebar-item">
                <i class="fas fa-tachometer-alt me-3"></i>Dashboard
            </a>
            <a href="couriers.php" class="sidebar-item">
                <i class="fas fa-truck me-3"></i>Couriers
            </a>
            <a href="agents.php" class="sidebar-item">
                <i class="fas fa-users me-3"></i>Agents
            </a>
            <a href="customers.php" class="sidebar-item">
                <i class="fas fa-user-friends me-3"></i>Customers
            </a>
            <a href="shipments.php" class="sidebar-item">
                <i class="fas fa-box me-3"></i>Shipments
            </a>
            <a href="reports.php" class="sidebar-item active">
                <i class="fas fa-chart-bar me-3"></i>Reports
            </a>
            <a href="logout.php" class="sidebar-item">
                <i class="fas fa-sign-out-alt me-3"></i>Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation -->
        <nav class="navbar-custom d-flex justify-content-between align-items-center" style="position: relative; z-index: 2000;">
    <h5 class="mb-0"><i class="fas fa-chart-bar me-2 text-primary"></i>Reports & Analytics</h5>
    <div class="d-flex align-items-center">
        <div class="dropdown me-3">
            <button class="btn btn-download dropdown-toggle" data-bs-toggle="dropdown">
                <i class="fas fa-download me-2"></i>Export Reports
            </button>
            <ul class="dropdown-menu" style="z-index: 3000;">
                <li><a class="dropdown-item" href="?export=csv&type=shipments">
                    <i class="fas fa-box me-2"></i>Shipments Report
                </a></li>
                <li><a class="dropdown-item" href="?export=csv&type=customers">
                    <i class="fas fa-users me-2"></i>Customers Report
                </a></li>
                <li><a class="dropdown-item" href="?export=csv&type=revenue">
                    <i class="fas fa-dollar-sign me-2"></i>Revenue Report
                </a></li>
            </ul>
        </div>
        <span class="me-3">Welcome, <?php echo $_SESSION['full_name']; ?></span>
        <div class="dropdown">
            <button class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                <i class="fas fa-user"></i>
            </button>
            <ul class="dropdown-menu" style="z-index: 3000;">
                <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-cog me-2"></i>Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
            </ul>
        </div>
    </div>
</nav>


        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <i class="fas fa-box-open fa-3x mb-3"></i>
                    <h3><?php echo number_format($total_shipments); ?></h3>
                    <p class="mb-0 opacity-90">Total Shipments</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <i class="fas fa-clock fa-3x mb-3"></i>
                    <h3><?php echo number_format($pending_shipments); ?></h3>
                    <p class="mb-0 opacity-90">Pending Shipments</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <i class="fas fa-check-circle fa-3x mb-3"></i>
                    <h3><?php echo number_format($delivered_shipments); ?></h3>
                    <p class="mb-0 opacity-90">Delivered Shipments</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <i class="fas fa-dollar-sign fa-3x mb-3"></i>
                    <h3><?php echo formatCurrency($total_revenue); ?></h3>
                    <p class="mb-0 opacity-90">Total Revenue</p>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="row">
            <div class="col-lg-8 mb-4">
                <div class="chart-container">
                    <h5 class="mb-4"><i class="fas fa-chart-line me-2 text-primary"></i>Monthly Revenue Trend</h5>
                    <canvas id="revenueChart" height="100"></canvas>
                </div>
            </div>
            <div class="col-lg-4 mb-4">
                <div class="chart-container">
                    <h5 class="mb-4"><i class="fas fa-chart-pie me-2 text-primary"></i>Shipment Status</h5>
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Performance Tables -->
        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="content-card">
                    <h5 class="mb-4"><i class="fas fa-star me-2 text-warning"></i>Top Performing Agents</h5>
                    <div class="table-responsive">
                        <table class="table table-modern">
                            <thead>
                                <tr>
                                    <th>Agent</th>
                                    <th>Shipments</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_agents as $agent): ?>
                                <tr>
                                    <td>
                                        <div>
                                            <strong><?php echo htmlspecialchars($agent['full_name']); ?></strong><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($agent['agent_code']); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary"><?php echo number_format($agent['shipments_count']); ?></span>
                                    </td>
                                    <td>
                                        <strong class="text-success"><?php echo formatCurrency($agent['total_revenue'] ?? 0); ?></strong>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 mb-4">
                <div class="content-card">
                    <h5 class="mb-4"><i class="fas fa-user-crown me-2 text-info"></i>Top Customers</h5>
                    <div class="table-responsive">
                        <table class="table table-modern">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Shipments</th>
                                    <th>Total Spent</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_customers as $customer): ?>
                                <tr>
                                    <td>
                                        <div>
                                            <strong><?php echo htmlspecialchars($customer['full_name']); ?></strong><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($customer['customer_code']); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-info"><?php echo number_format($customer['shipments_count']); ?></span>
                                    </td>
                                    <td>
                                        <strong class="text-success"><?php echo formatCurrency($customer['total_spent'] ?? 0); ?></strong>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Courier Performance -->
        <div class="content-card">
            <h5 class="mb-4"><i class="fas fa-truck me-2 text-primary"></i>Courier Performance Analysis</h5>
            <div class="table-responsive">
                <table class="table table-modern">
                    <thead>
                        <tr>
                            <th>Courier</th>
                            <th>Total Shipments</th>
                            <th>Delivered</th>
                            <th>Success Rate</th>
                            <th>Performance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($courier_performance as $courier): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                        <i class="fas fa-truck"></i>
                                    </div>
                                    <strong><?php echo htmlspecialchars($courier['courier_name']); ?></strong>
                                </div>
                            </td>
                            <td><span class="badge bg-info fs-6"><?php echo number_format($courier['shipments_count']); ?></span></td>
                            <td><span class="badge bg-success fs-6"><?php echo number_format($courier['delivered_count']); ?></span></td>
                            <td><strong class="text-<?php echo $courier['success_rate'] >= 80 ? 'success' : ($courier['success_rate'] >= 60 ? 'warning' : 'danger'); ?>"><?php echo $courier['success_rate']; ?>%</strong></td>
                            <td>
                                <div class="performance-bar">
                                    <div class="performance-fill" style="width: <?php echo $courier['success_rate']; ?>%"></div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Quick Stats Grid -->
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="content-card text-center">
                    <i class="fas fa-shipping-fast fa-3x text-primary mb-3"></i>
                    <h4><?php echo number_format($in_transit_shipments); ?></h4>
                    <p class="text-muted mb-0">In Transit</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="content-card text-center">
                    <i class="fas fa-calendar-check fa-3x text-success mb-3"></i>
                    <h4><?php echo formatCurrency($monthly_revenue); ?></h4>
                    <p class="text-muted mb-0">This Month's Revenue</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="content-card text-center">
                    <i class="fas fa-percentage fa-3x text-warning mb-3"></i>
                    <h4><?php echo $total_shipments > 0 ? number_format(($delivered_shipments / $total_shipments) * 100, 1) : 0; ?>%</h4>
                    <p class="text-muted mb-0">Delivery Success Rate</p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Revenue Chart
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        const monthlyData = <?php echo json_encode(array_reverse($monthly_data)); ?>;
        
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: monthlyData.map(item => {
                    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                    return months[item.month - 1] + ' ' + item.year;
                }),
                datasets: [{
                    label: 'Revenue (PKR)',
                    data: monthlyData.map(item => item.revenue),
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#667eea',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'PKR ' + value.toLocaleString();
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });

        // Status Chart
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Pending', 'In Transit', 'Delivered', 'Others'],
                datasets: [{
                    data: [
                        <?php echo $pending_shipments; ?>,
                        <?php echo $in_transit_shipments; ?>,
                        <?php echo $delivered_shipments; ?>,
                        <?php echo $total_shipments - $pending_shipments - $in_transit_shipments - $delivered_shipments; ?>
                    ],
                    backgroundColor: ['#ffc107', '#17a2b8', '#28a745', '#6c757d'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });

        // Animate performance bars
        document.addEventListener('DOMContentLoaded', function() {
            const performanceBars = document.querySelectorAll('.performance-fill');
            performanceBars.forEach((bar, index) => {
                setTimeout(() => {
                    bar.style.transition = 'width 1s ease-out';
                    const width = bar.style.width;
                    bar.style.width = '0%';
                    setTimeout(() => {
                        bar.style.width = width;
                    }, 100);
                }, index * 200);
            });
        });

        // Animate stat cards
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'all 0.6s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 150);
        });
    </script>
</body>
</html>