<?php
/**
 * MySQL Queries Collection for Admin Panel
 * Contains all database operations organized by module
 */

class AdminQueries {
    private $db;
    
    public function __construct($database_connection) {
        $this->db = $database_connection;
    }
    
    // ====================
    // ADMIN AUTHENTICATION
    // ====================
    
    public function authenticateAdmin($username) {
        $stmt = $this->db->prepare("
            SELECT id, username, password, full_name, role, status 
            FROM admins 
            WHERE username = ? AND status = 'active'
        ");
        $stmt->execute([$username]);
        return $stmt->fetch();
    }
    
    public function updateLastLogin($admin_id) {
        $stmt = $this->db->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?");
        return $stmt->execute([$admin_id]);
    }
    
    public function createAdmin($data) {
        $stmt = $this->db->prepare("
            INSERT INTO admins (username, email, password, full_name, role) 
            VALUES (?, ?, ?, ?, ?)
        ");
        return $stmt->execute([
            $data['username'], $data['email'], $data['password'], 
            $data['full_name'], $data['role']
        ]);
    }
    
    // ====================
    // COURIER MANAGEMENT
    // ====================
    
    public function getAllCouriers() {
        return $this->db->query("SELECT * FROM couriers ORDER BY created_at DESC")->fetchAll();
    }
    
    public function getActiveCouriers() {
        return $this->db->query("SELECT * FROM couriers WHERE status = 'active' ORDER BY courier_name")->fetchAll();
    }
    
    public function addCourier($data) {
        $stmt = $this->db->prepare("
            INSERT INTO couriers (courier_name, contact_person, phone, email, address, city, state, postal_code, tracking_url, service_areas) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([
            $data['courier_name'], $data['contact_person'], $data['phone'], $data['email'],
            $data['address'], $data['city'], $data['state'], $data['postal_code'],
            $data['tracking_url'], $data['service_areas']
        ]);
    }
    
    public function updateCourier($id, $data) {
        $stmt = $this->db->prepare("
            UPDATE couriers 
            SET courier_name=?, contact_person=?, phone=?, email=?, address=?, city=?, state=?, 
                postal_code=?, tracking_url=?, service_areas=?, status=? 
            WHERE id=?
        ");
        return $stmt->execute([
            $data['courier_name'], $data['contact_person'], $data['phone'], $data['email'],
            $data['address'], $data['city'], $data['state'], $data['postal_code'],
            $data['tracking_url'], $data['service_areas'], $data['status'], $id
        ]);
    }
    
    public function deleteCourier($id) {
        $stmt = $this->db->prepare("DELETE FROM couriers WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    public function getCourierById($id) {
        $stmt = $this->db->prepare("SELECT * FROM couriers WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function getCourierShipments($courier_id) {
        $stmt = $this->db->prepare("
            SELECT s.*, c.full_name as customer_name
            FROM shipments s
            JOIN customers c ON s.customer_id = c.id
            WHERE s.courier_id = ?
            ORDER BY s.created_at DESC
        ");
        $stmt->execute([$courier_id]);
        return $stmt->fetchAll();
    }
    
    // ====================
    // AGENT MANAGEMENT
    // ====================
    
    public function getAllAgentsWithSupervisors() {
        return $this->db->query("
            SELECT a.*, s.full_name as supervisor_name 
            FROM agents a 
            LEFT JOIN agents s ON a.supervisor_id = s.id 
            ORDER BY a.created_at DESC
        ")->fetchAll();
    }
    
    public function getActiveAgents() {
        return $this->db->query("
            SELECT id, full_name, agent_code 
            FROM agents 
            WHERE status = 'active' 
            ORDER BY full_name
        ")->fetchAll();
    }
    
    public function addAgent($data) {
        $stmt = $this->db->prepare("
            INSERT INTO agents (agent_code, full_name, email, phone, address, city, state, postal_code, commission_rate, hired_date, supervisor_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([
            $data['agent_code'], $data['full_name'], $data['email'], $data['phone'],
            $data['address'], $data['city'], $data['state'], $data['postal_code'],
            $data['commission_rate'], $data['hired_date'], $data['supervisor_id']
        ]);
    }
    
    public function updateAgent($id, $data) {
        $stmt = $this->db->prepare("
            UPDATE agents 
            SET full_name=?, email=?, phone=?, address=?, city=?, state=?, postal_code=?, 
                commission_rate=?, hired_date=?, supervisor_id=?, status=? 
            WHERE id=?
        ");
        return $stmt->execute([
            $data['full_name'], $data['email'], $data['phone'], $data['address'],
            $data['city'], $data['state'], $data['postal_code'], $data['commission_rate'],
            $data['hired_date'], $data['supervisor_id'], $data['status'], $id
        ]);
    }
    
    public function deleteAgent($id) {
        $stmt = $this->db->prepare("DELETE FROM agents WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    public function getAgentById($id) {
        $stmt = $this->db->prepare("SELECT * FROM agents WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function getAgentPerformance() {
        return $this->db->query("
            SELECT a.full_name, a.agent_code, COUNT(s.id) as shipments_count, 
                   SUM(s.total_cost) as total_revenue,
                   ROUND(SUM(s.total_cost * a.commission_rate / 100), 2) as commission_earned
            FROM agents a
            LEFT JOIN shipments s ON a.id = s.agent_id
            WHERE a.status = 'active'
            GROUP BY a.id
            ORDER BY shipments_count DESC
        ")->fetchAll();
    }
    
    public function getAgentShipments($agent_id) {
        $stmt = $this->db->prepare("
            SELECT s.*, c.full_name as customer_name, co.courier_name
            FROM shipments s
            JOIN customers c ON s.customer_id = c.id
            JOIN couriers co ON s.courier_id = co.id
            WHERE s.agent_id = ?
            ORDER BY s.created_at DESC
        ");
        $stmt->execute([$agent_id]);
        return $stmt->fetchAll();
    }
    
    // ====================
    // CUSTOMER MANAGEMENT
    // ====================
    
    public function getAllCustomersWithShipments() {
        return $this->db->query("
            SELECT c.*, COUNT(s.id) as shipment_count, 
                   SUM(s.total_cost) as total_spent,
                   MAX(s.created_at) as last_shipment
            FROM customers c 
            LEFT JOIN shipments s ON c.id = s.customer_id 
            GROUP BY c.id 
            ORDER BY c.created_at DESC
        ")->fetchAll();
    }
    
    public function getActiveCustomers() {
        return $this->db->query("SELECT * FROM customers WHERE status = 'active' ORDER BY full_name")->fetchAll();
    }
    
    public function addCustomer($data) {
        $stmt = $this->db->prepare("
            INSERT INTO customers (customer_code, full_name, email, phone, address, city, state, postal_code, customer_type, company_name, registration_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([
            $data['customer_code'], $data['full_name'], $data['email'], $data['phone'],
            $data['address'], $data['city'], $data['state'], $data['postal_code'],
            $data['customer_type'], $data['company_name'], $data['registration_date']
        ]);
    }
    
    public function updateCustomer($id, $data) {
        $stmt = $this->db->prepare("
            UPDATE customers 
            SET full_name=?, email=?, phone=?, address=?, city=?, state=?, postal_code=?, 
                customer_type=?, company_name=?, registration_date=?, status=? 
            WHERE id=?
        ");
        return $stmt->execute([
            $data['full_name'], $data['email'], $data['phone'], $data['address'],
            $data['city'], $data['state'], $data['postal_code'], $data['customer_type'],
            $data['company_name'], $data['registration_date'], $data['status'], $id
        ]);
    }
    
    public function deleteCustomer($id) {
        $stmt = $this->db->prepare("DELETE FROM customers WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    public function getCustomerById($id) {
        $stmt = $this->db->prepare("SELECT * FROM customers WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function getTopCustomers($limit = 10) {
        return $this->db->query("
            SELECT c.full_name, c.customer_code, COUNT(s.id) as shipments_count, 
                   SUM(s.total_cost) as total_spent,
                   AVG(s.total_cost) as avg_shipment_value
            FROM customers c
            LEFT JOIN shipments s ON c.id = s.customer_id
            WHERE c.status = 'active'
            GROUP BY c.id
            HAVING shipments_count > 0
            ORDER BY total_spent DESC
            LIMIT " . (int)$limit
        )->fetchAll();
    }
    
    public function getCustomerShipments($customer_id) {
        $stmt = $this->db->prepare("
            SELECT s.*, a.full_name as agent_name, co.courier_name
            FROM shipments s
            JOIN agents a ON s.agent_id = a.id
            JOIN couriers co ON s.courier_id = co.id
            WHERE s.customer_id = ?
            ORDER BY s.created_at DESC
        ");
        $stmt->execute([$customer_id]);
        return $stmt->fetchAll();
    }
    
    // ====================
    // SHIPMENT MANAGEMENT
    // ====================
    
    public function getAllShipmentsWithDetails() {
        return $this->db->query("
            SELECT s.*, c.full_name as customer_name, c.customer_code,
                   a.full_name as agent_name, a.agent_code,
                   co.courier_name
            FROM shipments s
            JOIN customers c ON s.customer_id = c.id
            JOIN agents a ON s.agent_id = a.id
            JOIN couriers co ON s.courier_id = co.id
            ORDER BY s.created_at DESC
        ")->fetchAll();
    }
    
    public function getShipmentsByStatus($status) {
        $stmt = $this->db->prepare("
            SELECT s.*, c.full_name as customer_name, a.full_name as agent_name, co.courier_name
            FROM shipments s
            JOIN customers c ON s.customer_id = c.id
            JOIN agents a ON s.agent_id = a.id
            JOIN couriers co ON s.courier_id = co.id
            WHERE s.shipment_status = ?
            ORDER BY s.created_at DESC
        ");
        $stmt->execute([$status]);
        return $stmt->fetchAll();
    }
    
    public function addShipment($data) {
        $stmt = $this->db->prepare("
            INSERT INTO shipments (
                tracking_number, customer_id, agent_id, courier_id, sender_name, sender_phone, sender_address,
                receiver_name, receiver_phone, receiver_address, receiver_city, receiver_state, receiver_postal_code,
                weight, dimensions, shipment_type, service_type, declared_value, shipping_cost, insurance_cost,
                total_cost, payment_status, pickup_date, estimated_delivery, special_instructions
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([
            $data['tracking_number'], $data['customer_id'], $data['agent_id'], $data['courier_id'],
            $data['sender_name'], $data['sender_phone'], $data['sender_address'],
            $data['receiver_name'], $data['receiver_phone'], $data['receiver_address'],
            $data['receiver_city'], $data['receiver_state'], $data['receiver_postal_code'],
            $data['weight'], $data['dimensions'], $data['shipment_type'], $data['service_type'],
            $data['declared_value'], $data['shipping_cost'], $data['insurance_cost'],
            $data['total_cost'], $data['payment_status'], $data['pickup_date'],
            $data['estimated_delivery'], $data['special_instructions']
        ]);
    }
    
    public function updateShipmentStatus($id, $status, $location = null, $remarks = null) {
        // Get old status first
        $oldStatusStmt = $this->db->prepare("SELECT shipment_status FROM shipments WHERE id = ?");
        $oldStatusStmt->execute([$id]);
        $oldStatus = $oldStatusStmt->fetchColumn();
        
        // Update shipment status
        $stmt = $this->db->prepare("UPDATE shipments SET shipment_status = ?, updated_at = NOW() WHERE id = ?");
        $result = $stmt->execute([$status, $id]);
        
        // Add to status history
        if ($result) {
            $historyStmt = $this->db->prepare("
                INSERT INTO shipment_status_history (shipment_id, old_status, new_status, location, remarks, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $historyStmt->execute([$id, $oldStatus, $status, $location, $remarks]);
        }
        
        return $result;
    }
    
    public function getShipmentById($id) {
        $stmt = $this->db->prepare("
            SELECT s.*, c.full_name as customer_name, c.customer_code,
                   a.full_name as agent_name, a.agent_code,
                   co.courier_name, co.tracking_url
            FROM shipments s
            JOIN customers c ON s.customer_id = c.id
            JOIN agents a ON s.agent_id = a.id
            JOIN couriers co ON s.courier_id = co.id
            WHERE s.id = ?
        ");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function getShipmentHistory($shipment_id) {
        $stmt = $this->db->prepare("
            SELECT * FROM shipment_status_history 
            WHERE shipment_id = ? 
            ORDER BY created_at DESC
        ");
        $stmt->execute([$shipment_id]);
        return $stmt->fetchAll();
    }
    
    public function searchShipments($tracking_number) {
        $stmt = $this->db->prepare("
            SELECT s.*, c.full_name as customer_name, co.courier_name
            FROM shipments s
            JOIN customers c ON s.customer_id = c.id
            JOIN couriers co ON s.courier_id = co.id
            WHERE s.tracking_number LIKE ?
        ");
        $stmt->execute(['%' . $tracking_number . '%']);
        return $stmt->fetchAll();
    }
    
    public function deleteShipment($id) {
        // Delete history first due to foreign key constraint
        $historyStmt = $this->db->prepare("DELETE FROM shipment_status_history WHERE shipment_id = ?");
        $historyStmt->execute([$id]);
        
        // Delete shipment
        $stmt = $this->db->prepare("DELETE FROM shipments WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    // ====================
    // DASHBOARD STATISTICS
    // ====================
    
    public function getDashboardStats() {
        $stats = [];
        
        // Basic counts
        $stats['couriers_count'] = $this->db->query("SELECT COUNT(*) FROM couriers WHERE status = 'active'")->fetchColumn();
        $stats['agents_count'] = $this->db->query("SELECT COUNT(*) FROM agents WHERE status = 'active'")->fetchColumn();
        $stats['customers_count'] = $this->db->query("SELECT COUNT(*) FROM customers WHERE status = 'active'")->fetchColumn();
        $stats['total_shipments'] = $this->db->query("SELECT COUNT(*) FROM shipments")->fetchColumn();
        
        // Shipment status counts
        $stats['pending_shipments'] = $this->db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'pending'")->fetchColumn();
        $stats['in_transit_shipments'] = $this->db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'in_transit'")->fetchColumn();
        $stats['delivered_shipments'] = $this->db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'delivered'")->fetchColumn();
        $stats['cancelled_shipments'] = $this->db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'cancelled'")->fetchColumn();
        $stats['out_for_delivery_shipments'] = $this->db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'out_for_delivery'")->fetchColumn();
        
        // Revenue statistics
        $stats['total_revenue'] = $this->db->query("SELECT SUM(total_cost) FROM shipments WHERE payment_status = 'paid'")->fetchColumn() ?? 0;
        $stats['monthly_revenue'] = $this->db->query("SELECT SUM(total_cost) FROM shipments WHERE payment_status = 'paid' AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())")->fetchColumn() ?? 0;
        $stats['pending_payments'] = $this->db->query("SELECT SUM(total_cost) FROM shipments WHERE payment_status = 'pending'")->fetchColumn() ?? 0;
        $stats['cod_shipments'] = $this->db->query("SELECT COUNT(*) FROM shipments WHERE payment_status = 'cod'")->fetchColumn();
        
        return $stats;
    }
    
    public function getRecentShipments($limit = 5) {
        return $this->db->query("
            SELECT s.tracking_number, s.shipment_status, s.created_at, 
                   c.full_name as customer_name, co.courier_name 
            FROM shipments s 
            JOIN customers c ON s.customer_id = c.id 
            JOIN couriers co ON s.courier_id = co.id 
            ORDER BY s.created_at DESC 
            LIMIT " . (int)$limit
        )->fetchAll();
    }
    
    public function getRecentCustomers($limit = 5) {
        return $this->db->query("
            SELECT full_name, customer_code, customer_type, created_at
            FROM customers
            ORDER BY created_at DESC
            LIMIT " . (int)$limit
        )->fetchAll();
    }
    
    public function getTodayStats() {
        $stats = [];
        $stats['today_shipments'] = $this->db->query("SELECT COUNT(*) FROM shipments WHERE DATE(created_at) = CURDATE()")->fetchColumn();
        $stats['today_revenue'] = $this->db->query("SELECT SUM(total_cost) FROM shipments WHERE DATE(created_at) = CURDATE() AND payment_status = 'paid'")->fetchColumn() ?? 0;
        $stats['today_customers'] = $this->db->query("SELECT COUNT(*) FROM customers WHERE DATE(created_at) = CURDATE()")->fetchColumn();
        return $stats;
    }
    
    // ====================
    // REPORTING QUERIES
    // ====================
    
    public function getMonthlyRevenueData($months = 12) {
        return $this->db->query("
            SELECT MONTH(created_at) as month, YEAR(created_at) as year, 
                   SUM(total_cost) as revenue, COUNT(*) as shipments
            FROM shipments 
            WHERE payment_status = 'paid' AND created_at >= DATE_SUB(NOW(), INTERVAL " . (int)$months . " MONTH)
            GROUP BY YEAR(created_at), MONTH(created_at) 
            ORDER BY year DESC, month DESC
            LIMIT " . (int)$months
        )->fetchAll();
    }
    
    public function getCourierPerformance() {
        return $this->db->query("
            SELECT co.courier_name, COUNT(s.id) as shipments_count, 
                   SUM(CASE WHEN s.shipment_status = 'delivered' THEN 1 ELSE 0 END) as delivered_count,
                   SUM(CASE WHEN s.shipment_status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count,
                   ROUND((SUM(CASE WHEN s.shipment_status = 'delivered' THEN 1 ELSE 0 END) / NULLIF(COUNT(s.id), 0)) * 100, 2) as success_rate,
                   SUM(s.total_cost) as total_revenue
            FROM couriers co
            LEFT JOIN shipments s ON co.id = s.courier_id
            WHERE co.status = 'active'
            GROUP BY co.id
            ORDER BY success_rate DESC
        ")->fetchAll();
    }
    
    public function getShipmentReport() {
        return $this->db->query("
            SELECT s.tracking_number, c.full_name as customer, a.full_name as agent, 
                   co.courier_name, s.shipment_status, s.payment_status, s.total_cost, s.created_at
            FROM shipments s
            JOIN customers c ON s.customer_id = c.id
            JOIN agents a ON s.agent_id = a.id
            JOIN couriers co ON s.courier_id = co.id
            ORDER BY s.created_at DESC
        ")->fetchAll();
    }
    
    public function getCustomerReport() {
        return $this->db->query("
            SELECT customer_code, full_name, email, phone, customer_type, 
                   company_name, city, state, status, registration_date, created_at
            FROM customers 
            ORDER BY created_at DESC
        ")->fetchAll();
    }
    
    public function getDailyRevenueReport() {
        return $this->db->query("
            SELECT DATE(created_at) as date, 
                   SUM(total_cost) as revenue, 
                   COUNT(*) as shipments,
                   AVG(total_cost) as avg_value
            FROM shipments 
            WHERE payment_status = 'paid'
            GROUP BY DATE(created_at) 
            ORDER BY date DESC
        ")->fetchAll();
    }
    
    public function getAgentCommissionReport($start_date = null, $end_date = null) {
        $whereClause = "";
        $params = [];
        
        if ($start_date && $end_date) {
            $whereClause = "AND DATE(s.created_at) BETWEEN ? AND ?";
            $params = [$start_date, $end_date];
        }
        
        $stmt = $this->db->prepare("
            SELECT a.full_name, a.agent_code, a.commission_rate,
                   COUNT(s.id) as shipments_handled,
                   SUM(s.total_cost) as total_revenue,
                   ROUND(SUM(s.total_cost * a.commission_rate / 100), 2) as total_commission
            FROM agents a
            LEFT JOIN shipments s ON a.id = s.agent_id $whereClause
            WHERE a.status = 'active'
            GROUP BY a.id
            ORDER BY total_commission DESC
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    // ====================
    // SEARCH AND FILTERS
    // ====================
    
    public function searchCustomers($search_term) {
        $stmt = $this->db->prepare("
            SELECT * FROM customers 
            WHERE full_name LIKE ? OR email LIKE ? OR customer_code LIKE ? OR phone LIKE ?
            ORDER BY full_name
        ");
        $search = '%' . $search_term . '%';
        $stmt->execute([$search, $search, $search, $search]);
        return $stmt->fetchAll();
    }
    
    public function filterShipmentsByDateRange($start_date, $end_date) {
        $stmt = $this->db->prepare("
            SELECT s.*, c.full_name as customer_name, a.full_name as agent_name, co.courier_name
            FROM shipments s
            JOIN customers c ON s.customer_id = c.id
            JOIN agents a ON s.agent_id = a.id
            JOIN couriers co ON s.courier_id = co.id
            WHERE DATE(s.created_at) BETWEEN ? AND ?
            ORDER BY s.created_at DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll();
    }
    
    public function filterCustomersByType($customer_type) {
        $stmt = $this->db->prepare("
            SELECT c.*, COUNT(s.id) as shipment_count 
            FROM customers c 
            LEFT JOIN shipments s ON c.id = s.customer_id 
            WHERE c.customer_type = ?
            GROUP BY c.id 
            ORDER BY c.created_at DESC
        ");
        $stmt->execute([$customer_type]);
        return $stmt->fetchAll();
    }
    
    // ====================
    // ADVANCED ANALYTICS
    // ====================
    
    public function getTopPerformingRoutes() {
        return $this->db->query("
            SELECT CONCAT(s.sender_address, ' → ', s.receiver_city) as route,
                   COUNT(*) as shipments_count,
                   AVG(s.total_cost) as avg_cost,
                   SUM(CASE WHEN s.shipment_status = 'delivered' THEN 1 ELSE 0 END) as delivered_count
            FROM shipments s
            GROUP BY s.sender_address, s.receiver_city
            HAVING shipments_count >= 3
            ORDER BY shipments_count DESC
            LIMIT 10
        ")->fetchAll();
    }
    
    public function getCustomerLifetimeValue() {
        return $this->db->query("
            SELECT c.full_name, c.customer_code,
                   COUNT(s.id) as total_shipments,
                   SUM(s.total_cost) as lifetime_value,
                   AVG(s.total_cost) as avg_shipment_value,
                   MIN(s.created_at) as first_shipment,
                   MAX(s.created_at) as last_shipment,
                   DATEDIFF(NOW(), MAX(s.created_at)) as days_since_last_shipment
            FROM customers c
            LEFT JOIN shipments s ON c.id = s.customer_id
            WHERE c.status = 'active'
            GROUP BY c.id
            HAVING total_shipments > 0
            ORDER BY lifetime_value DESC
            LIMIT 20
        ")->fetchAll();
    }
    
    public function getShipmentStatusTimeline() {
        return $this->db->query("
            SELECT shipment_status, 
                   COUNT(*) as count,
                   ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM shipments), 2) as percentage
            FROM shipments
            GROUP BY shipment_status
            ORDER BY count DESC
        ")->fetchAll();
    }
    
    public function getMonthlyGrowthStats() {
        return $this->db->query("
            SELECT 
                DATE_FORMAT(created_at, '%Y-%m') as month,
                COUNT(*) as shipments,
                SUM(total_cost) as revenue,
                COUNT(DISTINCT customer_id) as unique_customers
            FROM shipments
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
            GROUP BY DATE_FORMAT(created_at, '%Y-%m')
            ORDER BY month DESC
        ")->fetchAll();
    }
    
    // ====================
    // UTILITY FUNCTIONS
    // ====================
    
    public function generateTrackingNumber() {
        do {
            $tracking = 'TRK' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
            $exists = $this->db->prepare("SELECT COUNT(*) FROM shipments WHERE tracking_number = ?");
            $exists->execute([$tracking]);
        } while ($exists->fetchColumn() > 0);
        
        return $tracking;
    }
    
    public function validateUniqueEmail($email, $table, $exclude_id = null) {
        if ($exclude_id) {
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM {$table} WHERE email = ? AND id != ?");
            $stmt->execute([$email, $exclude_id]);
        } else {
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM {$table} WHERE email = ?");
            $stmt->execute([$email]);
        }
        return $stmt->fetchColumn() == 0;
    }
    
    public function getNextCustomerCode() {
        $result = $this->db->query("SELECT customer_code FROM customers ORDER BY id DESC LIMIT 1")->fetch();
        if ($result) {
            $last_number = intval(substr($result['customer_code'], 4));
            return 'CUST' . str_pad($last_number + 1, 3, '0', STR_PAD_LEFT);
        }
        return 'CUST001';
    }
    
    public function getNextAgentCode() {
        $result = $this->db->query("SELECT agent_code FROM agents ORDER BY id DESC LIMIT 1")->fetch();
        if ($result) {
            $last_number = intval(substr($result['agent_code'], 3));
            return 'AGT' . str_pad($last_number + 1, 3, '0', STR_PAD_LEFT);
        }
        return 'AGT001';
    }
    
    public function checkCodeExists($code, $table, $column) {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM {$table} WHERE {$column} = ?");
        $stmt->execute([$code]);
        return $stmt->fetchColumn() > 0;
    }
    
    // ====================
    // BACKUP AND MAINTENANCE
    // ====================
    
    public function cleanupOldSessions() {
        // Clean up old session data (if you're storing sessions in database)
        return $this->db->query("DELETE FROM user_sessions WHERE last_activity < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
    }
    
    public function getSystemHealth() {
        $health = [];
        
        // Table sizes
        $health['tables'] = [
            'customers' => $this->db->query("SELECT COUNT(*) FROM customers")->fetchColumn(),
            'agents' => $this->db->query("SELECT COUNT(*) FROM agents")->fetchColumn(),
            'couriers' => $this->db->query("SELECT COUNT(*) FROM couriers")->fetchColumn(),
            'shipments' => $this->db->query("SELECT COUNT(*) FROM shipments")->fetchColumn(),
            'shipment_history' => $this->db->query("SELECT COUNT(*) FROM shipment_status_history")->fetchColumn(),
        ];
        
        // Recent activity
        $health['recent_activity'] = [
            'shipments_today' => $this->db->query("SELECT COUNT(*) FROM shipments WHERE DATE(created_at) = CURDATE()")->fetchColumn(),
            'new_customers_week' => $this->db->query("SELECT COUNT(*) FROM customers WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn(),
            'revenue_today' => $this->db->query("SELECT COALESCE(SUM(total_cost), 0) FROM shipments WHERE DATE(created_at) = CURDATE() AND payment_status = 'paid'")->fetchColumn()
        ];
        
        // System status
        $health['system_status'] = [
            'pending_shipments' => $this->db->query("SELECT COUNT(*) FROM shipments WHERE shipment_status = 'pending'")->fetchColumn(),
            'overdue_shipments' => $this->db->query("SELECT COUNT(*) FROM shipments WHERE estimated_delivery < CURDATE() AND shipment_status NOT IN ('delivered', 'cancelled')")->fetchColumn(),
            'active_users' => $this->db->query("SELECT COUNT(*) FROM customers WHERE status = 'active'")->fetchColumn()
        ];
        
        return $health;
    }
    
    public function getDatabaseSize() {
        return $this->db->query("
            SELECT 
                table_name AS 'Table',
                round(((data_length + index_length) / 1024 / 1024), 2) AS 'Size (MB)'
            FROM information_schema.TABLES 
            WHERE table_schema = DATABASE()
            ORDER BY (data_length + index_length) DESC
        ")->fetchAll();
    }
    
    // ====================
    // DATA VALIDATION
    // ====================
    
    public function validateShipmentData($data) {
        $errors = [];
        
        // Required fields validation
        $required_fields = ['customer_id', 'agent_id', 'courier_id', 'sender_name', 'receiver_name', 'weight', 'total_cost'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
            }
        }
        
        // Validate foreign keys
        if (!empty($data['customer_id'])) {
            $customer_exists = $this->db->prepare("SELECT COUNT(*) FROM customers WHERE id = ? AND status = 'active'");
            $customer_exists->execute([$data['customer_id']]);
            if ($customer_exists->fetchColumn() == 0) {
                $errors[] = 'Invalid customer selected';
            }
        }
        
        if (!empty($data['agent_id'])) {
            $agent_exists = $this->db->prepare("SELECT COUNT(*) FROM agents WHERE id = ? AND status = 'active'");
            $agent_exists->execute([$data['agent_id']]);
            if ($agent_exists->fetchColumn() == 0) {
                $errors[] = 'Invalid agent selected';
            }
        }
        
        if (!empty($data['courier_id'])) {
            $courier_exists = $this->db->prepare("SELECT COUNT(*) FROM couriers WHERE id = ? AND status = 'active'");
            $courier_exists->execute([$data['courier_id']]);
            if ($courier_exists->fetchColumn() == 0) {
                $errors[] = 'Invalid courier selected';
            }
        }
        
        // Validate numeric fields
        if (!empty($data['weight']) && (!is_numeric($data['weight']) || $data['weight'] <= 0)) {
            $errors[] = 'Weight must be a positive number';
        }
        
        if (!empty($data['total_cost']) && (!is_numeric($data['total_cost']) || $data['total_cost'] <= 0)) {
            $errors[] = 'Total cost must be a positive number';
        }
        
        // Validate email formats
        if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email format';
        }
        
        return $errors;
    }
    
    public function validateCustomerData($data, $exclude_id = null) {
        $errors = [];
        
        // Required fields
        $required_fields = ['full_name', 'email', 'phone', 'address', 'city', 'state', 'postal_code'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
            }
        }
        
        // Email validation
        if (!empty($data['email'])) {
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'Invalid email format';
            } elseif (!$this->validateUniqueEmail($data['email'], 'customers', $exclude_id)) {
                $errors[] = 'Email already exists';
            }
        }
        
        // Phone validation
        if (!empty($data['phone']) && !preg_match('/^[\+]?[\d\s\-\(\)]+$/', $data['phone'])) {
            $errors[] = 'Invalid phone number format';
        }
        
        // Business customer validation
        if ($data['customer_type'] === 'business' && empty($data['company_name'])) {
            $errors[] = 'Company name is required for business customers';
        }
        
        return $errors;
    }
    
    // ====================
    // LOGGING AND AUDIT
    // ====================
    
    public function logActivity($admin_id, $action, $details = null) {
        $stmt = $this->db->prepare("
            INSERT INTO activity_logs (admin_id, action, details, ip_address, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        return $stmt->execute([
            $admin_id, 
            $action, 
            $details, 
            $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);
    }
    
    public function getActivityLogs($limit = 50) {
        return $this->db->query("
            SELECT al.*, a.full_name as admin_name
            FROM activity_logs al
            LEFT JOIN admins a ON al.admin_id = a.id
            ORDER BY al.created_at DESC
            LIMIT " . (int)$limit
        )->fetchAll();
    }
    
    public function getRecentActivities($days = 7, $limit = 20) {
        return $this->db->query("
            SELECT 
                'shipment' as type, 
                CONCAT('New shipment created: ', tracking_number) as description,
                created_at
            FROM shipments 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)
            
            UNION ALL
            
            SELECT 
                'customer' as type,
                CONCAT('New customer registered: ', full_name) as description,
                created_at
            FROM customers 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)
            
            UNION ALL
            
            SELECT 
                'agent' as type,
                CONCAT('New agent added: ', full_name) as description,
                created_at
            FROM agents 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)
            
            ORDER BY created_at DESC
            LIMIT " . (int)$limit
        )->fetchAll();
    }
    
    // ====================
    // ADVANCED REPORTING
    // ====================
    
    public function getFinancialSummary($start_date = null, $end_date = null) {
        $whereClause = "";
        $params = [];
        
        if ($start_date && $end_date) {
            $whereClause = "WHERE DATE(created_at) BETWEEN ? AND ?";
            $params = [$start_date, $end_date];
        }
        
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total_shipments,
                SUM(CASE WHEN payment_status = 'paid' THEN total_cost ELSE 0 END) as total_revenue,
                SUM(CASE WHEN payment_status = 'pending' THEN total_cost ELSE 0 END) as pending_revenue,
                SUM(CASE WHEN payment_status = 'cod' THEN total_cost ELSE 0 END) as cod_revenue,
                AVG(total_cost) as average_shipment_value,
                SUM(shipping_cost) as total_shipping_fees,
                SUM(insurance_cost) as total_insurance_fees
            FROM shipments 
            $whereClause
        ");
        $stmt->execute($params);
        return $stmt->fetch();
    }
    
    public function getCustomerSegmentation() {
        return $this->db->query("
            SELECT 
                CASE 
                    WHEN shipment_count = 0 THEN 'No Orders'
                    WHEN shipment_count = 1 THEN 'One-time Customer'
                    WHEN shipment_count BETWEEN 2 AND 5 THEN 'Regular Customer'
                    WHEN shipment_count BETWEEN 6 AND 20 THEN 'Loyal Customer'
                    ELSE 'VIP Customer'
                END as customer_segment,
                COUNT(*) as customer_count,
                AVG(total_spent) as avg_spent
            FROM (
                SELECT c.id, c.full_name, 
                       COUNT(s.id) as shipment_count,
                       SUM(s.total_cost) as total_spent
                FROM customers c
                LEFT JOIN shipments s ON c.id = s.customer_id
                GROUP BY c.id
            ) customer_stats
            GROUP BY customer_segment
            ORDER BY customer_count DESC
        ")->fetchAll();
    }
    
    public function getShipmentAnalytics() {
        return [
            'by_type' => $this->db->query("
                SELECT shipment_type, COUNT(*) as count, 
                       AVG(total_cost) as avg_cost,
                       SUM(total_cost) as total_revenue
                FROM shipments 
                GROUP BY shipment_type 
                ORDER BY count DESC
            ")->fetchAll(),
            
            'by_service' => $this->db->query("
                SELECT service_type, COUNT(*) as count,
                       AVG(total_cost) as avg_cost,
                       SUM(total_cost) as total_revenue
                FROM shipments 
                GROUP BY service_type 
                ORDER BY count DESC
            ")->fetchAll(),
            
            'by_payment' => $this->db->query("
                SELECT payment_status, COUNT(*) as count,
                       SUM(total_cost) as total_amount
                FROM shipments 
                GROUP BY payment_status 
                ORDER BY count DESC
            ")->fetchAll()
        ];
    }
    
    // ====================
    // BULK OPERATIONS
    // ====================
    
    public function bulkUpdateShipmentStatus($shipment_ids, $new_status) {
        if (empty($shipment_ids)) return false;
        
        $placeholders = str_repeat('?,', count($shipment_ids) - 1) . '?';
        $params = array_merge($shipment_ids, [$new_status]);
        
        $stmt = $this->db->prepare("
            UPDATE shipments 
            SET shipment_status = ?, updated_at = NOW() 
            WHERE id IN ($placeholders)
        ");
        
        // Reverse params for correct order
        $params = array_merge([$new_status], $shipment_ids);
        
        return $stmt->execute($params);
    }
    
    public function bulkDeleteCustomers($customer_ids) {
        if (empty($customer_ids)) return false;
        
        $placeholders = str_repeat('?,', count($customer_ids) - 1) . '?';
        $stmt = $this->db->prepare("DELETE FROM customers WHERE id IN ($placeholders)");
        return $stmt->execute($customer_ids);
    }
    
    // ====================
    // EXPORT HELPERS
    // ====================
    
    public function getExportData($type, $filters = []) {
        switch ($type) {
            case 'shipments':
                return $this->getShipmentReport();
                
            case 'customers':
                return $this->getCustomerReport();
                
            case 'revenue':
                return $this->getDailyRevenueReport();
                
            case 'agents':
                return $this->db->query("
                    SELECT agent_code, full_name, email, phone, city, state, 
                           commission_rate, hired_date, status, created_at
                    FROM agents 
                    ORDER BY created_at DESC
                ")->fetchAll();
                
            case 'couriers':
                return $this->db->query("
                    SELECT courier_name, contact_person, phone, email, 
                           city, state, status, created_at
                    FROM couriers 
                    ORDER BY created_at DESC
                ")->fetchAll();
                
            default:
                return [];
        }
    }
}
?>
<?php
// ====================
// ADDITIONAL UTILITY QUERIES
// ====================

try {
    $pdo = getDBConnection();

    // Create Activity Logs Table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS activity_logs (
            id INT PRIMARY KEY AUTO_INCREMENT,
            admin_id INT,
            action VARCHAR(255) NOT NULL,
            details TEXT,
            ip_address VARCHAR(45),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL,
            INDEX idx_activity_logs_admin (admin_id),
            INDEX idx_activity_logs_created (created_at)
        )
    ");

    // Performance Optimization Indexes
    $indexes = [
        "CREATE INDEX idx_shipments_status ON shipments(shipment_status)",
        "CREATE INDEX idx_shipments_created ON shipments(created_at)",
        "CREATE INDEX idx_shipments_tracking ON shipments(tracking_number)",
        "CREATE INDEX idx_shipments_customer ON shipments(customer_id)",
        "CREATE INDEX idx_shipments_agent ON shipments(agent_id)",
        "CREATE INDEX idx_shipments_courier ON shipments(courier_id)",
        "CREATE INDEX idx_shipments_payment ON shipments(payment_status)",
        "CREATE INDEX idx_customers_email ON customers(email)",
        "CREATE INDEX idx_customers_status ON customers(status)",
        "CREATE INDEX idx_customers_type ON customers(customer_type)",
        "CREATE INDEX idx_customers_created ON customers(created_at)",
        "CREATE INDEX idx_agents_status ON agents(status)",
        "CREATE INDEX idx_agents_supervisor ON agents(supervisor_id)",
        "CREATE INDEX idx_agents_code ON agents(agent_code)",
        "CREATE INDEX idx_couriers_status ON couriers(status)",
        "CREATE INDEX idx_shipment_history_shipment ON shipment_status_history(shipment_id)",
        "CREATE INDEX idx_shipment_history_created ON shipment_status_history(created_at)"
    ];

    foreach ($indexes as $sql) {
        try {
            $pdo->exec($sql);
        } catch (Exception $e) {
            // Ignore if already exists
        }
    }

} catch (Exception $e) {
    error_log("Utility queries failed: " . $e->getMessage());
}
?>
