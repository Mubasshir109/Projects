-- Admin Panel Database Schema
CREATE DATABASE IF NOT EXISTS admin_panel;
USE admin_panel;

-- Admin Table
CREATE TABLE IF NOT EXISTS admins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('super_admin', 'admin') DEFAULT 'admin',
    status ENUM('active', 'inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Couriers Table
CREATE TABLE IF NOT EXISTS couriers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    courier_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(50) NOT NULL,
    state VARCHAR(50) NOT NULL,
    postal_code VARCHAR(10) NOT NULL,
    country VARCHAR(50) DEFAULT 'Pakistan',
    tracking_url VARCHAR(255),
    api_key VARCHAR(255),
    service_areas TEXT,
    pricing_info TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Agents Table
CREATE TABLE IF NOT EXISTS agents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    agent_code VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(50) NOT NULL,
    state VARCHAR(50) NOT NULL,
    postal_code VARCHAR(10) NOT NULL,
    commission_rate DECIMAL(5,2) DEFAULT 0.00,
    status ENUM('active', 'inactive') DEFAULT 'active',
    hired_date DATE NOT NULL,
    supervisor_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (supervisor_id) REFERENCES agents(id) ON DELETE SET NULL
);

-- Customers Table
CREATE TABLE IF NOT EXISTS customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_code VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(50) NOT NULL,
    state VARCHAR(50) NOT NULL,
    postal_code VARCHAR(10) NOT NULL,
    country VARCHAR(50) DEFAULT 'Pakistan',
    customer_type ENUM('individual', 'business') DEFAULT 'individual',
    company_name VARCHAR(100) NULL,
    registration_date DATE NOT NULL,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Shipments Table
CREATE TABLE IF NOT EXISTS shipments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tracking_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    agent_id INT NOT NULL,
    courier_id INT NOT NULL,
    sender_name VARCHAR(100) NOT NULL,
    sender_phone VARCHAR(20) NOT NULL,
    sender_address TEXT NOT NULL,
    receiver_name VARCHAR(100) NOT NULL,
    receiver_phone VARCHAR(20) NOT NULL,
    receiver_address TEXT NOT NULL,
    receiver_city VARCHAR(50) NOT NULL,
    receiver_state VARCHAR(50) NOT NULL,
    receiver_postal_code VARCHAR(10) NOT NULL,
    weight DECIMAL(10,2) NOT NULL,
    dimensions VARCHAR(50),
    shipment_type ENUM('document', 'package', 'fragile', 'express') DEFAULT 'package',
    service_type ENUM('standard', 'express', 'overnight') DEFAULT 'standard',
    declared_value DECIMAL(10,2) DEFAULT 0.00,
    shipping_cost DECIMAL(10,2) NOT NULL,
    insurance_cost DECIMAL(10,2) DEFAULT 0.00,
    total_cost DECIMAL(10,2) NOT NULL,
    payment_status ENUM('pending', 'paid', 'cod', 'refunded') DEFAULT 'pending',
    shipment_status ENUM('pending', 'picked_up', 'in_transit', 'out_for_delivery', 'delivered', 'cancelled', 'returned') DEFAULT 'pending',
    pickup_date DATE NULL,
    delivery_date DATE NULL,
    estimated_delivery DATE NULL,
    special_instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE,
    FOREIGN KEY (courier_id) REFERENCES couriers(id) ON DELETE CASCADE
);

-- Shipment Status History
CREATE TABLE IF NOT EXISTS shipment_status_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    shipment_id INT NOT NULL,
    old_status VARCHAR(50),
    new_status VARCHAR(50) NOT NULL,
    location VARCHAR(100),
    remarks TEXT,
    changed_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE CASCADE
);

-- Insert Default Admin User
INSERT INTO admins (username, email, password, full_name, role) VALUES 
('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'super_admin');

-- Insert Sample Couriers
INSERT INTO couriers (courier_name, contact_person, phone, email, address, city, state, postal_code, tracking_url) VALUES 
('TCS Express', 'Muhammad Ali', '+92-300-1234567', 'info@tcs.com.pk', 'TCS House, Main Boulevard', 'Karachi', 'Sindh', '75300', 'https://www.tcs.com.pk/tracking'),
('Leopards Courier', 'Ahmed Hassan', '+92-321-9876543', 'support@leopardscourier.com', 'Plot 123, Industrial Area', 'Lahore', 'Punjab', '54000', 'https://www.leopardscourier.com/track'),
('Blue Ex', 'Fatima Khan', '+92-333-5555555', 'info@blue-ex.com', 'Blue Ex Terminal, Shahrah-e-Faisal', 'Karachi', 'Sindh', '75350', 'https://www.blue-ex.com/tracking');

-- Insert Sample Agents
INSERT INTO agents (agent_code, full_name, email, phone, address, city, state, postal_code, commission_rate, hired_date) VALUES 
('AGT001', 'Usman Malik', 'usman.malik@company.com', '+92-300-1111111', 'House 456, Block B, Gulshan', 'Karachi', 'Sindh', '75300', 5.00, '2024-01-15'),
('AGT002', 'Aisha Rehman', 'aisha.rehman@company.com', '+92-321-2222222', 'Flat 789, DHA Phase 5', 'Lahore', 'Punjab', '54000', 4.50, '2024-02-01'),
('AGT003', 'Hassan Ali', 'hassan.ali@company.com', '+92-333-3333333', 'Shop 12, F-7 Markaz', 'Islamabad', 'ICT', '44000', 4.00, '2024-03-10');

-- Insert Sample Customers
INSERT INTO customers (customer_code, full_name, email, phone, address, city, state, postal_code, customer_type, registration_date) VALUES 
('CUST001', 'Sarah Ahmed', 'sarah.ahmed@email.com', '+92-300-4444444', 'House 321, Clifton', 'Karachi', 'Sindh', '75600', 'individual', '2024-01-20'),
('CUST002', 'Tech Solutions Ltd', 'info@techsolutions.com', '+92-42-5555555', 'Office 501, Arfa Tower', 'Lahore', 'Punjab', '54000', 'business', '2024-02-15'),
('CUST003', 'Omar Sheikh', 'omar.sheikh@email.com', '+92-51-6666666', 'House 789, F-10', 'Islamabad', 'ICT', '44000', 'individual', '2024-03-05');

-- Insert Sample Shipments
INSERT INTO shipments (tracking_number, customer_id, agent_id, courier_id, sender_name, sender_phone, sender_address, receiver_name, receiver_phone, receiver_address, receiver_city, receiver_state, receiver_postal_code, weight, shipment_type, service_type, declared_value, shipping_cost, insurance_cost, total_cost, payment_status, shipment_status, pickup_date, estimated_delivery) VALUES 
('TRK001234567', 1, 1, 1, 'Sarah Ahmed', '+92-300-4444444', 'House 321, Clifton, Karachi', 'Ali Hassan', '+92-321-7777777', 'Shop 45, Mall Road, Lahore', 'Lahore', 'Punjab', '54000', 2.50, 'package', 'standard', 5000.00, 350.00, 50.00, 400.00, 'paid', 'in_transit', '2024-09-01', '2024-09-05'),
('TRK001234568', 2, 2, 2, 'Tech Solutions Ltd', '+92-42-5555555', 'Office 501, Arfa Tower, Lahore', 'Zara Khan', '+92-300-8888888', 'House 123, Blue Area, Islamabad', 'Islamabad', 'ICT', '44000', 1.20, 'document', 'express', 2000.00, 250.00, 20.00, 270.00, 'paid', 'delivered', '2024-08-28', '2024-08-30'),
('TRK001234569', 3, 3, 3, 'Omar Sheikh', '+92-51-6666666', 'House 789, F-10, Islamabad', 'Mehwish Ali', '+92-333-9999999', 'Flat 67, North Nazimabad, Karachi', 'Karachi', 'Sindh', '74700', 3.75, 'fragile', 'overnight', 8000.00, 500.00, 80.00, 580.00, 'cod', 'out_for_delivery', '2024-09-03', '2024-09-04');