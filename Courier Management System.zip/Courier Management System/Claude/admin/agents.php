<?php
require_once 'config/database.php';
requireLogin();

$database = new Database();
$db = $database->connect();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setMessage('Invalid CSRF token', 'error');
    } else {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'add':
                $agent_code = generateCode('AGT');
                $full_name = sanitizeInput($_POST['full_name']);
                $email = sanitizeInput($_POST['email']);
                $phone = sanitizeInput($_POST['phone']);
                $address = sanitizeInput($_POST['address']);
                $city = sanitizeInput($_POST['city']);
                $state = sanitizeInput($_POST['state']);
                $postal_code = sanitizeInput($_POST['postal_code']);
                $commission_rate = (float)$_POST['commission_rate'];
                $hired_date = sanitizeInput($_POST['hired_date']);
                $supervisor_id = !empty($_POST['supervisor_id']) ? (int)$_POST['supervisor_id'] : null;
                
                try {
                    $stmt = $db->prepare("
                        INSERT INTO agents (agent_code, full_name, email, phone, address, city, state, postal_code, commission_rate, hired_date, supervisor_id) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$agent_code, $full_name, $email, $phone, $address, $city, $state, $postal_code, $commission_rate, $hired_date, $supervisor_id]);
                    setMessage('Agent added successfully!');
                } catch (PDOException $e) {
                    setMessage('Error adding agent: ' . $e->getMessage(), 'error');
                }
                break;
                
            case 'update':
                $id = (int)$_POST['agent_id'];
                $full_name = sanitizeInput($_POST['full_name']);
                $email = sanitizeInput($_POST['email']);
                $phone = sanitizeInput($_POST['phone']);
                $address = sanitizeInput($_POST['address']);
                $city = sanitizeInput($_POST['city']);
                $state = sanitizeInput($_POST['state']);
                $postal_code = sanitizeInput($_POST['postal_code']);
                $commission_rate = (float)$_POST['commission_rate'];
                $hired_date = sanitizeInput($_POST['hired_date']);
                $supervisor_id = !empty($_POST['supervisor_id']) ? (int)$_POST['supervisor_id'] : null;
                $status = sanitizeInput($_POST['status']);
                
                try {
                    $stmt = $db->prepare("
                        UPDATE agents SET full_name=?, email=?, phone=?, address=?, city=?, state=?, 
                               postal_code=?, commission_rate=?, hired_date=?, supervisor_id=?, status=? 
                        WHERE id=?
                    ");
                    $stmt->execute([$full_name, $email, $phone, $address, $city, $state, $postal_code, $commission_rate, $hired_date, $supervisor_id, $status, $id]);
                    setMessage('Agent updated successfully!');
                } catch (PDOException $e) {
                    setMessage('Error updating agent: ' . $e->getMessage(), 'error');
                }
                break;
                
            case 'delete':
                $id = (int)$_POST['agent_id'];
                try {
                    $stmt = $db->prepare("DELETE FROM agents WHERE id = ?");
                    $stmt->execute([$id]);
                    setMessage('Agent deleted successfully!');
                } catch (PDOException $e) {
                    setMessage('Error deleting agent: ' . $e->getMessage(), 'error');
                }
                break;
        }
        
        header('Location: agents.php');
        exit();
    }
}

// Get all agents with supervisor names
try {
    $agents = $db->query("
        SELECT a.*, s.full_name as supervisor_name 
        FROM agents a 
        LEFT JOIN agents s ON a.supervisor_id = s.id 
        ORDER BY a.created_at DESC
    ")->fetchAll();
    
    // Get active agents for supervisor dropdown
    $supervisors = $db->query("
        SELECT id, full_name, agent_code 
        FROM agents 
        WHERE status = 'active' 
        ORDER BY full_name
    ")->fetchAll();
} catch (PDOException $e) {
    $error = "Error fetching agents: " . $e->getMessage();
}

$message = getMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Management</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
       body {
    background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%), 
                linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
    background-blend-mode: overlay;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}


/* Sidebar */
.sidebar {
    background: linear-gradient(180deg, #1e3a8a 0%, #4f46e5 100%);
    min-height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    z-index: 1000;
    transition: all 0.3s ease;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
}

.sidebar-item {
    color: rgba(255, 255, 255, 0.85);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.sidebar-item:hover,
.sidebar-item.active {
    color: white;
    background: rgba(255, 255, 255, 0.1);
    border-left-color: #3b82f6;
    transform: translateX(5px);
}

.sidebar h4 {
    font-size: 18px;   /* size chhota / bara karne ke liye */
    font-weight: 600;  /* boldness */
    color: #fff;       /* white hi rakho */
    margin: 0;         /* gap remove */
}


/* Main Content */
.main-content {
    margin-left: 250px;
    padding: 20px;
}

/* Content Card */
.content-card {
    background: #ffffff;
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    padding: 30px;
    margin-bottom: 30px;
    transition: all 0.3s ease;
}
.content-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 25px 50px rgba(0,0,0,0.15);
}

.modal {
    z-index: 1060 !important; /* sabse upar */
}
.modal-backdrop {
    z-index: 1050 !important;
}
.dropdown-menu {
    z-index: 1055 !important;
}

/* Navbar */
.navbar-custom {
    background: #ffffff;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
    padding: 15px 20px;
    margin-bottom: 30px;
    position: relative;
    z-index: 2000;
    border-radius: 10px;
    z-index: 1030;
}
.navbar-custom h3,
.navbar-custom h5 {
    font-size: 1.2rem;      /* consistent size */
    font-weight: 600;       /* semi-bold clean look */
    color: #1e3a8a;         /* dashboard theme ka dark blue */
    margin: 0;              /* extra spacing hatao */
    letter-spacing: 0.5px;  /* thoda spacing for modern look */
}

/* Gradient Button */
.btn-gradient {
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    border: none;
    color: white;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}
.btn-gradient:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.4);
    color: white;
}
.btn-gradient::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s;
}
.btn-gradient:hover::before { left: 100%; }

/* Table */
.table-modern {
    border-collapse: separate;
    border-spacing: 0;
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
}
.table-modern th {
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    color: white;
    border: none;
    padding: 20px 15px;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.85rem;
    letter-spacing: 1px;
}
.table-modern td {
    border: none;
    padding: 20px 15px;
    border-bottom: 1px solid #f1f3f4;
    vertical-align: middle;
    transition: all 0.3s ease;
}
.table-modern tbody tr:hover {
    background: #f8f9fa;
    transform: scale(1.01);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

/* Agent Avatar */
.agent-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.2rem;
    margin-right: 15px;
    background: linear-gradient(45deg, #3b82f6, #9333ea);
}

/* Status Badge */
.status-badge {
    padding: 8px 16px;
    border-radius: 25px;
    font-size: 0.8rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
}
.status-badge.success { background: #10b981; color: #fff; }
.status-badge.warning { background: #f59e0b; color: #fff; }
.status-badge.danger  { background: #ef4444; color: #fff; }
.status-badge.info    { background: #3b82f6; color: #fff; }

/* Modal */
.modal-content {
    border: none;
    border-radius: 20px;
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
    background: #ffffff;
}

/* Forms */
.form-control {
    border: 2px solid #e1e8ed;
    border-radius: 12px;
    padding: 15px 20px;
    transition: all 0.3s ease;
}
.form-control:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.3rem rgba(102, 126, 234, 0.15);
    transform: translateY(-2px);
    background: white;
}

/* Animations */
.animate-slide-in {
    animation: slideInUp 0.6s ease-out;
}
@keyframes slideInUp {
    from { opacity: 0; transform: translateY(30px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* Stats Card */
.stats-card {
    background: linear-gradient(135deg, #3b82f6 0%, #9333ea 100%);
    color: white;
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
}
.stats-card::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
    animation: rotate 15s linear infinite;
}
@keyframes rotate {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
}

/* ✅ Status Indicator Styles */
.status-indicator {
    display: inline-block;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    margin-right: 8px;
    animation: blink 2s infinite;
}

.status-indicator.online { background: #00b894; }   /* Green = Online */
.status-indicator.busy { background: #fdcb6e; }     /* Yellow = Busy */
.status-indicator.offline { background: #fd79a8; }  /* Pink/Red = Offline */

@keyframes blink {
    0%, 50% { opacity: 1; }
    51%, 100% { opacity: 0.5; }
}

/* ✅ Sidebar text (jisme System Status likha hai) */
.sidebar-text {
    margin-left: 15px;
    transition: opacity 0.3s ease;
}

    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-center border-bottom border-secondary">
            <h4 class="text-white mb-0">
                <i class="fas fa-users-cog me-2"></i>
                 <span class="sidebar-text">Admin Panel</span>
            </h4>
        </div>
        
        <nav class="mt-3">
            <a href="dashboard.php" class="sidebar-item">
                <i class="fas fa-tachometer-alt me-3"></i>Dashboard
            </a>
            <a href="couriers.php" class="sidebar-item">
                <i class="fas fa-truck me-3"></i>Couriers
            </a>
            <a href="agents.php" class="sidebar-item active">
                <i class="fas fa-users me-3"></i>Agents
            </a>
            <a href="customers.php" class="sidebar-item">
                <i class="fas fa-user-friends me-3"></i>Customers
            </a>
            <a href="shipments.php" class="sidebar-item">
                <i class="fas fa-box me-3"></i>Shipments
            </a>
            <a href="reports.php" class="sidebar-item">
                <i class="fas fa-chart-bar me-3"></i>Reports
            </a>
            <a href="logout.php" class="sidebar-item">
                <i class="fas fa-sign-out-alt me-3"></i>Logout
            </a>
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
     <nav class="navbar-custom d-flex justify-content-between align-items-center">
    <h5 class="mb-0"><i class="fas fa-users-cog me-2 text-primary"></i>Agent Management</h5>
    <div class="d-flex align-items-center">
        <span class="me-3">Welcome, <?php echo $_SESSION['full_name']; ?></span>
        <div class="dropdown">
            <button class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                <i class="fas fa-user"></i>
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-cog me-2"></i>Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Alert Messages -->
        <?php if ($message): ?>
        <div class="alert alert-<?php echo $message['type'] === 'error' ? 'danger' : 'success'; ?> alert-dismissible fade show animate-slide-in" role="alert">
            <i class="fas fa-<?php echo $message['type'] === 'error' ? 'exclamation-triangle' : 'check-circle'; ?> me-2"></i>
            <?php echo $message['message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card text-center">
                    <h3 class="mb-1"><?php echo count(array_filter($agents, function($a) { return $a['status'] === 'active'; })); ?></h3>
                    <p class="mb-0 opacity-90">Active Agents</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card text-center">
                    <h3 class="mb-1"><?php echo count(array_filter($agents, function($a) { return $a['status'] === 'inactive'; })); ?></h3>
                    <p class="mb-0 opacity-90">Inactive Agents</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card text-center">
                    <h3 class="mb-1"><?php echo count(array_filter($agents, function($a) { return !empty($a['supervisor_id']); })); ?></h3>
                    <p class="mb-0 opacity-90">Supervised Agents</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card text-center">
                    <h3 class="mb-1"><?php echo number_format(array_sum(array_column($agents, 'commission_rate')) / count($agents), 2); ?>%</h3>
                    <p class="mb-0 opacity-90">Avg Commission</p>
                </div>
            </div>
        </div>

        <!-- Add New Agent Button -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0">All Agents</h3>
            <button type="button" class="btn btn-gradient btn-lg" data-bs-toggle="modal" data-bs-target="#addAgentModal">
                <i class="fas fa-user-plus me-2"></i>Add New Agent
            </button>
        </div>

        <!-- Agents Table -->
        <div class="content-card">
            <div class="table-responsive">
                <table class="table table-modern">
                    <thead>
                        <tr>
                            <th>Agent</th>
                            <th>Contact Info</th>
                            <th>Location</th>
                            <th>Commission</th>
                            <th>Supervisor</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($agents as $agent): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="agent-avatar" style="background: linear-gradient(45deg, #<?php echo substr(md5($agent['full_name']), 0, 6); ?>, #<?php echo substr(md5($agent['agent_code']), 0, 6); ?>);">
                                        <?php echo strtoupper(substr($agent['full_name'], 0, 1)); ?>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($agent['full_name']); ?></h6>
                                        <small class="text-muted"><?php echo htmlspecialchars($agent['agent_code']); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <i class="fas fa-envelope text-primary me-1"></i>
                                    <?php echo htmlspecialchars($agent['email']); ?><br>
                                    <i class="fas fa-phone text-success me-1"></i>
                                    <?php echo htmlspecialchars($agent['phone']); ?>
                                </div>
                            </td>
                            <td>
                                <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                <?php echo htmlspecialchars($agent['city']); ?>, <?php echo htmlspecialchars($agent['state']); ?>
                            </td>
                            <td>
                                <span class="badge bg-info text-white fs-6">
                                    <?php echo number_format($agent['commission_rate'], 2); ?>%
                                </span>
                            </td>
                            <td>
                                <?php if ($agent['supervisor_name']): ?>
                                    <span class="badge bg-secondary">
                                        <?php echo htmlspecialchars($agent['supervisor_name']); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="status-badge <?php echo $agent['status'] === 'active' ? 'bg-success text-white' : 'bg-danger text-white'; ?>">
                                    <?php echo ucfirst($agent['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-info" 
                                            onclick="viewAgent(<?php echo htmlspecialchars(json_encode($agent)); ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-warning" 
                                            onclick="editAgent(<?php echo htmlspecialchars(json_encode($agent)); ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger" 
                                            onclick="deleteAgent(<?php echo $agent['id']; ?>, '<?php echo htmlspecialchars($agent['full_name']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Agent Modal -->
    <div class="modal fade" id="addAgentModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Add New Agent</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="full_name" class="form-label">Full Name *</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">Phone *</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="hired_date" class="form-label">Hired Date *</label>
                                <input type="date" class="form-control" id="hired_date" name="hired_date" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Address *</label>
                            <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="city" class="form-label">City *</label>
                                <input type="text" class="form-control" id="city" name="city" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="state" class="form-label">State *</label>
                                <input type="text" class="form-control" id="state" name="state" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="postal_code" class="form-label">Postal Code *</label>
                                <input type="text" class="form-control" id="postal_code" name="postal_code" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="commission_rate" class="form-label">Commission Rate (%)</label>
                                <input type="number" class="form-control" id="commission_rate" name="commission_rate" 
                                       min="0" max="100" step="0.01" value="5.00">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="supervisor_id" class="form-label">Supervisor</label>
                                <select class="form-control" id="supervisor_id" name="supervisor_id">
                                    <option value="">Select Supervisor (Optional)</option>
                                    <?php foreach ($supervisors as $supervisor): ?>
                                    <option value="<?php echo $supervisor['id']; ?>">
                                        <?php echo htmlspecialchars($supervisor['full_name'] . ' (' . $supervisor['agent_code'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-gradient">
                            <i class="fas fa-save me-2"></i>Add Agent
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Agent Modal -->
    <div class="modal fade" id="editAgentModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Agent</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="agent_id" id="edit_agent_id">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_full_name" class="form-label">Full Name *</label>
                                <input type="text" class="form-control" id="edit_full_name" name="full_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="edit_email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_phone" class="form-label">Phone *</label>
                                <input type="tel" class="form-control" id="edit_phone" name="phone" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_hired_date" class="form-label">Hired Date *</label>
                                <input type="date" class="form-control" id="edit_hired_date" name="hired_date" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_address" class="form-label">Address *</label>
                            <textarea class="form-control" id="edit_address" name="address" rows="2" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="edit_city" class="form-label">City *</label>
                                <input type="text" class="form-control" id="edit_city" name="city" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_state" class="form-label">State *</label>
                                <input type="text" class="form-control" id="edit_state" name="state" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_postal_code" class="form-label">Postal Code *</label>
                                <input type="text" class="form-control" id="edit_postal_code" name="postal_code" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_status" class="form-label">Status *</label>
                                <select class="form-control" id="edit_status" name="status" required>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_commission_rate" class="form-label">Commission Rate (%)</label>
                                <input type="number" class="form-control" id="edit_commission_rate" name="commission_rate" 
                                       min="0" max="100" step="0.01">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_supervisor_id" class="form-label">Supervisor</label>
                                <select class="form-control" id="edit_supervisor_id" name="supervisor_id">
                                    <option value="">Select Supervisor (Optional)</option>
                                    <?php foreach ($supervisors as $supervisor): ?>
                                    <option value="<?php echo $supervisor['id']; ?>">
                                        <?php echo htmlspecialchars($supervisor['full_name'] . ' (' . $supervisor['agent_code'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-gradient">
                            <i class="fas fa-save me-2"></i>Update Agent
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Agent Modal -->
    <div class="modal fade" id="viewAgentModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-eye me-2"></i>Agent Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary">Personal Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Full Name:</strong></td><td id="view_full_name"></td></tr>
                                <tr><td><strong>Agent Code:</strong></td><td id="view_agent_code"></td></tr>
                                <tr><td><strong>Email:</strong></td><td id="view_email"></td></tr>
                                <tr><td><strong>Phone:</strong></td><td id="view_phone"></td></tr>
                                <tr><td><strong>Status:</strong></td><td id="view_status"></td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-primary">Address Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Address:</strong></td><td id="view_address"></td></tr>
                                <tr><td><strong>City:</strong></td><td id="view_city"></td></tr>
                                <tr><td><strong>State:</strong></td><td id="view_state"></td></tr>
                                <tr><td><strong>Postal Code:</strong></td><td id="view_postal_code"></td></tr>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6 class="text-primary">Employment Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Commission Rate:</strong></td><td id="view_commission_rate"></td></tr>
                                <tr><td><strong>Hired Date:</strong></td><td id="view_hired_date"></td></tr>
                                <tr><td><strong>Supervisor:</strong></td><td id="view_supervisor"></td></tr>
                                <tr><td><strong>Created:</strong></td><td id="view_created_at"></td></tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteAgentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger"><i class="fas fa-exclamation-triangle me-2"></i>Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete agent <strong id="delete_agent_name"></strong>?</p>
                    <p class="text-danger"><small>This action cannot be undone and will affect all related shipments.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="agent_id" id="delete_agent_id">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i>Delete Agent
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // View Agent Details
        function viewAgent(agent) {
            document.getElementById('view_full_name').textContent = agent.full_name;
            document.getElementById('view_agent_code').textContent = agent.agent_code;
            document.getElementById('view_email').textContent = agent.email;
            document.getElementById('view_phone').textContent = agent.phone;
            document.getElementById('view_status').innerHTML = `<span class="status-badge ${agent.status === 'active' ? 'bg-success' : 'bg-danger'} text-white">${agent.status.charAt(0).toUpperCase() + agent.status.slice(1)}</span>`;
            document.getElementById('view_address').textContent = agent.address;
            document.getElementById('view_city').textContent = agent.city;
            document.getElementById('view_state').textContent = agent.state;
            document.getElementById('view_postal_code').textContent = agent.postal_code;
            document.getElementById('view_commission_rate').textContent = agent.commission_rate + '%';
            document.getElementById('view_hired_date').textContent = new Date(agent.hired_date).toLocaleDateString();
            document.getElementById('view_supervisor').textContent = agent.supervisor_name || 'None';
            document.getElementById('view_created_at').textContent = new Date(agent.created_at).toLocaleDateString();
            
            new bootstrap.Modal(document.getElementById('viewAgentModal')).show();
        }

        // Edit Agent
        function editAgent(agent) {
            document.getElementById('edit_agent_id').value = agent.id;
            document.getElementById('edit_full_name').value = agent.full_name;
            document.getElementById('edit_email').value = agent.email;
            document.getElementById('edit_phone').value = agent.phone;
            document.getElementById('edit_address').value = agent.address;
            document.getElementById('edit_city').value = agent.city;
            document.getElementById('edit_state').value = agent.state;
            document.getElementById('edit_postal_code').value = agent.postal_code;
            document.getElementById('edit_commission_rate').value = agent.commission_rate;
            document.getElementById('edit_hired_date').value = agent.hired_date;
            document.getElementById('edit_supervisor_id').value = agent.supervisor_id || '';
            document.getElementById('edit_status').value = agent.status;
            
            new bootstrap.Modal(document.getElementById('editAgentModal')).show();
        }

        // Delete Agent
        function deleteAgent(id, name) {
            document.getElementById('delete_agent_id').value = id;
            document.getElementById('delete_agent_name').textContent = name;
            
            new bootstrap.Modal(document.getElementById('deleteAgentModal')).show();
        }

        // Form animations
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 5px 15px rgba(102, 126, 234, 0.2)';
            });
            
            input.addEventListener('blur', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            });
        });
    </script>
</body>
</html>