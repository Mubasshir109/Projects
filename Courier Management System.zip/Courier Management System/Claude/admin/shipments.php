<?php
require_once 'config/database.php';
requireLogin();

$database = new Database();
$db = $database->connect();

// Handle form submissions (supports normal form submits and AJAX (ajax=1))
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isAjax = !empty($_POST['ajax']) && $_POST['ajax'] == '1';

    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        if ($isAjax) {
            header('Content-Type: application/json');
            echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
            exit;
        } else {
            setMessage('Invalid CSRF token', 'error');
            header('Location: shipments.php');
            exit;
        }
    }

    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'add':
            $tracking_number = 'TRK' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
            $customer_id = (int)$_POST['customer_id'];
            $agent_id = (int)$_POST['agent_id'];
            $courier_id = (int)$_POST['courier_id'];
            $sender_name = sanitizeInput($_POST['sender_name']);
            $sender_phone = sanitizeInput($_POST['sender_phone']);
            $sender_address = sanitizeInput($_POST['sender_address']);
            $receiver_name = sanitizeInput($_POST['receiver_name']);
            $receiver_phone = sanitizeInput($_POST['receiver_phone']);
            $receiver_address = sanitizeInput($_POST['receiver_address']);
            $receiver_city = sanitizeInput($_POST['receiver_city']);
            $receiver_state = sanitizeInput($_POST['receiver_state']);
            $receiver_postal_code = sanitizeInput($_POST['receiver_postal_code']);
            $weight = (float)$_POST['weight'];
            $dimensions = sanitizeInput($_POST['dimensions']);
            $shipment_type = sanitizeInput($_POST['shipment_type']);
            $service_type = sanitizeInput($_POST['service_type']);
            $declared_value = (float)$_POST['declared_value'];
            $shipping_cost = (float)$_POST['shipping_cost'];
            $insurance_cost = (float)$_POST['insurance_cost'];
            $total_cost = $shipping_cost + $insurance_cost;
            $payment_status = sanitizeInput($_POST['payment_status']);
            $pickup_date = sanitizeInput($_POST['pickup_date']);
            $estimated_delivery = sanitizeInput($_POST['estimated_delivery']);
            $special_instructions = sanitizeInput($_POST['special_instructions']);

            try {
                $stmt = $db->prepare("
                    INSERT INTO shipments (
                        tracking_number, customer_id, agent_id, courier_id, sender_name, sender_phone, sender_address,
                        receiver_name, receiver_phone, receiver_address, receiver_city, receiver_state, receiver_postal_code,
                        weight, dimensions, shipment_type, service_type, declared_value, shipping_cost, insurance_cost,
                        total_cost, payment_status, pickup_date, estimated_delivery, special_instructions
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $tracking_number, $customer_id, $agent_id, $courier_id, $sender_name, $sender_phone, $sender_address,
                    $receiver_name, $receiver_phone, $receiver_address, $receiver_city, $receiver_state, $receiver_postal_code,
                    $weight, $dimensions, $shipment_type, $service_type, $declared_value, $shipping_cost, $insurance_cost,
                    $total_cost, $payment_status, $pickup_date, $estimated_delivery, $special_instructions
                ]);
                $msg = 'Shipment created successfully!';
                if ($isAjax) {
                    header('Content-Type: application/json');
                    echo json_encode(['status' => 'success', 'message' => $msg]);
                    exit;
                } else {
                    setMessage($msg);
                }
            } catch (PDOException $e) {
                $err = 'Error creating shipment: ' . $e->getMessage();
                if ($isAjax) {
                    header('Content-Type: application/json');
                    echo json_encode(['status' => 'error', 'message' => $err]);
                    exit;
                } else {
                    setMessage($err, 'error');
                }
            }
            break;

        case 'update_status':
            $id = (int)$_POST['shipment_id'];
            $new_status = sanitizeInput($_POST['shipment_status']);
            $location = sanitizeInput($_POST['location']);
            $remarks = sanitizeInput($_POST['remarks']);

            try {
                // Get old status
                $oldStatusStmt = $db->prepare("SELECT shipment_status FROM shipments WHERE id = ?");
                $oldStatusStmt->execute([$id]);
                $oldStatus = $oldStatusStmt->fetchColumn();

                // Update shipment status
                $stmt = $db->prepare("UPDATE shipments SET shipment_status = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$new_status, $id]);

                // Add to history
                $historyStmt = $db->prepare("
                    INSERT INTO shipment_status_history (shipment_id, old_status, new_status, location, remarks, changed_by) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $historyStmt->execute([$id, $oldStatus, $new_status, $location, $remarks, $_SESSION['username']]);

                $msg = 'Shipment status updated successfully!';
                if ($isAjax) {
                    header('Content-Type: application/json');
                    echo json_encode(['status' => 'success', 'message' => $msg]);
                    exit;
                } else {
                    setMessage($msg);
                }
            } catch (PDOException $e) {
                $err = 'Error updating shipment status: ' . $e->getMessage();
                if ($isAjax) {
                    header('Content-Type: application/json');
                    echo json_encode(['status' => 'error', 'message' => $err]);
                    exit;
                } else {
                    setMessage($err, 'error');
                }
            }
            break;

        case 'delete':
            $id = (int)$_POST['shipment_id'];
            try {
                // Delete history first
                $historyStmt = $db->prepare("DELETE FROM shipment_status_history WHERE shipment_id = ?");
                $historyStmt->execute([$id]);

                // Delete shipment
                $stmt = $db->prepare("DELETE FROM shipments WHERE id = ?");
                $stmt->execute([$id]);
                $msg = 'Shipment deleted successfully!';
                if ($isAjax) {
                    header('Content-Type: application/json');
                    echo json_encode(['status' => 'success', 'message' => $msg]);
                    exit;
                } else {
                    setMessage($msg);
                }
            } catch (PDOException $e) {
                $err = 'Error deleting shipment: ' . $e->getMessage();
                if ($isAjax) {
                    header('Content-Type: application/json');
                    echo json_encode(['status' => 'error', 'message' => $err]);
                    exit;
                } else {
                    setMessage($err, 'error');
                }
            }
            break;
    }

    if (!$isAjax) {
        header('Location: shipments.php');
        exit();
    }
}

// Get all shipments with details (regular)
try {
    $shipments = $db->query("
        SELECT s.*, c.full_name as customer_name, c.customer_code,
               a.full_name as agent_name, a.agent_code,
               co.courier_name
        FROM shipments s
        JOIN customers c ON s.customer_id = c.id
        JOIN agents a ON s.agent_id = a.id
        JOIN couriers co ON s.courier_id = co.id
        ORDER BY s.created_at DESC
    ")->fetchAll();

    // Get customers, agents, and couriers for dropdowns
    $customers = $db->query("SELECT id, full_name, customer_code FROM customers WHERE status = 'active' ORDER BY full_name")->fetchAll();
    $agents = $db->query("SELECT id, full_name, agent_code FROM agents WHERE status = 'active' ORDER BY full_name")->fetchAll();
    $couriers = $db->query("SELECT id, courier_name FROM couriers WHERE status = 'active' ORDER BY courier_name")->fetchAll();

} catch (PDOException $e) {
    $error = "Error fetching data: " . $e->getMessage();
}

$message = getMessage();


// ---- Partial HTML for AJAX refresh ----
if (isset($_GET['partial']) && $_GET['partial'] == '1') {
    // output only the shipments grid HTML fragment (same markup used below)
    foreach ($shipments as $shipment):
    ?>
    <div class="col-md-6 col-xl-4 shipment-item" 
         data-tracking="<?php echo strtolower($shipment['tracking_number']); ?>"
         data-status="<?php echo $shipment['shipment_status']; ?>"
         data-courier="<?php echo strtolower($shipment['courier_name']); ?>">
        <div class="shipment-card <?php echo str_replace('_', '-', $shipment['shipment_status']); ?>">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <div class="tracking-number"><?php echo htmlspecialchars($shipment['tracking_number']); ?></div>
                    <small class="text-muted">
                        <?php echo htmlspecialchars($shipment['customer_name']); ?> • 
                        <?php echo htmlspecialchars($shipment['courier_name']); ?>
                    </small>
                </div>
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#" onclick='viewShipment(<?php echo json_encode($shipment); ?>)'>
                            <i class="fas fa-eye me-2"></i>View Details
                        </a></li>
                        <li><a class="dropdown-item" href="#" onclick='updateStatus(<?php echo $shipment['id']; ?>, <?php echo json_encode($shipment['tracking_number']); ?>)'>
                            <i class="fas fa-sync me-2"></i>Update Status
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="#" onclick='deleteShipment(<?php echo $shipment['id']; ?>, <?php echo json_encode($shipment['tracking_number']); ?>)'>
                            <i class="fas fa-trash me-2"></i>Delete
                        </a></li>
                    </ul>
                </div>
            </div>
            
            <div class="mb-3">
                <span class="status-badge <?php 
                    switch($shipment['shipment_status']) {
                        case 'pending': echo 'bg-warning text-dark'; break;
                        case 'in_transit': echo 'bg-info text-white'; break;
                        case 'out_for_delivery': echo 'bg-primary text-white'; break;
                        case 'delivered': echo 'bg-success text-white'; break;
                        case 'cancelled': echo 'bg-danger text-white'; break;
                        default: echo 'bg-secondary text-white';
                    }
                ?>">
                    <?php echo ucfirst(str_replace('_', ' ', $shipment['shipment_status'])); ?>
                </span>
            </div>
            
            <div class="row mb-3">
                <div class="col-6">
                    <small class="text-muted d-block">From</small>
                    <strong><?php echo htmlspecialchars($shipment['sender_name']); ?></strong>
                </div>
                <div class="col-6">
                    <small class="text-muted d-block">To</small>
                    <strong><?php echo htmlspecialchars($shipment['receiver_name']); ?></strong>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-6">
                    <small class="text-muted d-block">Weight</small>
                    <span><?php echo $shipment['weight']; ?> kg</span>
                </div>
                <div class="col-6">
                    <small class="text-muted d-block">Total Cost</small>
                    <span class="text-success fw-bold"><?php echo formatCurrency($shipment['total_cost']); ?></span>
                </div>
            </div>
            
            <div class="row">
                <div class="col-6">
                    <small class="text-muted d-block">Service</small>
                    <span><?php echo ucfirst($shipment['service_type']); ?></span>
                </div>
                <div class="col-6">
                    <small class="text-muted d-block">Created</small>
                    <span><?php echo formatDate($shipment['created_at']); ?></span>
                </div>
            </div>
        </div>
    </div>
    <?php
    endforeach;
    exit;
}

// ---- JSON endpoint (optional) ----
if (isset($_GET['fetch']) && $_GET['fetch'] == '1') {
    header('Content-Type: application/json');
    echo json_encode($shipments);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shipments - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap & Font Awesome (already used in project) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
         body {
    background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%),
                linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
    background-blend-mode: overlay;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    min-height: 100vh;
}

.sidebar {
    background: linear-gradient(180deg, #1e3a8a 0%, #4f46e5 100%);
    min-height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    z-index: 1000;
    transition: all 0.3s ease;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
}

.sidebar-item {
    color: rgba(255, 255, 255, 0.85);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.sidebar-item:hover,
.sidebar-item.active {
    color: white;
    background: rgba(255, 255, 255, 0.1);
    border-left-color: #3b82f6;
    transform: translateX(5px);
}

.sidebar h4 {
    font-size: 18px;   /* size chhota / bara karne ke liye */
    font-weight: 600;  /* boldness */
    color: #fff;       /* white hi rakho */
    margin: 0;         /* gap remove */
}


.main-content {
    margin-left: 250px;
    padding: 20px;
}

.content-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    padding: 30px;
    margin-bottom: 30px;
    z-index: 1200;
    position: relative; /* ✅ absolute ki jagah ye rakho */
}
.modal-backdrop {
    z-index: 1040 !important;
}
.modal {
    z-index: 1050 !important;
}
.navbar-custom {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    padding: 15px 30px;
    margin-bottom: 30px;
    border-radius: 15px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    z-index: 1030; /* Bootstrap ke modal backdrop se neeche rakho */

}
.navbar-custom h3,
.navbar-custom h5 {
    font-size: 1.2rem;      /* consistent size */
    font-weight: 600;       /* semi-bold clean look */
    color: #1e3a8a;         /* dashboard theme ka dark blue */
    margin: 0;              /* extra spacing hatao */
    letter-spacing: 0.5px;  /* thoda spacing for modern look */
}

.dropdown-menu {
    z-index: 1200; /* Navbar se bhi upar */
    position: absolute;
}

.btn-gradient {
    background: linear-gradient(45deg, #3b82f6, #10b981);
    border: none;
    color: white;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn-gradient:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
    color: white;
}

.shipment-card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 20px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    border-left: 4px solid;
    position: relative;
    overflow: hidden;
}

.shipment-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
}

/* Shipment Status Colors (Dashboard Theme) */
.shipment-card.pending { border-left-color: #f59e0b; }
.shipment-card.in-transit { border-left-color: #3b82f6; }
.shipment-card.delivered { border-left-color: #10b981; }
.shipment-card.cancelled { border-left-color: #ef4444; }
.shipment-card.out-for-delivery { border-left-color: #9333ea; }

.status-badge {
    padding: 8px 16px;
    border-radius: 25px;
    font-size: 0.8rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Status Badge Colors */
.status-badge.bg-warning { background: #f59e0b; color: #fff; }
.status-badge.bg-info { background: #3b82f6; color: #fff; }
.status-badge.bg-success { background: #10b981; color: #fff; }
.status-badge.bg-danger { background: #ef4444; color: #fff; }
.status-badge.bg-secondary { background: #9333ea; color: #fff; }

.tracking-number {
    font-family: 'Courier New', monospace;
    font-weight: bold;
    font-size: 1.1rem;
    color: #2563eb;
}

.form-control {
    border: 2px solid #e1e8ed;
    border-radius: 12px;
    padding: 15px 20px;
    transition: all 0.3s ease;
}

.form-control:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 0.3rem rgba(59, 130, 246, 0.15);
    transform: translateY(-2px);
}

.modal-content {
    border: none;
    border-radius: 20px;
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
    backdrop-filter: blur(10px);
}

.timeline {
    position: relative;
    padding-left: 30px;
}

.timeline::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #dee2e6;
}

.timeline-item {
    position: relative;
    margin-bottom: 20px;
}

.timeline-item::before {
    content: '';
    position: absolute;
    left: -23px;
    top: 5px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #3b82f6;
    border: 2px solid white;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.search-box {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 20px;
    backdrop-filter: blur(10px);
}

.stats-mini {
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    color: white;
    padding: 15px;
    border-radius: 10px;
    text-align: center;
    margin-bottom: 15px;
    position: relative;
    overflow: hidden;
}

.stats-mini::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
    animation: rotate 15s linear infinite;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.animate-slide-in {
    animation: slideInUp 0.6s ease-out;
}

@keyframes slideInUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
    <div class="p-4 text-center border-bottom border-secondary">
        <h4 class="text-white mb-0">
            <i class="fas fa-box me-2"></i>
            <span class="sidebar-text">Admin Panel</span>
        </h4>
    </div>
    
    <nav class="mt-3">
        <a href="dashboard.php" class="sidebar-item">
            <i class="fas fa-tachometer-alt me-3"></i>
            <span class="sidebar-text">Dashboard</span>
        </a>
        <a href="couriers.php" class="sidebar-item">
            <i class="fas fa-truck me-3"></i>
            <span class="sidebar-text">Couriers</span>
        </a>
        <a href="agents.php" class="sidebar-item">
            <i class="fas fa-users me-3"></i>
            <span class="sidebar-text">Agents</span>
        </a>
        <a href="customers.php" class="sidebar-item">
            <i class="fas fa-user-friends me-3"></i>
            <span class="sidebar-text">Customers</span>
        </a>
        <a href="shipments.php" class="sidebar-item active">
            <i class="fas fa-box me-3"></i>
            <span class="sidebar-text">Shipments</span>
        </a>
        <a href="reports.php" class="sidebar-item">
            <i class="fas fa-chart-bar me-3"></i>
            <span class="sidebar-text">Reports</span>
        </a>
        <a href="logout.php" class="sidebar-item">
            <i class="fas fa-sign-out-alt me-3"></i>
            <span class="sidebar-text">Logout</span>
        </a>
    </nav>
</div>


    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation -->
        <nav class="navbar-custom d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-box me-2 text-primary"></i>Shipment Management</h5>
            <div class="d-flex align-items-center">
                <button type="button" class="btn btn-gradient me-3" data-bs-toggle="modal" data-bs-target="#addShipmentModal">
                    <i class="fas fa-plus me-2"></i>Create Shipment
                </button>
                <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Admin'); ?></span>
                <div class="dropdown">
                    <button class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fas fa-user"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-cog me-2"></i>Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Alert Messages -->
        <?php if ($message): ?>
        <div id="serverAlert" class="alert alert-<?php echo $message['type'] === 'error' ? 'danger' : 'success'; ?> alert-dismissible fade show animate-slide-in" role="alert">
            <i class="fas fa-<?php echo $message['type'] === 'error' ? 'exclamation-triangle' : 'check-circle'; ?> me-2"></i>
            <?php echo $message['message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-mini text-center">
                    <h4><?php echo count(array_filter($shipments, function($s) { return $s['shipment_status'] === 'pending'; })); ?></h4>
                    <small>Pending Shipments</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-mini text-center">
                    <h4><?php echo count(array_filter($shipments, function($s) { return $s['shipment_status'] === 'in_transit'; })); ?></h4>
                    <small>In Transit</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-mini text-center">
                    <h4><?php echo count(array_filter($shipments, function($s) { return $s['shipment_status'] === 'delivered'; })); ?></h4>
                    <small>Delivered</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-mini text-center">
                    <h4><?php echo count($shipments); ?></h4>
                    <small>Total Shipments</small>
                </div>
            </div>
        </div>

        <!-- Search and Filter -->
        <div class="search-box">
            <div class="row">
                <div class="col-md-4">
                    <input type="text" class="form-control" id="searchShipment" placeholder="Search by tracking number...">
                </div>
                <div class="col-md-3">
                    <select class="form-control" id="filterStatus">
                        <option value="">All Statuses</option>
                        <option value="pending">Pending</option>
                        <option value="in_transit">In Transit</option>
                        <option value="out_for_delivery">Out for Delivery</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-control" id="filterCourier">
                        <option value="">All Couriers</option>
                        <?php foreach ($couriers as $courier): ?>
                        <option value="<?php echo htmlspecialchars(strtolower($courier['courier_name'])); ?>">
                            <?php echo htmlspecialchars($courier['courier_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-primary w-100" id="clearFiltersBtn">
                        <i class="fas fa-times"></i> Clear
                    </button>
                </div>
            </div>
        </div>

        <!-- Shipments List -->
        <div class="row" id="shipmentsContainer">
            <?php foreach ($shipments as $shipment): ?>
            <div class="col-md-6 col-xl-4 shipment-item" 
                 data-tracking="<?php echo strtolower($shipment['tracking_number']); ?>"
                 data-status="<?php echo $shipment['shipment_status']; ?>"
                 data-courier="<?php echo strtolower($shipment['courier_name']); ?>">
                <div class="shipment-card <?php echo str_replace('_', '-', $shipment['shipment_status']); ?>">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <div class="tracking-number"><?php echo htmlspecialchars($shipment['tracking_number']); ?></div>
                            <small class="text-muted">
                                <?php echo htmlspecialchars($shipment['customer_name']); ?> • 
                                <?php echo htmlspecialchars($shipment['courier_name']); ?>
                            </small>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" onclick='viewShipment(<?php echo json_encode($shipment); ?>)'>
                                    <i class="fas fa-eye me-2"></i>View Details
                                </a></li>
                                <li><a class="dropdown-item" href="#" onclick='updateStatus(<?php echo $shipment['id']; ?>, <?php echo json_encode($shipment['tracking_number']); ?>)'>
                                    <i class="fas fa-sync me-2"></i>Update Status
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="#" onclick='deleteShipment(<?php echo $shipment['id']; ?>, <?php echo json_encode($shipment['tracking_number']); ?>)'>
                                    <i class="fas fa-trash me-2"></i>Delete
                                </a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <span class="status-badge <?php 
                            switch($shipment['shipment_status']) {
                                case 'pending': echo 'bg-warning text-dark'; break;
                                case 'in_transit': echo 'bg-info text-white'; break;
                                case 'out_for_delivery': echo 'bg-primary text-white'; break;
                                case 'delivered': echo 'bg-success text-white'; break;
                                case 'cancelled': echo 'bg-danger text-white'; break;
                                default: echo 'bg-secondary text-white';
                            }
                        ?>">
                            <?php echo ucfirst(str_replace('_', ' ', $shipment['shipment_status'])); ?>
                        </span>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-6">
                            <small class="text-muted d-block">From</small>
                            <strong><?php echo htmlspecialchars($shipment['sender_name']); ?></strong>
                        </div>
                        <div class="col-6">
                            <small class="text-muted d-block">To</small>
                            <strong><?php echo htmlspecialchars($shipment['receiver_name']); ?></strong>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-6">
                            <small class="text-muted d-block">Weight</small>
                            <span><?php echo $shipment['weight']; ?> kg</span>
                        </div>
                        <div class="col-6">
                            <small class="text-muted d-block">Total Cost</small>
                            <span class="text-success fw-bold"><?php echo formatCurrency($shipment['total_cost']); ?></span>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <small class="text-muted d-block">Service</small>
                            <span><?php echo ucfirst($shipment['service_type']); ?></span>
                        </div>
                        <div class="col-6">
                            <small class="text-muted d-block">Created</small>
                            <span><?php echo formatDate($shipment['created_at']); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Add Shipment Modal (complete) -->
    <div class="modal fade" id="addShipmentModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Create New Shipment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="addShipmentForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="ajax" value="1">

                        <!-- Customer and Service Details -->
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="customer_id" class="form-label">Customer *</label>
                                <select class="form-control" id="customer_id" name="customer_id" required>
                                    <option value="">Select Customer</option>
                                    <?php foreach ($customers as $customer): ?>
                                    <option value="<?php echo $customer['id']; ?>">
                                        <?php echo htmlspecialchars($customer['full_name'] . ' (' . $customer['customer_code'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="agent_id" class="form-label">Agent *</label>
                                <select class="form-control" id="agent_id" name="agent_id" required>
                                    <option value="">Select Agent</option>
                                    <?php foreach ($agents as $agent): ?>
                                    <option value="<?php echo $agent['id']; ?>">
                                        <?php echo htmlspecialchars($agent['full_name'] . ' (' . $agent['agent_code'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="courier_id" class="form-label">Courier *</label>
                                <select class="form-control" id="courier_id" name="courier_id" required>
                                    <option value="">Select Courier</option>
                                    <?php foreach ($couriers as $courier): ?>
                                    <option value="<?php echo $courier['id']; ?>">
                                        <?php echo htmlspecialchars($courier['courier_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <!-- Sender Information -->
                        <h6 class="text-primary mb-3">Sender Information</h6>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="sender_name" class="form-label">Sender Name *</label>
                                <input type="text" class="form-control" id="sender_name" name="sender_name" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="sender_phone" class="form-label">Sender Phone *</label>
                                <input type="tel" class="form-control" id="sender_phone" name="sender_phone" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="sender_address" class="form-label">Sender Address *</label>
                                <textarea class="form-control" id="sender_address" name="sender_address" rows="1" required></textarea>
                            </div>
                        </div>

                        <!-- Receiver Information -->
                        <h6 class="text-primary mb-3">Receiver Information</h6>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="receiver_name" class="form-label">Receiver Name *</label>
                                <input type="text" class="form-control" id="receiver_name" name="receiver_name" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="receiver_phone" class="form-label">Receiver Phone *</label>
                                <input type="tel" class="form-control" id="receiver_phone" name="receiver_phone" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="receiver_address" class="form-label">Receiver Address *</label>
                                <textarea class="form-control" id="receiver_address" name="receiver_address" rows="1" required></textarea>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="receiver_city" class="form-label">City</label>
                                <input type="text" class="form-control" id="receiver_city" name="receiver_city">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="receiver_state" class="form-label">State</label>
                                <input type="text" class="form-control" id="receiver_state" name="receiver_state">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="receiver_postal_code" class="form-label">Postal Code</label>
                                <input type="text" class="form-control" id="receiver_postal_code" name="receiver_postal_code">
                            </div>
                        </div>

                        <!-- Package Details -->
                        <h6 class="text-primary mb-3">Package Details</h6>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="weight" class="form-label">Weight (kg)</label>
                                <input type="number" step="0.01" class="form-control" id="weight" name="weight" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="dimensions" class="form-label">Dimensions</label>
                                <input type="text" class="form-control" id="dimensions" name="dimensions" placeholder="LxWxH">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="shipment_type" class="form-label">Shipment Type</label>
                                <select class="form-control" id="shipment_type" name="shipment_type">
                                    <option value="parcel">Parcel</option>
                                    <option value="document">Document</option>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="service_type" class="form-label">Service Type</label>
                                <select class="form-control" id="service_type" name="service_type">
                                    <option value="standard">Standard</option>
                                    <option value="express">Express</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="declared_value" class="form-label">Declared Value</label>
                                <input type="number" step="0.01" class="form-control" id="declared_value" name="declared_value" value="0">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="shipping_cost" class="form-label">Shipping Cost</label>
                                <input type="number" step="0.01" class="form-control" id="shipping_cost" name="shipping_cost" value="0">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="insurance_cost" class="form-label">Insurance Cost</label>
                                <input type="number" step="0.01" class="form-control" id="insurance_cost" name="insurance_cost" value="0">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="payment_status" class="form-label">Payment Status</label>
                                <select class="form-control" id="payment_status" name="payment_status">
                                    <option value="pending">Pending</option>
                                    <option value="paid">Paid</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="pickup_date" class="form-label">Pickup Date</label>
                                <input type="date" class="form-control" id="pickup_date" name="pickup_date">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="estimated_delivery" class="form-label">Estimated Delivery</label>
                                <input type="date" class="form-control" id="estimated_delivery" name="estimated_delivery">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="special_instructions" class="form-label">Special Instructions</label>
                            <textarea class="form-control" id="special_instructions" name="special_instructions" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-gradient">
                            <i class="fas fa-save me-2"></i>Create Shipment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Shipment Modal -->
    <div class="modal fade" id="viewShipmentModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-eye me-2"></i>Shipment Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="viewShipmentContent">
                        <!-- populated by JS -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button id="viewEditBtn" type="button" class="btn btn-primary" style="display:none;">
                        <i class="fas fa-edit me-2"></i>Edit Shipment
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Status Modal -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-sync me-2"></i>Update Shipment Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="updateStatusForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update_status">
                        <input type="hidden" name="shipment_id" id="update_shipment_id">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="ajax" value="1">

                        <div class="mb-3">
                            <label for="shipment_status" class="form-label">Status</label>
                            <select class="form-control" id="shipment_status" name="shipment_status" required>
                                <option value="pending">Pending</option>
                                <option value="in_transit">In Transit</option>
                                <option value="out_for_delivery">Out for Delivery</option>
                                <option value="delivered">Delivered</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="location" class="form-label">Location</label>
                            <input type="text" class="form-control" id="location" name="location">
                        </div>

                        <div class="mb-3">
                            <label for="remarks" class="form-label">Remarks</label>
                            <textarea class="form-control" id="remarks" name="remarks" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-gradient">
                            <i class="fas fa-sync me-2"></i>Update Status
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteShipmentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger"><i class="fas fa-exclamation-triangle me-2"></i>Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete shipment <strong id="delete_shipment_tracking"></strong>?</p>
                    <p class="text-danger"><small>This action cannot be undone.</small></p>
                </div>
                <div class="modal-footer">
                    <form id="deleteShipmentForm">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="shipment_id" id="delete_shipment_id">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="ajax" value="1">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i>Delete Shipment
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    <!-- Frontend JS: AJAX + Live refresh + handlers -->
    <script>
(function(){
    const partialUrl = 'shipments.php?partial=1';
    const csrfToken = '<?php echo generateCSRFToken(); ?>'; // server-side token (safe; rotates per session)

    // ---------------------------
    // Utility: show/hide top navbar
    // ---------------------------
    function toggleNavigation(hide) {
        const navbar = document.querySelector('.navbar-custom');
        if (navbar) {
            navbar.style.display = hide ? 'none' : 'flex';
        }
    }

    // ---------------------------
    // Utility: display temporary alert
    // ---------------------------
    function showAlert(msg, type='success', timeout=4000) {
        const container = document.createElement('div');
        container.className = `alert alert-${type} alert-dismissible fade show`;
        container.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>${msg}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
        document.body.prepend(container);
        setTimeout(()=>{ try { container.remove(); } catch(e){} }, timeout);
    }

    // ---------------------------
    // Refresh shipments container (fetch partial HTML)
    // ---------------------------
    async function refreshShipments() {
        try {
            const res = await fetch(partialUrl, {cache: 'no-store'});
            if (!res.ok) throw new Error('Failed to load shipments');
            const html = await res.text();
            const container = document.getElementById('shipmentsContainer');
            container.innerHTML = html;
        } catch (err) {
            console.error(err);
        }
    }

    // Polling: refresh every 12 seconds
    let pollingInterval = setInterval(refreshShipments, 12000);

    // ---------------------------
    // Search & Filter behavior
    // ---------------------------
    function performSearchFilter() {
        const q = document.getElementById('searchShipment').value.trim().toLowerCase();
        const status = document.getElementById('filterStatus').value;
        const courier = document.getElementById('filterCourier').value;
        const items = document.querySelectorAll('.shipment-item');
        let visible = 0;
        items.forEach(item=>{
            const trk = item.getAttribute('data-tracking') || '';
            const st = item.getAttribute('data-status') || '';
            const c = item.getAttribute('data-courier') || '';
            let show = true;
            if (q && trk.indexOf(q) === -1) show = false;
            if (status && st !== status) show = false;
            if (courier && c !== courier) show = false;
            item.style.display = show ? 'block' : 'none';
            if (show) visible++;
        });
    }

    document.getElementById('searchShipment').addEventListener('input', performSearchFilter);
    document.getElementById('filterStatus').addEventListener('change', performSearchFilter);
    document.getElementById('filterCourier').addEventListener('change', performSearchFilter);
    document.getElementById('clearFiltersBtn').addEventListener('click', ()=>{
        document.getElementById('searchShipment').value = '';
        document.getElementById('filterStatus').value = '';
        document.getElementById('filterCourier').value = '';
        performSearchFilter();
    });

    // ---------------------------
    // Add Shipment form (AJAX)
    // ---------------------------
    const addForm = document.getElementById('addShipmentForm');
    addForm.addEventListener('submit', async function(e){
        e.preventDefault();
        const fd = new FormData(addForm);
        fd.set('csrf_token', csrfToken);
        fd.set('ajax', '1');
        try {
            const res = await fetch('shipments.php', {method: 'POST', body: fd});
            const data = await res.json();
            if (data.status === 'success') {
                showAlert(data.message, 'success');
                const modal = bootstrap.Modal.getInstance(document.getElementById('addShipmentModal'));
                modal.hide();
                addForm.reset();
                await refreshShipments();
            } else {
                showAlert(data.message || 'Error', 'danger');
            }
        } catch (err) {
            console.error(err);
            showAlert('Network error', 'danger');
        }
    });

    // ---------------------------
    // View shipment details
    // ---------------------------
    window.viewShipment = function(shipment) {
        const html = `
            <div class="content-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h5 class="mb-1">${escapeHtml(shipment.tracking_number)}</h5>
                        <small class="text-muted">${escapeHtml(shipment.customer_name)} • ${escapeHtml(shipment.courier_name)}</small>
                    </div>
                    <div>
                        <span class="status-badge ${statusClass(shipment.shipment_status)}">
                            ${escapeHtml(capitalize(shipment.shipment_status.replace(/_/g, ' ')))}
                        </span>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-6"><strong>Sender:</strong><br>${escapeHtml(shipment.sender_name)}<br>${escapeHtml(shipment.sender_phone)}<br>${escapeHtml(shipment.sender_address)}</div>
                    <div class="col-6"><strong>Receiver:</strong><br>${escapeHtml(shipment.receiver_name)}<br>${escapeHtml(shipment.receiver_phone)}<br>${escapeHtml(shipment.receiver_address)}</div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-4"><strong>Weight</strong><br>${escapeHtml(shipment.weight)} kg</div>
                    <div class="col-4"><strong>Service</strong><br>${escapeHtml(shipment.service_type)}</div>
                    <div class="col-4"><strong>Total</strong><br>${escapeHtml(shipment.total_cost)}</div>
                </div>
                <hr>
                <div><strong>Special Instructions</strong><br>${escapeHtml(shipment.special_instructions || 'N/A')}</div>
            </div>
        `;
        document.getElementById('viewShipmentContent').innerHTML = html;

        // Hide navbar while modal open
        toggleNavigation(true);

        new bootstrap.Modal(document.getElementById('viewShipmentModal')).show();
    };

    // ---------------------------
    // Update status (open modal)
    // ---------------------------
    window.updateStatus = function(shipmentId, tracking) {
        document.getElementById('update_shipment_id').value = shipmentId;
        document.getElementById('shipment_status').value = 'in_transit';
        document.getElementById('location').value = '';
        document.getElementById('remarks').value = '';

        // Hide navbar
        toggleNavigation(true);

        new bootstrap.Modal(document.getElementById('updateStatusModal')).show();
    };

    // Update status form submit (AJAX)
    const updateStatusForm = document.getElementById('updateStatusForm');
    updateStatusForm.addEventListener('submit', async function(e){
        e.preventDefault();
        const fd = new FormData(updateStatusForm);
        fd.set('csrf_token', csrfToken);
        fd.set('ajax', '1');
        try {
            const res = await fetch('shipments.php', {method: 'POST', body: fd});
            const data = await res.json();
            if (data.status === 'success') {
                showAlert(data.message, 'success');
                bootstrap.Modal.getInstance(document.getElementById('updateStatusModal')).hide();
                await refreshShipments();
            } else {
                showAlert(data.message || 'Error', 'danger');
            }
        } catch (err) {
            console.error(err);
            showAlert('Network error', 'danger');
        }
    });

    // ---------------------------
    // Delete shipment (open confirm)
    // ---------------------------
    window.deleteShipment = function(shipmentId, tracking) {
        document.getElementById('delete_shipment_id').value = shipmentId;
        document.getElementById('delete_shipment_tracking').textContent = tracking;

        // Hide navbar
        toggleNavigation(true);

        new bootstrap.Modal(document.getElementById('deleteShipmentModal')).show();
    };

    // Delete form submit (AJAX)
    const deleteForm = document.getElementById('deleteShipmentForm');
    deleteForm.addEventListener('submit', async function(e){
        e.preventDefault();
        const fd = new FormData(deleteForm);
        fd.set('csrf_token', csrfToken);
        fd.set('ajax', '1');
        try {
            const res = await fetch('shipments.php', {method: 'POST', body: fd});
            const data = await res.json();
            if (data.status === 'success') {
                showAlert(data.message, 'success');
                bootstrap.Modal.getInstance(document.getElementById('deleteShipmentModal')).hide();
                await refreshShipments();
            } else {
                showAlert(data.message || 'Error', 'danger');
            }
        } catch (err) {
            console.error(err);
            showAlert('Network error', 'danger');
        }
    });

    // ---------------------------
    // helpers
    // ---------------------------
    function escapeHtml(s) {
        if (!s && s !== 0) return '';
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }
    function capitalize(s){ return s.charAt(0).toUpperCase() + s.slice(1); }
    function statusClass(status) {
        switch(status) {
            case 'pending': return 'bg-warning text-dark';
            case 'in_transit': return 'bg-info text-white';
            case 'out_for_delivery': return 'bg-primary text-white';
            case 'delivered': return 'bg-success text-white';
            case 'cancelled': return 'bg-danger text-white';
            default: return 'bg-secondary text-white';
        }
    }

    // ---------------------------
    // Initial hooks
    // ---------------------------
    document.addEventListener('DOMContentLoaded', function(){
        performSearchFilter();

        // Ensure navbar shows again when modal closes
        const modalIds = ['viewShipmentModal', 'updateStatusModal', 'deleteShipmentModal', 'addShipmentModal'];
        modalIds.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.addEventListener('hidden.bs.modal', function() {
                    toggleNavigation(false);
                });
            }
        });
    });

})();
document.addEventListener('DOMContentLoaded', function(){
    const modalIds = ['viewShipmentModal', 'updateStatusModal', 'deleteShipmentModal', 'addShipmentModal'];

    modalIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            // jab modal open ho to navbar chupao
            el.addEventListener('shown.bs.modal', function() {
                const navbar = document.querySelector('.navbar-custom');
                if (navbar) navbar.style.display = 'none';
            });

            // jab modal band ho to navbar wapas dikhao
            el.addEventListener('hidden.bs.modal', function() {
                const navbar = document.querySelector('.navbar-custom');
                if (navbar) navbar.style.display = 'flex';
            });
        }
    });
});

</script>

</body>
</html>
