<?php
require_once 'config/database.php';
requireLogin();

$database = new Database();
$db = $database->connect();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setMessage('Invalid CSRF token', 'error');
    } else {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'add':
                $courier_name = sanitizeInput($_POST['courier_name']);
                $contact_person = sanitizeInput($_POST['contact_person']);
                $phone = sanitizeInput($_POST['phone']);
                $email = sanitizeInput($_POST['email']);
                $address = sanitizeInput($_POST['address']);
                $city = sanitizeInput($_POST['city']);
                $state = sanitizeInput($_POST['state']);
                $postal_code = sanitizeInput($_POST['postal_code']);
                $tracking_url = sanitizeInput($_POST['tracking_url']);
                $service_areas = sanitizeInput($_POST['service_areas']);
                
                try {
                    $stmt = $db->prepare("
                        INSERT INTO couriers (courier_name, contact_person, phone, email, address, city, state, postal_code, tracking_url, service_areas) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$courier_name, $contact_person, $phone, $email, $address, $city, $state, $postal_code, $tracking_url, $service_areas]);
                    setMessage('Courier added successfully!');
                } catch (PDOException $e) {
                    setMessage('Error adding courier: ' . $e->getMessage(), 'error');
                }
                break;
                
            case 'update':
                $id = (int)$_POST['courier_id'];
                $courier_name = sanitizeInput($_POST['courier_name']);
                $contact_person = sanitizeInput($_POST['contact_person']);
                $phone = sanitizeInput($_POST['phone']);
                $email = sanitizeInput($_POST['email']);
                $address = sanitizeInput($_POST['address']);
                $city = sanitizeInput($_POST['city']);
                $state = sanitizeInput($_POST['state']);
                $postal_code = sanitizeInput($_POST['postal_code']);
                $tracking_url = sanitizeInput($_POST['tracking_url']);
                $service_areas = sanitizeInput($_POST['service_areas']);
                $status = sanitizeInput($_POST['status']);
                
                try {
                    $stmt = $db->prepare("
                        UPDATE couriers SET courier_name=?, contact_person=?, phone=?, email=?, address=?, 
                               city=?, state=?, postal_code=?, tracking_url=?, service_areas=?, status=? 
                        WHERE id=?
                    ");
                    $stmt->execute([$courier_name, $contact_person, $phone, $email, $address, $city, $state, $postal_code, $tracking_url, $service_areas, $status, $id]);
                    setMessage('Courier updated successfully!');
                } catch (PDOException $e) {
                    setMessage('Error updating courier: ' . $e->getMessage(), 'error');
                }
                break;
                
            case 'delete':
                $id = (int)$_POST['courier_id'];
                try {
                    $stmt = $db->prepare("DELETE FROM couriers WHERE id = ?");
                    $stmt->execute([$id]);
                    setMessage('Courier deleted successfully!');
                } catch (PDOException $e) {
                    setMessage('Error deleting courier: ' . $e->getMessage(), 'error');
                }
                break;
        }
        
        header('Location: couriers.php');
        exit();
    }
}

// Get all couriers
try {
    $couriers = $db->query("SELECT * FROM couriers ORDER BY created_at DESC")->fetchAll();
} catch (PDOException $e) {
    $error = "Error fetching couriers: " . $e->getMessage();
}

$message = getMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courier Management - Admin Panel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Global Styles */
body {
    background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%), 
                linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
    background-blend-mode: overlay;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #1f2937;
    margin: 0;
    padding: 0;
}

/* Sidebar */
.sidebar {
    background: linear-gradient(180deg, #1e3a8a 0%, #4f46e5 100%);
    min-height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    z-index: 1000;
    transition: all 0.3s ease;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
}

.sidebar-item {
    color: rgba(255, 255, 255, 0.85);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.sidebar-item:hover,
.sidebar-item.active {
    color: white;
    background: rgba(255, 255, 255, 0.1);
    border-left-color: #3b82f6;
    transform: translateX(5px);
}

.sidebar h4 {
    font-size: 18px;   /* size chhota / bara karne ke liye */
    font-weight: 600;  /* boldness */
    color: #fff;       /* white hi rakho */
    margin: 0;         /* gap remove */
}


/* Main Layout */
.main-content {
    margin-left: 250px;
    padding: 20px;
    transition: margin-left 0.3s ease;
}
.main-content.expanded { margin-left: 70px; }

.modal {
    z-index: 1060 !important; /* sabse upar */
}
.modal-backdrop {
    z-index: 1050 !important;
}
.dropdown-menu {
    z-index: 1055 !important;
}

/* Navbar */
.navbar-custom {
    background: #ffffff;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
    padding: 15px 20px;
    margin-bottom: 30px;
    position: relative;
    z-index: 2000;
    border-radius: 10px;
    z-index: 1030;
}
.navbar-custom h3,
.navbar-custom h5 {
    font-size: 1.2rem;      /* consistent size */
    font-weight: 600;       /* semi-bold clean look */
    color: #1e3a8a;         /* dashboard theme ka dark blue */
    margin: 0;              /* extra spacing hatao */
    letter-spacing: 0.5px;  /* thoda spacing for modern look */
}


/* Stat Cards */
.stat-card {
    background: #ffffff;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}
.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(45deg, #3b82f6, #10b981);
}
.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: white;
}

/* Charts & Cards */
.chart-container,
.content-card,
.recent-activity {
    background: #ffffff;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    margin-top: 20px;
}

/* Welcome Banner */
.welcome-banner {
    background: linear-gradient(135deg, #3b82f6 0%, #9333ea 100%);
    color: #ffffff;
    border-radius: 15px;
    padding: 30px;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}
.welcome-banner::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
    animation: rotate 10s linear infinite;
}
@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

/* Tables */
.table-modern {
    border-collapse: separate;
    border-spacing: 0;
    border-radius: 10px;
    overflow: hidden;
}
.table-modern th {
    background: #f8f9fa;
    border: none;
    padding: 15px;
    font-weight: 600;
    color: #495057;
}
.table-modern td {
    border: none;
    padding: 15px;
    border-bottom: 1px solid #e9ecef;
    vertical-align: middle;
}
.table-modern tr {
    transition: all 0.3s ease;
}
.table-modern tr:hover {
    background: #f8f9fa;
    transform: scale(1.01);
}

/* Status Badges */
.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: bold;
    white-space: nowrap;
}
.status-badge.success { background: #10b981; color: #fff; }
.status-badge.warning { background: #f59e0b; color: #fff; }
.status-badge.danger  { background: #ef4444; color: #fff; }
.status-badge.info    { background: #3b82f6; color: #fff; }

/* Buttons */
.btn-gradient {
    background: linear-gradient(45deg, #667eea, #764ba2);
    border: none;
    color: white;
    transition: all 0.3s ease;
}
.btn-gradient:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    color: white;
}

/* Forms & Modals */
.modal-content {
    border: none;
    border-radius: 15px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
}
.form-control {
    border: 1px solid #e1e5e9;
    border-radius: 10px;
    padding: 12px 15px;
    transition: all 0.3s ease;
}
.form-control:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

/* Animations */
.animate-slide-in {
    animation: slideIn 0.5s ease-out;
}
@keyframes slideIn {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}
.animate-counter {
    animation: countUp 2s ease-out;
}
@keyframes countUp {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* Activity Section */
.activity-item {
    padding: 15px;
    border-bottom: 1px solid #f8f9fa;
    transition: background 0.3s ease;
}
.activity-item:hover { background: #f8f9fa; }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-center border-bottom border-secondary">
            <h4 class="text-white mb-0">
                <i class="fas fa-truck-fast me-2"></i>
                 <span class="sidebar-text">Admin Panel</span>
            </h4>
        </div>
        
        <nav class="mt-3">
            <a href="dashboard.php" class="sidebar-item">
                <i class="fas fa-tachometer-alt me-3"></i>Dashboard
            </a>
            <a href="couriers.php" class="sidebar-item active">
                <i class="fas fa-truck me-3"></i>Couriers
            </a>
            <a href="agents.php" class="sidebar-item">
                <i class="fas fa-users me-3"></i>Agents
            </a>
            <a href="customers.php" class="sidebar-item">
                <i class="fas fa-user-friends me-3"></i>Customers
            </a>
            <a href="shipments.php" class="sidebar-item">
                <i class="fas fa-box me-3"></i>Shipments
            </a>
            <a href="reports.php" class="sidebar-item">
                <i class="fas fa-chart-bar me-3"></i>Reports
            </a>
            <a href="logout.php" class="sidebar-item">
                <i class="fas fa-sign-out-alt me-3"></i>Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation -->
        <nav class="navbar-custom d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-truck me-2 text-primary"></i>Courier Management</h5>
            <div class="d-flex align-items-center">
                <span class="me-3">Welcome, <?php echo $_SESSION['full_name']; ?></span>
                <div class="dropdown">
                    <button class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fas fa-user"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-cog me-2"></i>Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Alert Messages -->
        <?php if ($message): ?>
        <div class="alert alert-<?php echo $message['type'] === 'error' ? 'danger' : 'success'; ?> alert-dismissible fade show animate-slide-in" role="alert">
            <i class="fas fa-<?php echo $message['type'] === 'error' ? 'exclamation-triangle' : 'check-circle'; ?> me-2"></i>
            <?php echo $message['message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Add New Courier Button -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0">All Couriers</h3>
            <button type="button" class="btn btn-gradient" data-bs-toggle="modal" data-bs-target="#addCourierModal">
                <i class="fas fa-plus me-2"></i>Add New Courier
            </button>
        </div>

        <!-- Couriers Table -->
        <div class="content-card">
            <div class="table-responsive">
                <table class="table table-modern">
                    <thead>
                        <tr>
                            <th>Courier Name</th>
                            <th>Contact Person</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>City</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($couriers as $courier): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                        <i class="fas fa-truck"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0"><?php echo htmlspecialchars($courier['courier_name']); ?></h6>
                                        <small class="text-muted">ID: <?php echo $courier['id']; ?></small>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($courier['contact_person']); ?></td>
                            <td><?php echo htmlspecialchars($courier['phone']); ?></td>
                            <td><?php echo htmlspecialchars($courier['email']); ?></td>
                            <td><?php echo htmlspecialchars($courier['city']); ?>, <?php echo htmlspecialchars($courier['state']); ?></td>
                            <td>
                                <span class="status-badge <?php echo $courier['status'] === 'active' ? 'bg-success text-white' : 'bg-danger text-white'; ?>">
                                    <?php echo ucfirst($courier['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-info" 
                                            onclick="viewCourier(<?php echo htmlspecialchars(json_encode($courier)); ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-warning" 
                                            onclick="editCourier(<?php echo htmlspecialchars(json_encode($courier)); ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger" 
                                            onclick="deleteCourier(<?php echo $courier['id']; ?>, '<?php echo htmlspecialchars($courier['courier_name']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Courier Modal -->
    <div class="modal fade" id="addCourierModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Add New Courier</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="courier_name" class="form-label">Courier Name *</label>
                                <input type="text" class="form-control" id="courier_name" name="courier_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="contact_person" class="form-label">Contact Person *</label>
                                <input type="text" class="form-control" id="contact_person" name="contact_person" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">Phone *</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Address *</label>
                            <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="city" class="form-label">City *</label>
                                <input type="text" class="form-control" id="city" name="city" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="state" class="form-label">State *</label>
                                <input type="text" class="form-control" id="state" name="state" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="postal_code" class="form-label">Postal Code *</label>
                                <input type="text" class="form-control" id="postal_code" name="postal_code" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="tracking_url" class="form-label">Tracking URL</label>
                            <input type="url" class="form-control" id="tracking_url" name="tracking_url" 
                                   placeholder="https://example.com/track">
                        </div>
                        
                        <div class="mb-3">
                            <label for="service_areas" class="form-label">Service Areas</label>
                            <textarea class="form-control" id="service_areas" name="service_areas" rows="2" 
                                      placeholder="List of cities or regions served"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-gradient">
                            <i class="fas fa-save me-2"></i>Add Courier
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Courier Modal -->
    <div class="modal fade" id="editCourierModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Courier</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="courier_id" id="edit_courier_id">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_courier_name" class="form-label">Courier Name *</label>
                                <input type="text" class="form-control" id="edit_courier_name" name="courier_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_contact_person" class="form-label">Contact Person *</label>
                                <input type="text" class="form-control" id="edit_contact_person" name="contact_person" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_phone" class="form-label">Phone *</label>
                                <input type="tel" class="form-control" id="edit_phone" name="phone" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="edit_email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_address" class="form-label">Address *</label>
                            <textarea class="form-control" id="edit_address" name="address" rows="2" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="edit_city" class="form-label">City *</label>
                                <input type="text" class="form-control" id="edit_city" name="city" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_state" class="form-label">State *</label>
                                <input type="text" class="form-control" id="edit_state" name="state" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_postal_code" class="form-label">Postal Code *</label>
                                <input type="text" class="form-control" id="edit_postal_code" name="postal_code" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_status" class="form-label">Status *</label>
                                <select class="form-control" id="edit_status" name="status" required>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_tracking_url" class="form-label">Tracking URL</label>
                            <input type="url" class="form-control" id="edit_tracking_url" name="tracking_url">
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_service_areas" class="form-label">Service Areas</label>
                            <textarea class="form-control" id="edit_service_areas" name="service_areas" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-gradient">
                            <i class="fas fa-save me-2"></i>Update Courier
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Courier Modal -->
    <div class="modal fade" id="viewCourierModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-eye me-2"></i>Courier Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary">Basic Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Courier Name:</strong></td><td id="view_courier_name"></td></tr>
                                <tr><td><strong>Contact Person:</strong></td><td id="view_contact_person"></td></tr>
                                <tr><td><strong>Phone:</strong></td><td id="view_phone"></td></tr>
                                <tr><td><strong>Email:</strong></td><td id="view_email"></td></tr>
                                <tr><td><strong>Status:</strong></td><td id="view_status"></td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-primary">Address Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Address:</strong></td><td id="view_address"></td></tr>
                                <tr><td><strong>City:</strong></td><td id="view_city"></td></tr>
                                <tr><td><strong>State:</strong></td><td id="view_state"></td></tr>
                                <tr><td><strong>Postal Code:</strong></td><td id="view_postal_code"></td></tr>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6 class="text-primary">Additional Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Tracking URL:</strong></td><td id="view_tracking_url"></td></tr>
                                <tr><td><strong>Service Areas:</strong></td><td id="view_service_areas"></td></tr>
                                <tr><td><strong>Created:</strong></td><td id="view_created_at"></td></tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteCourierModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger"><i class="fas fa-exclamation-triangle me-2"></i>Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete <strong id="delete_courier_name"></strong>?</p>
                    <p class="text-danger"><small>This action cannot be undone.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="courier_id" id="delete_courier_id">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i>Delete Courier
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // View Courier Details
        function viewCourier(courier) {
            document.getElementById('view_courier_name').textContent = courier.courier_name;
            document.getElementById('view_contact_person').textContent = courier.contact_person;
            document.getElementById('view_phone').textContent = courier.phone;
            document.getElementById('view_email').textContent = courier.email;
            document.getElementById('view_status').innerHTML = `<span class="status-badge ${courier.status === 'active' ? 'bg-success' : 'bg-danger'} text-white">${courier.status.charAt(0).toUpperCase() + courier.status.slice(1)}</span>`;
            document.getElementById('view_address').textContent = courier.address;
            document.getElementById('view_city').textContent = courier.city;
            document.getElementById('view_state').textContent = courier.state;
            document.getElementById('view_postal_code').textContent = courier.postal_code;
            document.getElementById('view_tracking_url').innerHTML = courier.tracking_url ? `<a href="${courier.tracking_url}" target="_blank">${courier.tracking_url}</a>` : 'N/A';
            document.getElementById('view_service_areas').textContent = courier.service_areas || 'N/A';
            document.getElementById('view_created_at').textContent = new Date(courier.created_at).toLocaleDateString();
            
            new bootstrap.Modal(document.getElementById('viewCourierModal')).show();
        }

        // Edit Courier
        function editCourier(courier) {
            document.getElementById('edit_courier_id').value = courier.id;
            document.getElementById('edit_courier_name').value = courier.courier_name;
            document.getElementById('edit_contact_person').value = courier.contact_person;
            document.getElementById('edit_phone').value = courier.phone;
            document.getElementById('edit_email').value = courier.email;
            document.getElementById('edit_address').value = courier.address;
            document.getElementById('edit_city').value = courier.city;
            document.getElementById('edit_state').value = courier.state;
            document.getElementById('edit_postal_code').value = courier.postal_code;
            document.getElementById('edit_status').value = courier.status;
            document.getElementById('edit_tracking_url').value = courier.tracking_url || '';
            document.getElementById('edit_service_areas').value = courier.service_areas || '';
            
            new bootstrap.Modal(document.getElementById('editCourierModal')).show();
        }

        // Delete Courier
        function deleteCourier(id, name) {
            document.getElementById('delete_courier_id').value = id;
            document.getElementById('delete_courier_name').textContent = name;
            
            new bootstrap.Modal(document.getElementById('deleteCourierModal')).show();
        }

        // Form validation and animations
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.style.transform = 'scale(1.02)';
            });
            
            input.addEventListener('blur', function() {
                this.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>