<?php
require_once 'config/database.php';
requireLogin();

$database = new Database();
$db = $database->connect();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setMessage('Invalid CSRF token', 'error');
    } else {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'add':
                $customer_code = generateCode('CUST');
                $full_name = sanitizeInput($_POST['full_name']);
                $email = sanitizeInput($_POST['email']);
                $phone = sanitizeInput($_POST['phone']);
                $address = sanitizeInput($_POST['address']);
                $city = sanitizeInput($_POST['city']);
                $state = sanitizeInput($_POST['state']);
                $postal_code = sanitizeInput($_POST['postal_code']);
                $customer_type = sanitizeInput($_POST['customer_type']);
                $company_name = sanitizeInput($_POST['company_name']);
                $registration_date = sanitizeInput($_POST['registration_date']);
                
                try {
                    $stmt = $db->prepare("
                        INSERT INTO customers (customer_code, full_name, email, phone, address, city, state, postal_code, customer_type, company_name, registration_date) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$customer_code, $full_name, $email, $phone, $address, $city, $state, $postal_code, $customer_type, $company_name, $registration_date]);
                    setMessage('Customer added successfully!');
                } catch (PDOException $e) {
                    setMessage('Error adding customer: ' . $e->getMessage(), 'error');
                }
                break;
                
            case 'update':
                $id = (int)$_POST['customer_id'];
                $full_name = sanitizeInput($_POST['full_name']);
                $email = sanitizeInput($_POST['email']);
                $phone = sanitizeInput($_POST['phone']);
                $address = sanitizeInput($_POST['address']);
                $city = sanitizeInput($_POST['city']);
                $state = sanitizeInput($_POST['state']);
                $postal_code = sanitizeInput($_POST['postal_code']);
                $customer_type = sanitizeInput($_POST['customer_type']);
                $company_name = sanitizeInput($_POST['company_name']);
                $registration_date = sanitizeInput($_POST['registration_date']);
                $status = sanitizeInput($_POST['status']);
                
                try {
                    $stmt = $db->prepare("
                        UPDATE customers SET full_name=?, email=?, phone=?, address=?, city=?, state=?, 
                               postal_code=?, customer_type=?, company_name=?, registration_date=?, status=? 
                        WHERE id=?
                    ");
                    $stmt->execute([$full_name, $email, $phone, $address, $city, $state, $postal_code, $customer_type, $company_name, $registration_date, $status, $id]);
                    setMessage('Customer updated successfully!');
                } catch (PDOException $e) {
                    setMessage('Error updating customer: ' . $e->getMessage(), 'error');
                }
                break;
                
            case 'delete':
                $id = (int)$_POST['customer_id'];
                try {
                    $stmt = $db->prepare("DELETE FROM customers WHERE id = ?");
                    $stmt->execute([$id]);
                    setMessage('Customer deleted successfully!');
                } catch (PDOException $e) {
                    setMessage('Error deleting customer: ' . $e->getMessage(), 'error');
                }
                break;
        }
        
        header('Location: customers.php');
        exit();
    }
}

// Get all customers with shipment counts
try {
    $customers = $db->query("
        SELECT c.*, COUNT(s.id) as shipment_count, 
               SUM(s.total_cost) as total_spent,
               MAX(s.created_at) as last_shipment_date
        FROM customers c 
        LEFT JOIN shipments s ON c.id = s.customer_id 
        GROUP BY c.id 
        ORDER BY c.created_at DESC
    ")->fetchAll();
} catch (PDOException $e) {
    $error = "Error fetching customers: " . $e->getMessage();
}

$message = getMessage();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Management - Admin Panel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
       body {
 background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%), 
                linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
    background-blend-mode: overlay;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.sidebar {
     background: linear-gradient(180deg, #1e3a8a 0%, #4f46e5 100%);
    min-height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    z-index: 1000;
    transition: all 0.3s ease;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
}

.sidebar-item {
    color: rgba(255, 255, 255, 0.85);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.sidebar-item:hover,
.sidebar-item.active {
    color: white;
    background: rgba(255, 255, 255, 0.1);
    border-left-color: #3b82f6;
    transform: translateX(5px);
}

.sidebar h4 {
    font-size: 18px;   /* size chhota / bara karne ke liye */
    font-weight: 600;  /* boldness */
    color: #fff;       /* white hi rakho */
    margin: 0;         /* gap remove */
}


.main-content {
    margin-left: 250px;
    padding: 20px;
}

.content-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    padding: 30px;
    margin-bottom: 30px;
}
.modal {
    z-index: 1060 !important; /* sabse upar */
}
.modal-backdrop {
    z-index: 1050 !important;
}
.dropdown-menu {
    z-index: 1055 !important;
}

.navbar-custom {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    padding: 15px 30px;
    margin-bottom: 30px;
    border-radius: 15px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    z-index: 1030;
    
}
.navbar-custom h3,
.navbar-custom h5 {
    font-size: 1.2rem;      /* consistent size */
    font-weight: 600;       /* semi-bold clean look */
    color: #1e3a8a;         /* dashboard theme ka dark blue */
    margin: 0;              /* extra spacing hatao */
    letter-spacing: 0.5px;  /* thoda spacing for modern look */
}



.btn-gradient {
    background: linear-gradient(45deg, #3b82f6, #9333ea);
    border: none;
    color: white;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn-gradient:hover {
    transform: translateY(-3px);
    color: white;
}

.btn-gradient::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s;
}

.btn-gradient:hover::before {
    left: 100%;
}

.customer-card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 20px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    border-left: 4px solid #667eea;
    position: relative;
    overflow: hidden;
}

.customer-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(45deg, #667eea, #764ba2);
    transform: scaleX(0);
    transition: transform 0.3s ease;
}

.customer-card:hover::before {
    transform: scaleX(1);
}

.customer-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.5rem;
    margin-right: 20px;
    position: relative;
    overflow: hidden;
    background: linear-gradient(135deg, #3b82f6, #9333ea);
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.status-badge {
    padding: 8px 16px;
    border-radius: 25px;
    font-size: 0.8rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    position: relative;
    overflow: hidden;
    color: white;
}

.status-badge.success {
    background: #10b981;
}
.status-badge.warning {
    background: #f59e0b;
}
.status-badge.danger {
    background: #ef4444;
}

.stats-mini {
    background: linear-gradient(135deg, #3b82f6 0%, #9333ea 100%);
    color: white;
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
}
.stats-mini::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
    animation: rotate 15s linear infinite;
}
.form-control {
    border: 2px solid #e1e8ed;
    border-radius: 12px;
    padding: 15px 20px;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.9);
}

.form-control:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.3rem rgba(102, 126, 234, 0.15);
    transform: translateY(-2px);
    background: white;
}

.search-box {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 20px;
    backdrop-filter: blur(10px);
}

.animate-slide-in {
    animation: slideInUp 0.6s ease-out;
}

@keyframes slideInUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}

.modal-content {
    border: none;
    border-radius: 20px;
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
    backdrop-filter: blur(10px);
    background: rgba(255, 255, 255, 0.95);
}

.info-label {
    font-size: 0.8rem;
    color: #6c757d;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.info-value {
    font-weight: 600;
    color: #495057;
}

.customer-stats {
    background: linear-gradient(45deg, #f8f9fa, #e9ecef);
    border-radius: 10px;
    padding: 15px;
    margin-top: 15px;
}

.floating-action {
    position: fixed;
    bottom: 30px;
    right: 30px;
    z-index: 1000;
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
}

        </style>
        </head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-center border-bottom border-secondary">
            <h4 class="text-white mb-0">
                <i class="fas fa-user-friends me-2"></i>
                 <span class="sidebar-text">Admin Panel</span>
            </h4>
        </div>
        
        <nav class="mt-3">
            <a href="dashboard.php" class="sidebar-item">
                <i class="fas fa-tachometer-alt me-3"></i>Dashboard
            </a>
            <a href="couriers.php" class="sidebar-item">
                <i class="fas fa-truck me-3"></i>Couriers
            </a>
            <a href="agents.php" class="sidebar-item">
                <i class="fas fa-users me-3"></i>Agents
            </a>
            <a href="customers.php" class="sidebar-item active">
                <i class="fas fa-user-friends me-3"></i>Customers
            </a>
            <a href="shipments.php" class="sidebar-item">
                <i class="fas fa-box me-3"></i>Shipments
            </a>
            <a href="reports.php" class="sidebar-item">
                <i class="fas fa-chart-bar me-3"></i>Reports
            </a>
            <a href="logout.php" class="sidebar-item">
                <i class="fas fa-sign-out-alt me-3"></i>Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation -->
        <nav class="navbar-custom d-flex justify-content-between align-items-center">
    <h5 class="mb-0"><i class="fas fa-user-friends me-2 text-primary"></i>Customer Management</h5>
    <div class="d-flex align-items-center">
        <span class="me-3">Welcome, <?php echo $_SESSION['full_name']; ?></span>
        <div class="dropdown">
            <button class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user"></i>
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-cog me-2"></i>Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Alert Messages -->
        <?php if ($message): ?>
        <div class="alert alert-<?php echo $message['type'] === 'error' ? 'danger' : 'success'; ?> alert-dismissible fade show animate-slide-in" role="alert">
            <i class="fas fa-<?php echo $message['type'] === 'error' ? 'exclamation-triangle' : 'check-circle'; ?> me-2"></i>
            <?php echo $message['message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-mini text-center">
                    <h4><?php echo count(array_filter($customers, function($c) { return $c['status'] === 'active'; })); ?></h4>
                    <small>Active Customers</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-mini text-center">
                    <h4><?php echo count(array_filter($customers, function($c) { return $c['customer_type'] === 'business'; })); ?></h4>
                    <small>Business Customers</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-mini text-center">
                    <h4><?php echo count(array_filter($customers, function($c) { return $c['customer_type'] === 'individual'; })); ?></h4>
                    <small>Individual Customers</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-mini text-center">
                    <h4><?php echo array_sum(array_column($customers, 'shipment_count')); ?></h4>
                    <small>Total Shipments</small>
                </div>
            </div>
        </div>

        <!-- Search Box -->
        <div class="search-box">
            <div class="row">
                <div class="col-md-4">
                    <input type="text" class="form-control" id="searchCustomer" placeholder="Search customers...">
                </div>
                <div class="col-md-3">
                    <select class="form-control" id="filterType">
                        <option value="">All Types</option>
                        <option value="individual">Individual</option>
                        <option value="business">Business</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-control" id="filterStatus">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="suspended">Suspended</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-primary w-100" onclick="clearFilters()">
                        <i class="fas fa-times"></i> Clear
                    </button>
                </div>
            </div>
        </div>

        <!-- Customers Grid -->
        <div class="row" id="customersContainer">
            <?php foreach ($customers as $customer): ?>
            <div class="col-md-6 col-lg-4 customer-item" 
                 data-name="<?php echo strtolower($customer['full_name']); ?>" 
                 data-type="<?php echo $customer['customer_type']; ?>" 
                 data-status="<?php echo $customer['status']; ?>">
                <div class="customer-card">
                    <div class="d-flex align-items-center mb-3">
                        <div class="customer-avatar" style="background: linear-gradient(45deg, #<?php echo substr(md5($customer['full_name']), 0, 6); ?>, #<?php echo substr(md5($customer['customer_code']), 0, 6); ?>);">
                            <?php echo strtoupper(substr($customer['full_name'], 0, 1)); ?>
                        </div>
                        <div class="flex-grow-1">
                            <h5 class="mb-1"><?php echo htmlspecialchars($customer['full_name']); ?></h5>
                            <small class="text-muted"><?php echo htmlspecialchars($customer['customer_code']); ?></small>
                            <br>
                            <span class="badge bg-<?php echo $customer['customer_type'] === 'business' ? 'primary' : 'info'; ?>">
                                <?php echo ucfirst($customer['customer_type']); ?>
                            </span>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" onclick="viewCustomer(<?php echo htmlspecialchars(json_encode($customer)); ?>)">
                                    <i class="fas fa-eye me-2"></i>View Details
                                </a></li>
                                <li><a class="dropdown-item" href="#" onclick="editCustomer(<?php echo htmlspecialchars(json_encode($customer)); ?>)">
                                    <i class="fas fa-edit me-2"></i>Edit
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="#" onclick="deleteCustomer(<?php echo $customer['id']; ?>, '<?php echo htmlspecialchars($customer['full_name']); ?>')">
                                    <i class="fas fa-trash me-2"></i>Delete
                                </a></li>
                            </ul>
                        </div>
                    </div>
                    
                  <div class="row mb-3">
    <div class="col-12">
        <div class="info-label">Email</div>
        <div class="info-value"><?php echo htmlspecialchars($customer['email']); ?></div>
    </div>
    <div class="col-12 mt-2">
        <div class="info-label">Phone</div>
        <div class="info-value"><?php echo htmlspecialchars($customer['phone']); ?></div>
    </div>
</div>
                    
                    <div class="row mb-3">
                        <div class="col-6">
                            <div class="info-label">Location</div>
                            <div class="info-value"><?php echo htmlspecialchars($customer['city']); ?>, <?php echo htmlspecialchars($customer['state']); ?></div>
                        </div>
                        <div class="col-6">
                            <div class="info-label">Shipments</div>
                            <div class="info-value text-primary"><?php echo $customer['shipment_count']; ?></div>
                        </div>
                    </div>
                    
                    <?php if ($customer['company_name']): ?>
                    <div class="mb-3">
                        <div class="info-label">Company</div>
                        <div class="info-value"><?php echo htmlspecialchars($customer['company_name']); ?></div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="customer-stats">
                        <div class="row text-center">
                            <div class="col-6">
                                <div class="info-label">Total Spent</div>
                                <div class="info-value text-success"><?php echo formatCurrency($customer['total_spent'] ?? 0); ?></div>
                            </div>
                            <div class="col-6">
                                <div class="info-label">Last Order</div>
                                <div class="info-value"><?php echo $customer['last_shipment_date'] ? formatDate($customer['last_shipment_date']) : 'Never'; ?></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <span class="status-badge <?php 
                            switch($customer['status']) {
                                case 'active': echo 'bg-success text-white'; break;
                                case 'inactive': echo 'bg-warning text-dark'; break;
                                case 'suspended': echo 'bg-danger text-white'; break;
                                default: echo 'bg-secondary text-white';
                            }
                        ?>">
                            <?php echo ucfirst($customer['status']); ?>
                        </span>
                        <small class="text-muted ms-2">
                            Registered: <?php echo formatDate($customer['registration_date']); ?>
                        </small>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Floating Add Button -->
    <button type="button" class="btn btn-gradient btn-lg floating-action" data-bs-toggle="modal" data-bs-target="#addCustomerModal">
        <i class="fas fa-user-plus me-2"></i>Add Customer
    </button>

    <!-- Add Customer Modal -->
    <div class="modal fade" id="addCustomerModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Add New Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="full_name" class="form-label">Full Name *</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">Phone *</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="customer_type" class="form-label">Customer Type *</label>
                                <select class="form-control" id="customer_type" name="customer_type" required onchange="toggleCompanyField()">
                                    <option value="individual">Individual</option>
                                    <option value="business">Business</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3" id="company_field" style="display: none;">
                            <label for="company_name" class="form-label">Company Name</label>
                            <input type="text" class="form-control" id="company_name" name="company_name">
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Address *</label>
                            <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="city" class="form-label">City *</label>
                                <input type="text" class="form-control" id="city" name="city" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="state" class="form-label">State *</label>
                                <input type="text" class="form-control" id="state" name="state" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="postal_code" class="form-label">Postal Code *</label>
                                <input type="text" class="form-control" id="postal_code" name="postal_code" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="registration_date" class="form-label">Registration Date *</label>
                            <input type="date" class="form-control" id="registration_date" name="registration_date" 
                                   value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-gradient">
                            <i class="fas fa-save me-2"></i>Add Customer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Customer Modal -->
    <div class="modal fade" id="editCustomerModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="customer_id" id="edit_customer_id">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_full_name" class="form-label">Full Name *</label>
                                <input type="text" class="form-control" id="edit_full_name" name="full_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="edit_email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="edit_phone" class="form-label">Phone *</label>
                                <input type="tel" class="form-control" id="edit_phone" name="phone" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_customer_type" class="form-label">Customer Type *</label>
                                <select class="form-control" id="edit_customer_type" name="customer_type" required onchange="toggleEditCompanyField()">
                                    <option value="individual">Individual</option>
                                    <option value="business">Business</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_status" class="form-label">Status *</label>
                                <select class="form-control" id="edit_status" name="status" required>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                    <option value="suspended">Suspended</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3" id="edit_company_field">
                            <label for="edit_company_name" class="form-label">Company Name</label>
                            <input type="text" class="form-control" id="edit_company_name" name="company_name">
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_address" class="form-label">Address *</label>
                            <textarea class="form-control" id="edit_address" name="address" rows="2" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="edit_city" class="form-label">City *</label>
                                <input type="text" class="form-control" id="edit_city" name="city" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_state" class="form-label">State *</label>
                                <input type="text" class="form-control" id="edit_state" name="state" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_postal_code" class="form-label">Postal Code *</label>
                                <input type="text" class="form-control" id="edit_postal_code" name="postal_code" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_registration_date" class="form-label">Registration Date *</label>
                            <input type="date" class="form-control" id="edit_registration_date" name="registration_date" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-gradient">
                            <i class="fas fa-save me-2"></i>Update Customer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Customer Modal -->
    <div class="modal fade" id="viewCustomerModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-eye me-2"></i>Customer Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <div class="customer-avatar mx-auto" id="view_avatar" style="width: 80px; height: 80px; font-size: 2rem;"></div>
                        <h4 class="mt-3" id="view_customer_name"></h4>
                        <span class="badge" id="view_customer_type_badge"></span>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary">Personal Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Customer Code:</strong></td><td id="view_customer_code"></td></tr>
                                <tr><td><strong>Full Name:</strong></td><td id="view_full_name"></td></tr>
                                <tr><td><strong>Email:</strong></td><td id="view_email"></td></tr>
                                <tr><td><strong>Phone:</strong></td><td id="view_phone"></td></tr>
                                <tr><td><strong>Customer Type:</strong></td><td id="view_customer_type"></td></tr>
                                <tr><td><strong>Company:</strong></td><td id="view_company_name"></td></tr>
                                <tr><td><strong>Status:</strong></td><td id="view_status"></td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-primary">Address & Statistics</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Address:</strong></td><td id="view_address"></td></tr>
                                <tr><td><strong>City:</strong></td><td id="view_city"></td></tr>
                                <tr><td><strong>State:</strong></td><td id="view_state"></td></tr>
                                <tr><td><strong>Postal Code:</strong></td><td id="view_postal_code"></td></tr>
                                <tr><td><strong>Total Shipments:</strong></td><td id="view_shipment_count"></td></tr>
                                <tr><td><strong>Total Spent:</strong></td><td id="view_total_spent"></td></tr>
                                <tr><td><strong>Registration Date:</strong></td><td id="view_registration_date"></td></tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="editCustomerFromView()">
                        <i class="fas fa-edit me-2"></i>Edit Customer
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteCustomerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger"><i class="fas fa-exclamation-triangle me-2"></i>Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete customer <strong id="delete_customer_name"></strong>?</p>
                    <p class="text-danger"><small>This action cannot be undone and will affect all related shipments.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="customer_id" id="delete_customer_id">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i>Delete Customer
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentCustomerData = null;

        // Toggle company field based on customer type
        function toggleCompanyField() {
            const customerType = document.getElementById('customer_type').value;
            const companyField = document.getElementById('company_field');
            
            if (customerType === 'business') {
                companyField.style.display = 'block';
                document.getElementById('company_name').required = true;
            } else {
                companyField.style.display = 'none';
                document.getElementById('company_name').required = false;
                document.getElementById('company_name').value = '';
            }
        }

        function toggleEditCompanyField() {
            const customerType = document.getElementById('edit_customer_type').value;
            const companyField = document.getElementById('edit_company_field');
            
            if (customerType === 'business') {
                companyField.style.display = 'block';
            } else {
                companyField.style.display = 'none';
                document.getElementById('edit_company_name').value = '';
            }
        }

        // View Customer Details
        function viewCustomer(customer) {
            currentCustomerData = customer;
            
            // Set avatar
            const avatar = document.getElementById('view_avatar');
            const color1 = customer.full_name.charCodeAt(0) * 12345;
            const color2 = customer.customer_code.charCodeAt(0) * 54321;
            avatar.style.background = `linear-gradient(45deg, hsl(${color1 % 360}, 70%, 50%), hsl(${color2 % 360}, 70%, 50%))`;
            avatar.textContent = customer.full_name.charAt(0).toUpperCase();
            
            // Set customer info
            document.getElementById('view_customer_name').textContent = customer.full_name;
            document.getElementById('view_customer_code').textContent = customer.customer_code;
            document.getElementById('view_full_name').textContent = customer.full_name;
            document.getElementById('view_email').textContent = customer.email;
            document.getElementById('view_phone').textContent = customer.phone;
            document.getElementById('view_customer_type').textContent = customer.customer_type.charAt(0).toUpperCase() + customer.customer_type.slice(1);
            document.getElementById('view_company_name').textContent = customer.company_name || 'N/A';
            document.getElementById('view_address').textContent = customer.address;
            document.getElementById('view_city').textContent = customer.city;
            document.getElementById('view_state').textContent = customer.state;
            document.getElementById('view_postal_code').textContent = customer.postal_code;
            document.getElementById('view_shipment_count').textContent = customer.shipment_count;
            document.getElementById('view_total_spent').textContent = 'PKR ' + (customer.total_spent || 0).toLocaleString();
            document.getElementById('view_registration_date').textContent = new Date(customer.registration_date).toLocaleDateString();
            
            // Set status badge
            const statusBadge = document.getElementById('view_status');
            let statusClass = '';
            switch(customer.status) {
                case 'active': statusClass = 'bg-success text-white'; break;
                case 'inactive': statusClass = 'bg-warning text-dark'; break;
                case 'suspended': statusClass = 'bg-danger text-white'; break;
                default: statusClass = 'bg-secondary text-white';
            }
            statusBadge.innerHTML = `<span class="status-badge ${statusClass}">${customer.status.charAt(0).toUpperCase() + customer.status.slice(1)}</span>`;
            
            // Set type badge
            const typeBadge = document.getElementById('view_customer_type_badge');
            typeBadge.className = `badge ${customer.customer_type === 'business' ? 'bg-primary' : 'bg-info'}`;
            typeBadge.textContent = customer.customer_type.charAt(0).toUpperCase() + customer.customer_type.slice(1);
            
            new bootstrap.Modal(document.getElementById('viewCustomerModal')).show();
        }

        // Edit Customer from View Modal
        function editCustomerFromView() {
            bootstrap.Modal.getInstance(document.getElementById('viewCustomerModal')).hide();
            setTimeout(() => editCustomer(currentCustomerData), 300);
        }

        // Edit Customer
        function editCustomer(customer) {
            document.getElementById('edit_customer_id').value = customer.id;
            document.getElementById('edit_full_name').value = customer.full_name;
            document.getElementById('edit_email').value = customer.email;
            document.getElementById('edit_phone').value = customer.phone;
            document.getElementById('edit_customer_type').value = customer.customer_type;
            document.getElementById('edit_company_name').value = customer.company_name || '';
            document.getElementById('edit_address').value = customer.address;
            document.getElementById('edit_city').value = customer.city;
            document.getElementById('edit_state').value = customer.state;
            document.getElementById('edit_postal_code').value = customer.postal_code;
            document.getElementById('edit_registration_date').value = customer.registration_date;
            document.getElementById('edit_status').value = customer.status;
            
            toggleEditCompanyField();
            
            new bootstrap.Modal(document.getElementById('editCustomerModal')).show();
        }

        // Delete Customer
        function deleteCustomer(id, name) {
            document.getElementById('delete_customer_id').value = id;
            document.getElementById('delete_customer_name').textContent = name;
            
            new bootstrap.Modal(document.getElementById('deleteCustomerModal')).show();
        }

        // Search and Filter Functions
        function performSearch() {
            const searchTerm = document.getElementById('searchCustomer').value.toLowerCase();
            const typeFilter = document.getElementById('filterType').value;
            const statusFilter = document.getElementById('filterStatus').value;
            
            const customers = document.querySelectorAll('.customer-item');
            let visibleCount = 0;
            
            customers.forEach(customer => {
                const name = customer.getAttribute('data-name');
                const type = customer.getAttribute('data-type');
                const status = customer.getAttribute('data-status');
                
                let showCustomer = true;
                
                // Search filter
                if (searchTerm && !name.includes(searchTerm)) {
                    showCustomer = false;
                }
                
                // Type filter
                if (typeFilter && type !== typeFilter) {
                    showCustomer = false;
                }
                
                // Status filter
                if (statusFilter && status !== statusFilter) {
                    showCustomer = false;
                }
                
                if (showCustomer) {
                    customer.style.display = 'block';
                    customer.style.animation = 'slideInUp 0.5s ease-out';
                    visibleCount++;
                } else {
                    customer.style.display = 'none';
                }
            });
            
            // Show/hide no results message
            updateNoResultsMessage(visibleCount);
        }

        function updateNoResultsMessage(visibleCount) {
            let noResultsMsg = document.getElementById('noResultsMessage');
            
            if (visibleCount === 0) {
                if (!noResultsMsg) {
                    noResultsMsg = document.createElement('div');
                    noResultsMsg.id = 'noResultsMessage';
                    noResultsMsg.className = 'col-12 text-center py-5';
                    noResultsMsg.innerHTML = `
                        <div class="content-card">
                            <i class="fas fa-search fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">No customers found</h5>
                            <p class="text-muted">Try adjusting your search criteria or filters.</p>
                            <button class="btn btn-outline-primary" onclick="clearFilters()">
                                <i class="fas fa-times me-2"></i>Clear Filters
                            </button>
                        </div>
                    `;
                    document.getElementById('customersContainer').appendChild(noResultsMsg);
                }
            } else {
                if (noResultsMsg) {
                    noResultsMsg.remove();
                }
            }
        }

        function clearFilters() {
            document.getElementById('searchCustomer').value = '';
            document.getElementById('filterType').value = '';
            document.getElementById('filterStatus').value = '';
            performSearch();
        }

        // Event listeners
        document.getElementById('searchCustomer').addEventListener('input', performSearch);
        document.getElementById('filterType').addEventListener('change', performSearch);
        document.getElementById('filterStatus').addEventListener('change', performSearch);

        // Form animations and validations
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 5px 15px rgba(102, 126, 234, 0.2)';
            });
            
            input.addEventListener('blur', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            });
        });

        // Animate customer cards on load
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.customer-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
            
            // Initialize tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });

        // Form validation
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const requiredFields = form.querySelectorAll('[required]');
                let isValid = true;
                
                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        field.classList.add('is-invalid');
                        isValid = false;
                    } else {
                        field.classList.remove('is-invalid');
                    }
                });
                
                // Email validation
                const emailFields = form.querySelectorAll('input[type="email"]');
                emailFields.forEach(field => {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (field.value && !emailRegex.test(field.value)) {
                        field.classList.add('is-invalid');
                        isValid = false;
                    }
                });
                
                // Phone validation
                const phoneFields = form.querySelectorAll('input[type="tel"]');
                phoneFields.forEach(field => {
                    const phoneRegex = /^[\+]?[\d\s\-\(\)]+$/;
                    if (field.value && !phoneRegex.test(field.value)) {
                        field.classList.add('is-invalid');
                        isValid = false;
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    
                    // Show error message
                    let errorDiv = form.querySelector('.validation-error');
                    if (!errorDiv) {
                        errorDiv = document.createElement('div');
                        errorDiv.className = 'alert alert-danger validation-error mt-3';
                        form.querySelector('.modal-body').appendChild(errorDiv);
                    }
                    errorDiv.innerHTML = '<i class="fas fa-exclamation-triangle me-2"></i>Please fill in all required fields correctly.';
                    
                    // Scroll to first invalid field
                    const firstInvalid = form.querySelector('.is-invalid');
                    if (firstInvalid) {
                        firstInvalid.focus();
                    }
                }
            });
        });

        // Real-time field validation
        document.querySelectorAll('.form-control').forEach(field => {
            field.addEventListener('input', function() {
                this.classList.remove('is-invalid');
                
                // Remove validation error if exists
                const form = this.closest('form');
                const errorDiv = form.querySelector('.validation-error');
                if (errorDiv) {
                    errorDiv.remove();
                }
            });
        });

        // Customer statistics update
        function updateCustomerStats() {
            const allCustomers = document.querySelectorAll('.customer-item');
            const visibleCustomers = document.querySelectorAll('.customer-item[style*="block"], .customer-item:not([style*="none"])');
            
            const stats = {
                total: allCustomers.length,
                visible: visibleCustomers.length,
                active: 0,
                business: 0,
                individual: 0
            };
            
            visibleCustomers.forEach(customer => {
                const status = customer.getAttribute('data-status');
                const type = customer.getAttribute('data-type');
                
                if (status === 'active') stats.active++;
                if (type === 'business') stats.business++;
                if (type === 'individual') stats.individual++;
            });
            
            // Update stats cards if they exist
            const statsCards = document.querySelectorAll('.stats-mini h4');
            if (statsCards.length >= 4) {
                statsCards[0].textContent = stats.active;
                statsCards[1].textContent = stats.business;
                statsCards[2].textContent = stats.individual;
                // Fourth stat (total shipments) remains unchanged as it's calculated from PHP
            }
        }

        // Call updateCustomerStats on filter change
        ['searchCustomer', 'filterType', 'filterStatus'].forEach(id => {
            document.getElementById(id).addEventListener('input', updateCustomerStats);
            document.getElementById(id).addEventListener('change', updateCustomerStats);
        });

        // Auto-save form data to prevent data loss
        function autoSaveFormData() {
            const forms = ['addCustomerModal', 'editCustomerModal'];
            
            forms.forEach(formId => {
                const form = document.querySelector(`#${formId} form`);
                if (form) {
                    const inputs = form.querySelectorAll('input, select, textarea');
                    inputs.forEach(input => {
                        input.addEventListener('input', function() {
                            if (input.type !== 'hidden' && input.name) {
                                localStorage.setItem(`${formId}_${input.name}`, input.value);
                            }
                        });
                    });
                }
            });
        }

        // Restore form data
        function restoreFormData(formId) {
            const form = document.querySelector(`#${formId} form`);
            if (form) {
                const inputs = form.querySelectorAll('input, select, textarea');
                inputs.forEach(input => {
                    if (input.type !== 'hidden' && input.name) {
                        const savedValue = localStorage.getItem(`${formId}_${input.name}`);
                        if (savedValue) {
                            input.value = savedValue;
                        }
                    }
                });
            }
        }

        // Clear saved form data
        function clearSavedFormData(formId) {
            const form = document.querySelector(`#${formId} form`);
            if (form) {
                const inputs = form.querySelectorAll('input, select, textarea');
                inputs.forEach(input => {
                    if (input.type !== 'hidden' && input.name) {
                        localStorage.removeItem(`${formId}_${input.name}`);
                    }
                });
            }
        }

        // Initialize auto-save
        document.addEventListener('DOMContentLoaded', function() {
            autoSaveFormData();
            
            // Clear saved data on successful form submission
            document.querySelectorAll('form').forEach(form => {
                form.addEventListener('submit', function() {
                    const modalId = this.closest('.modal').id;
                    clearSavedFormData(modalId);
                });
            });
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + K for search
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                document.getElementById('searchCustomer').focus();
            }
            
            // Ctrl/Cmd + N for new customer
            if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
                e.preventDefault();
                new bootstrap.Modal(document.getElementById('addCustomerModal')).show();
            }
            
            // Escape to close modals
            if (e.key === 'Escape') {
                const openModal = document.querySelector('.modal.show');
                if (openModal) {
                    bootstrap.Modal.getInstance(openModal).hide();
                }
            }
        });

        // Export functionality (if needed)
        function exportCustomers(format) {
            const visibleCustomers = document.querySelectorAll('.customer-item[style*="block"], .customer-item:not([style*="none"])');
            
            if (format === 'csv') {
                let csvContent = "data:text/csv;charset=utf-8,";
                csvContent += "Name,Email,Phone,Type,Status,City,State,Shipments,Total Spent\n";
                
                visibleCustomers.forEach(customerElement => {
                    const customerData = JSON.parse(customerElement.querySelector('.dropdown-item').getAttribute('onclick').match(/viewCustomer\((.*?)\)/)[1]);
                    csvContent += `"${customerData.full_name}","${customerData.email}","${customerData.phone}","${customerData.customer_type}","${customerData.status}","${customerData.city}","${customerData.state}","${customerData.shipment_count}","${customerData.total_spent || 0}"\n`;
                });
                
                const encodedUri = encodeURI(csvContent);
                const link = document.createElement("a");
                link.setAttribute("href", encodedUri);
                link.setAttribute("download", `customers_${new Date().toISOString().split('T')[0]}.csv`);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }

        // Add export button functionality if needed
        console.log('Customer Management System Loaded Successfully');
        console.log(`Total Customers: ${document.querySelectorAll('.customer-item').length}`);
    </script>
</body>
</html>